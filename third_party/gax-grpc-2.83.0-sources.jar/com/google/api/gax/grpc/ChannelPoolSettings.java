/*
 * Copyright 2021 Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.google.api.gax.grpc;

import com.google.api.core.BetaApi;
import com.google.auto.value.AutoValue;
import com.google.common.base.Preconditions;
import java.time.Duration;
import org.jspecify.annotations.NullMarked;

/**
 * Settings to control {@link ChannelPool} behavior.
 *
 * <p>To facilitate low latency/high throughout applications, gax provides a {@link ChannelPool}.
 * The pool is meant to facilitate high throughput/low latency clients. By splitting load across
 * multiple gRPC channels the client can spread load across multiple frontends and overcome gRPC's
 * limit of 100 concurrent RPCs per channel. However oversizing the {@link ChannelPool} can lead to
 * underutilized channels which will lead to high tail latency due to GFEs disconnecting idle
 * channels.
 *
 * <p>The {@link ChannelPool} is designed to adapt to varying traffic patterns by tracking
 * outstanding RPCs and resizing the pool size. This class configures the behavior. In general
 * clients should aim to have less than 50 concurrent RPCs per channel and at least 1 outstanding
 * per channel per minute.
 *
 * <p>The settings in this class will be applied every minute.
 */
@NullMarked
@BetaApi("surface for channel pool sizing is not yet stable")
@AutoValue
public abstract class ChannelPoolSettings {
  /** How often to check and possibly resize the {@link ChannelPool}. */
  static final Duration RESIZE_INTERVAL = Duration.ofMinutes(1);

  /** The maximum number of channels that can be added or removed at a time. */
  static final int DEFAULT_MAX_RESIZE_DELTA = 2;

  // Arbitrary limit to prevent unbounded growth and protect server/client resources.
  // Capping at 25 ensures we don't scale too aggressively in a single cycle.
  private static final int MAX_ALLOWED_RESIZE_DELTA = 25;

  /**
   * Threshold to start scaling down the channel pool.
   *
   * <p>When the average of the maximum number of outstanding RPCs in a single minute drop below
   * this threshold, channels will be removed from the pool.
   */
  public abstract int getMinRpcsPerChannel();

  /**
   * Threshold to start scaling up the channel pool.
   *
   * <p>When the average of the maximum number of outstanding RPCs in a single minute surpass this
   * threshold, channels will be added to the pool. For google services, gRPC channels will start
   * locally queuing RPC when there are 100 concurrent RPCs.
   */
  public abstract int getMaxRpcsPerChannel();

  /**
   * The absolute minimum size of the channel pool.
   *
   * <p>Regardless of the current throughput, the number of channels will not drop below this limit
   */
  public abstract int getMinChannelCount();

  /**
   * The absolute maximum size of the channel pool.
   *
   * <p>Regardless of the current throughput, the number of channels will not exceed this limit
   */
  public abstract int getMaxChannelCount();

  /**
   * The maximum number of channels that can be added or removed at a time.
   *
   * <p>This setting limits the rate at which the channel pool can grow or shrink in a single resize
   * period. The default value is {@value #DEFAULT_MAX_RESIZE_DELTA}. Increasing this value can help
   * the pool better handle sudden bursts or spikes in requests by allowing it to scale up faster.
   * Regardless of this setting, the number of channels will never exceed {@link
   * #getMaxChannelCount()}.
   *
   * <p><b>Note:</b> This value cannot exceed {@value #MAX_ALLOWED_RESIZE_DELTA}.
   *
   * <p><b>Warning:</b> Higher values for resize delta may still result in performance degradation
   * during spikes due to rapid scaling.
   */
  abstract int getMaxResizeDelta();

  /**
   * The initial size of the channel pool.
   *
   * <p>During client construction the client open this many connections. This will be scaled up or
   * down in the next period.
   */
  public abstract int getInitialChannelCount();

  /**
   * If all of the channels should be replaced on an hourly basis.
   *
   * <p>The GFE will forcibly disconnect active channels after an hour. To minimize the cost of
   * reconnects, this will create a new channel asynchronuously, prime it and then swap it with an
   * old channel.
   */
  public abstract boolean isPreemptiveRefreshEnabled();

  /** Helper to check if the {@link ChannelPool} implementation can skip dynamic size logic */
  boolean isStaticSize() {
    // When range is restricted to a single size
    if (getMinChannelCount() == getMaxChannelCount()) {
      return true;
    }
    // When the scaling threshold are not set
    return getMinRpcsPerChannel() == 0 && getMaxRpcsPerChannel() == Integer.MAX_VALUE;
  }

  public abstract Builder toBuilder();

  public static ChannelPoolSettings staticallySized(int size) {
    return builder()
        .setInitialChannelCount(size)
        .setMinRpcsPerChannel(0)
        .setMaxRpcsPerChannel(Integer.MAX_VALUE)
        .setMinChannelCount(size)
        .setMaxChannelCount(size)
        // Static pools don't resize so this value doesn't affect operation.
        .setMaxResizeDelta(DEFAULT_MAX_RESIZE_DELTA)
        .build();
  }

  public static Builder builder() {
    return new AutoValue_ChannelPoolSettings.Builder()
        .setInitialChannelCount(1)
        .setMinChannelCount(1)
        .setMaxChannelCount(200)
        .setMinRpcsPerChannel(0)
        .setMaxRpcsPerChannel(Integer.MAX_VALUE)
        .setPreemptiveRefreshEnabled(false)
        .setMaxResizeDelta(DEFAULT_MAX_RESIZE_DELTA);
  }

  @AutoValue.Builder
  public abstract static class Builder {
    /**
     * Sets the minimum desired number of concurrent RPCs per channel.
     *
     * <p>This ensures channels are adequately utilized. If the average load per channel falls below
     * this value, the pool attempts to shrink. The resulting target channel count is a dynamic
     * value determined by load and is bounded by {@link #setMinChannelCount} and {@link
     * #setMaxChannelCount}.
     */
    public abstract Builder setMinRpcsPerChannel(int count);

    /**
     * Sets the maximum desired number of concurrent RPCs per channel.
     *
     * <p>This ensures channels do not become overloaded. If the average load per channel exceeds
     * this value, the pool attempts to expand. The resulting target channel count is a dynamic
     * value determined by load and is bounded by {@link #setMinChannelCount} and {@link
     * #setMaxChannelCount}.
     */
    public abstract Builder setMaxRpcsPerChannel(int count);

    /**
     * Sets the minimum number of channels the pool can shrink to.
     *
     * <p>When resizing, if the calculated resize bounds fall below this minimum configuration, the
     * bounds will be clamped to this value. This ensures the pool never shrinks below this absolute
     * minimum, even under very low load.
     */
    public abstract Builder setMinChannelCount(int count);

    /**
     * Sets the maximum number of channels the pool can expand to.
     *
     * <p>When resizing, if the calculated resize bounds exceed this maximum configuration, the
     * bounds will be clamped to this value. This ensures the pool never expands above this absolute
     * maximum, even under very high load.
     */
    public abstract Builder setMaxChannelCount(int count);

    /** Sets the initial number of channels in the pool. */
    public abstract Builder setInitialChannelCount(int count);

    /**
     * Sets whether preemptive channel refresh is enabled to prevent channels from becoming idle.
     */
    public abstract Builder setPreemptiveRefreshEnabled(boolean enabled);

    /**
     * Sets the maximum number of channels that can be added or removed in a single resize cycle.
     * This acts as a rate limiter to prevent wild fluctuations. The pool resizes periodically
     * according to {@link #RESIZE_INTERVAL} (default 1 minute). During resizing, this value is
     * effectively capped by the bound configured via {@link #setMaxChannelCount}.
     *
     * <p><b>Warning:</b> Higher values for resize delta may still result in performance degradation
     * during spikes due to rapid scaling.
     */
    public abstract Builder setMaxResizeDelta(int count);

    abstract ChannelPoolSettings autoBuild();

    public ChannelPoolSettings build() {
      ChannelPoolSettings s = autoBuild();

      Preconditions.checkState(
          s.getMinRpcsPerChannel() <= s.getMaxRpcsPerChannel(), "rpcsPerChannel range is invalid");
      Preconditions.checkState(
          s.getMinChannelCount() > 0, "Minimum channel count must be at least 1");
      Preconditions.checkState(
          s.getMinChannelCount() <= s.getMaxChannelCount(), "absolute channel range is invalid");
      Preconditions.checkState(
          s.getMinChannelCount() <= s.getInitialChannelCount(),
          "initial channel count be at least minChannelCount");
      Preconditions.checkState(
          s.getInitialChannelCount() <= s.getMaxChannelCount(),
          "initial channel count must be less than maxChannelCount");
      Preconditions.checkState(
          s.getInitialChannelCount() > 0, "Initial channel count must be greater than 0");
      Preconditions.checkState(
          s.getMaxResizeDelta() > 0, "Max resize delta must be greater than 0");
      Preconditions.checkState(
          s.getMaxResizeDelta() <= MAX_ALLOWED_RESIZE_DELTA,
          "Max resize delta cannot be greater than " + MAX_ALLOWED_RESIZE_DELTA);
      return s;
    }
  }
}
