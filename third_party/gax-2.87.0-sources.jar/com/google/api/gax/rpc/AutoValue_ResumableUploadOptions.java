package com.google.api.gax.rpc;

import java.time.Duration;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ResumableUploadOptions extends ResumableUploadOptions {

  private final int chunkSize;

  private final @Nullable Duration globalTimeout;

  private final @Nullable ResumableUploadProgressListener progressListener;

  private AutoValue_ResumableUploadOptions(
      int chunkSize,
      @Nullable Duration globalTimeout,
      @Nullable ResumableUploadProgressListener progressListener) {
    this.chunkSize = chunkSize;
    this.globalTimeout = globalTimeout;
    this.progressListener = progressListener;
  }

  @Override
  public int getChunkSize() {
    return chunkSize;
  }

  @Override
  public @Nullable Duration getGlobalTimeout() {
    return globalTimeout;
  }

  @Override
  public @Nullable ResumableUploadProgressListener getProgressListener() {
    return progressListener;
  }

  @Override
  public String toString() {
    return "ResumableUploadOptions{"
        + "chunkSize=" + chunkSize + ", "
        + "globalTimeout=" + globalTimeout + ", "
        + "progressListener=" + progressListener
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ResumableUploadOptions) {
      ResumableUploadOptions that = (ResumableUploadOptions) o;
      return this.chunkSize == that.getChunkSize()
          && (this.globalTimeout == null ? that.getGlobalTimeout() == null : this.globalTimeout.equals(that.getGlobalTimeout()))
          && (this.progressListener == null ? that.getProgressListener() == null : this.progressListener.equals(that.getProgressListener()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= chunkSize;
    h$ *= 1000003;
    h$ ^= (globalTimeout == null) ? 0 : globalTimeout.hashCode();
    h$ *= 1000003;
    h$ ^= (progressListener == null) ? 0 : progressListener.hashCode();
    return h$;
  }

  @Override
  public ResumableUploadOptions.Builder toBuilder() {
    return new AutoValue_ResumableUploadOptions.Builder(this);
  }

  static final class Builder extends ResumableUploadOptions.Builder {
    private int chunkSize;
    private @Nullable Duration globalTimeout;
    private @Nullable ResumableUploadProgressListener progressListener;
    private byte set$0;
    Builder() {
    }
    Builder(ResumableUploadOptions source) {
      this.chunkSize = source.getChunkSize();
      this.globalTimeout = source.getGlobalTimeout();
      this.progressListener = source.getProgressListener();
      set$0 = (byte) 1;
    }
    @Override
    public ResumableUploadOptions.Builder setChunkSize(int chunkSize) {
      this.chunkSize = chunkSize;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public int getChunkSize() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"chunkSize\" has not been set");
      }
      return chunkSize;
    }
    @Override
    public ResumableUploadOptions.Builder setGlobalTimeout(@Nullable Duration globalTimeout) {
      this.globalTimeout = globalTimeout;
      return this;
    }
    @Override
    public @Nullable Duration getGlobalTimeout() {
      return globalTimeout;
    }
    @Override
    public ResumableUploadOptions.Builder setProgressListener(@Nullable ResumableUploadProgressListener progressListener) {
      this.progressListener = progressListener;
      return this;
    }
    @Override
    ResumableUploadOptions autoBuild() {
      if (set$0 != 1) {
        String missing = " chunkSize";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ResumableUploadOptions(
          this.chunkSize,
          this.globalTimeout,
          this.progressListener);
    }
  }

}
