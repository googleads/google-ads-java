package com.google.api.gax.rpc;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ResumableUploadProgress extends ResumableUploadProgress {

  private final @Nullable String uploadUrl;

  private final long bytesUploaded;

  private final String state;

  private AutoValue_ResumableUploadProgress(
      @Nullable String uploadUrl,
      long bytesUploaded,
      String state) {
    this.uploadUrl = uploadUrl;
    this.bytesUploaded = bytesUploaded;
    this.state = state;
  }

  @Override
  public @Nullable String getUploadUrl() {
    return uploadUrl;
  }

  @Override
  public long getBytesUploaded() {
    return bytesUploaded;
  }

  @Override
  public String getState() {
    return state;
  }

  @Override
  public String toString() {
    return "ResumableUploadProgress{"
        + "uploadUrl=" + uploadUrl + ", "
        + "bytesUploaded=" + bytesUploaded + ", "
        + "state=" + state
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ResumableUploadProgress) {
      ResumableUploadProgress that = (ResumableUploadProgress) o;
      return (this.uploadUrl == null ? that.getUploadUrl() == null : this.uploadUrl.equals(that.getUploadUrl()))
          && this.bytesUploaded == that.getBytesUploaded()
          && this.state.equals(that.getState());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (uploadUrl == null) ? 0 : uploadUrl.hashCode();
    h$ *= 1000003;
    h$ ^= (int) ((bytesUploaded >>> 32) ^ bytesUploaded);
    h$ *= 1000003;
    h$ ^= state.hashCode();
    return h$;
  }

  @Override
  ResumableUploadProgress.Builder toBuilder() {
    return new AutoValue_ResumableUploadProgress.Builder(this);
  }

  static final class Builder extends ResumableUploadProgress.Builder {
    private @Nullable String uploadUrl;
    private long bytesUploaded;
    private @Nullable String state;
    private byte set$0;
    Builder() {
    }
    Builder(ResumableUploadProgress source) {
      this.uploadUrl = source.getUploadUrl();
      this.bytesUploaded = source.getBytesUploaded();
      this.state = source.getState();
      set$0 = (byte) 1;
    }
    @Override
    ResumableUploadProgress.Builder setUploadUrl(@Nullable String uploadUrl) {
      this.uploadUrl = uploadUrl;
      return this;
    }
    @Override
    ResumableUploadProgress.Builder setBytesUploaded(long bytesUploaded) {
      this.bytesUploaded = bytesUploaded;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    ResumableUploadProgress.Builder setState(String state) {
      if (state == null) {
        throw new NullPointerException("Null state");
      }
      this.state = state;
      return this;
    }
    @Override
    ResumableUploadProgress build() {
      if (set$0 != 1
          || this.state == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" bytesUploaded");
        }
        if (this.state == null) {
          missing.append(" state");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ResumableUploadProgress(
          this.uploadUrl,
          this.bytesUploaded,
          this.state);
    }
  }

}
