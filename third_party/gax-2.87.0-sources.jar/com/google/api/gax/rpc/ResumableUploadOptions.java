/*
 * Copyright 2026 Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.google.api.gax.rpc;

import com.google.api.core.BetaApi;
import com.google.auto.value.AutoValue;
import com.google.common.base.Preconditions;
import java.time.Duration;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

/**
 * Options to configure a resumable upload invocation on a {@link ResumableUploadCallable}.
 * Encapsulates protocol options such as payload chunk size and global upload timeout.
 */
@BetaApi
@AutoValue
@NullMarked
public abstract class ResumableUploadOptions {
  private static final int DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024; // 8 MB

  /** Returns the configured chunk size in bytes (defaults to 8 MB / 8,388,608 bytes). */
  public abstract int getChunkSize();

  /**
   * Returns the global upload timeout governing the entire upload duration, or {@code null} if
   * disabled.
   */
  public abstract @Nullable Duration getGlobalTimeout();

  /**
   * Returns the listener notified of upload progress and state transitions, or {@code null} if not
   * set.
   */
  public abstract @Nullable ResumableUploadProgressListener getProgressListener();

  /**
   * Merges another {@code ResumableUploadOptions} instance with this one. Fields set in {@code
   * other} override fields in this instance.
   *
   * @param other options to overlay; may be {@code null}
   * @return a new, resolved {@code ResumableUploadOptions} instance
   */
  public ResumableUploadOptions merge(@Nullable ResumableUploadOptions other) {
    if (other == null) {
      return this;
    }
    Builder builder = toBuilder();
    if (other.getChunkSize() > 0) {
      builder.setChunkSize(other.getChunkSize());
    }
    if (other.getGlobalTimeout() != null) {
      builder.setGlobalTimeout(other.getGlobalTimeout());
    }
    ResumableUploadProgressListener otherProgressListener = other.getProgressListener();
    if (otherProgressListener != null) {
      builder.setProgressListener(otherProgressListener);
    }
    return builder.build();
  }

  public abstract Builder toBuilder();

  public static Builder newBuilder() {
    return new AutoValue_ResumableUploadOptions.Builder().setChunkSize(DEFAULT_CHUNK_SIZE);
  }

  /** Builder for {@link ResumableUploadOptions}. */
  @AutoValue.Builder
  public abstract static class Builder {
    /**
     * Sets the chunk size in bytes. The payload is sent in chunks of this size, and each chunk is
     * buffered in memory so it can be resent if the upload needs to recover. Must be positive;
     * defaults to 8 MB.
     */
    public abstract Builder setChunkSize(int chunkSize);

    /** Returns the chunk size in bytes. See {@link #setChunkSize(int)}. */
    public abstract int getChunkSize();

    /**
     * Sets the global timeout bounding the entire upload, including session initiation, chunk
     * transmission, and recovery. If the upload has not completed when the timeout elapses, it is
     * cancelled and fails. Must be positive.
     */
    public abstract Builder setGlobalTimeout(@Nullable Duration globalTimeout);

    /**
     * Returns the global upload timeout, or {@code null} if unset. See {@link
     * #setGlobalTimeout(Duration)}.
     */
    public abstract @Nullable Duration getGlobalTimeout();

    /**
     * Sets the listener notified of upload progress and state transitions. Updates are delivered in
     * order, beginning with {@link ResumableUploadProgress#STATE_STARTING}. Callbacks are
     * dispatched on the client's background executor.
     */
    public abstract Builder setProgressListener(
        @Nullable ResumableUploadProgressListener progressListener);

    abstract ResumableUploadOptions autoBuild();

    public ResumableUploadOptions build() {
      Preconditions.checkArgument(getChunkSize() > 0, "chunkSize must be > 0");
      if (getGlobalTimeout() != null) {
        Preconditions.checkArgument(
            !getGlobalTimeout().isNegative() && !getGlobalTimeout().isZero(),
            "globalTimeout must be positive");
      }
      return autoBuild();
    }
  }
}
