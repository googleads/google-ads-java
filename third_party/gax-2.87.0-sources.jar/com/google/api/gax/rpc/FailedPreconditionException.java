/*
 * Copyright 2017 Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.google.api.gax.rpc;

import org.jspecify.annotations.NullMarked;

/**
 * Exception thrown when the operation was rejected because the system is not in a state required
 * for the operation's execution. For example, directory to be deleted may be non-empty, an rmdir
 * operation is applied to a non-directory, etc.
 */
@NullMarked
public class FailedPreconditionException extends ApiException {
  public FailedPreconditionException(Throwable cause, StatusCode statusCode, boolean retryable) {
    super(cause, statusCode, retryable);
  }

  public FailedPreconditionException(
      String message, Throwable cause, StatusCode statusCode, boolean retryable) {
    super(message, cause, statusCode, retryable);
  }

  public FailedPreconditionException(
      Throwable cause, StatusCode statusCode, boolean retryable, ErrorDetails errorDetails) {
    super(cause, statusCode, retryable, errorDetails);
  }

  public FailedPreconditionException(
      String message,
      Throwable cause,
      StatusCode statusCode,
      boolean retryable,
      ErrorDetails errorDetails) {
    super(message, cause, statusCode, retryable, errorDetails);
  }
}
