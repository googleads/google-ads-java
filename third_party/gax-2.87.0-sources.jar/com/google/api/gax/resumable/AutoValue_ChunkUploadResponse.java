package com.google.api.gax.resumable;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ChunkUploadResponse<ResponseT> extends ChunkUploadResponse<ResponseT> {

  private final @Nullable ResponseT response;

  private final ResumableUploadStatus uploadStatus;

  private AutoValue_ChunkUploadResponse(
      @Nullable ResponseT response,
      ResumableUploadStatus uploadStatus) {
    this.response = response;
    this.uploadStatus = uploadStatus;
  }

  @Override
  public @Nullable ResponseT getResponse() {
    return response;
  }

  @Override
  public ResumableUploadStatus getUploadStatus() {
    return uploadStatus;
  }

  @Override
  public String toString() {
    return "ChunkUploadResponse{"
        + "response=" + response + ", "
        + "uploadStatus=" + uploadStatus
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ChunkUploadResponse) {
      ChunkUploadResponse<?> that = (ChunkUploadResponse<?>) o;
      return (this.response == null ? that.getResponse() == null : this.response.equals(that.getResponse()))
          && this.uploadStatus.equals(that.getUploadStatus());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (response == null) ? 0 : response.hashCode();
    h$ *= 1000003;
    h$ ^= uploadStatus.hashCode();
    return h$;
  }

  @Override
  public ChunkUploadResponse.Builder<ResponseT> toBuilder() {
    return new AutoValue_ChunkUploadResponse.Builder<ResponseT>(this);
  }

  static final class Builder<ResponseT> extends ChunkUploadResponse.Builder<ResponseT> {
    private @Nullable ResponseT response;
    private @Nullable ResumableUploadStatus uploadStatus;
    Builder() {
    }
    Builder(ChunkUploadResponse<ResponseT> source) {
      this.response = source.getResponse();
      this.uploadStatus = source.getUploadStatus();
    }
    @Override
    public ChunkUploadResponse.Builder<ResponseT> setResponse(ResponseT response) {
      this.response = response;
      return this;
    }
    @Override
    public ChunkUploadResponse.Builder<ResponseT> setUploadStatus(ResumableUploadStatus uploadStatus) {
      if (uploadStatus == null) {
        throw new NullPointerException("Null uploadStatus");
      }
      this.uploadStatus = uploadStatus;
      return this;
    }
    @Override
    public ChunkUploadResponse<ResponseT> build() {
      if (this.uploadStatus == null) {
        String missing = " uploadStatus";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ChunkUploadResponse<ResponseT>(
          this.response,
          this.uploadStatus);
    }
  }

}
