package com.google.api.gax.resumable;

import java.util.Arrays;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ChunkUploadRequest extends ChunkUploadRequest {

  private final String uploadUrl;

  private final byte[] payload;

  private final long offset;

  private final boolean final0;

  private AutoValue_ChunkUploadRequest(
      String uploadUrl,
      byte[] payload,
      long offset,
      boolean final0) {
    this.uploadUrl = uploadUrl;
    this.payload = payload;
    this.offset = offset;
    this.final0 = final0;
  }

  @Override
  public String getUploadUrl() {
    return uploadUrl;
  }

  @SuppressWarnings("mutable")
  @Override
  public byte[] getPayload() {
    return payload;
  }

  @Override
  public long getOffset() {
    return offset;
  }

  @Override
  public boolean isFinal() {
    return final0;
  }

  @Override
  public String toString() {
    return "ChunkUploadRequest{"
        + "uploadUrl=" + uploadUrl + ", "
        + "payload=" + Arrays.toString(payload) + ", "
        + "offset=" + offset + ", "
        + "final=" + final0
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ChunkUploadRequest) {
      ChunkUploadRequest that = (ChunkUploadRequest) o;
      return this.uploadUrl.equals(that.getUploadUrl())
          && Arrays.equals(this.payload, (that instanceof AutoValue_ChunkUploadRequest) ? ((AutoValue_ChunkUploadRequest) that).payload : that.getPayload())
          && this.offset == that.getOffset()
          && this.final0 == that.isFinal();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= uploadUrl.hashCode();
    h$ *= 1000003;
    h$ ^= Arrays.hashCode(payload);
    h$ *= 1000003;
    h$ ^= (int) ((offset >>> 32) ^ offset);
    h$ *= 1000003;
    h$ ^= final0 ? 1231 : 1237;
    return h$;
  }

  @Override
  public ChunkUploadRequest.Builder toBuilder() {
    return new AutoValue_ChunkUploadRequest.Builder(this);
  }

  static final class Builder extends ChunkUploadRequest.Builder {
    private String uploadUrl;
    private byte[] payload;
    private long offset;
    private boolean final0;
    private byte set$0;
    Builder() {
    }
    Builder(ChunkUploadRequest source) {
      this.uploadUrl = source.getUploadUrl();
      this.payload = source.getPayload();
      this.offset = source.getOffset();
      this.final0 = source.isFinal();
      set$0 = (byte) 3;
    }
    @Override
    public ChunkUploadRequest.Builder setUploadUrl(String uploadUrl) {
      if (uploadUrl == null) {
        throw new NullPointerException("Null uploadUrl");
      }
      this.uploadUrl = uploadUrl;
      return this;
    }
    @Override
    public ChunkUploadRequest.Builder setPayload(byte[] payload) {
      if (payload == null) {
        throw new NullPointerException("Null payload");
      }
      this.payload = payload;
      return this;
    }
    @Override
    public ChunkUploadRequest.Builder setOffset(long offset) {
      this.offset = offset;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public ChunkUploadRequest.Builder setFinal(boolean final0) {
      this.final0 = final0;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public ChunkUploadRequest build() {
      if (set$0 != 3
          || this.uploadUrl == null
          || this.payload == null) {
        StringBuilder missing = new StringBuilder();
        if (this.uploadUrl == null) {
          missing.append(" uploadUrl");
        }
        if (this.payload == null) {
          missing.append(" payload");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" offset");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" final");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ChunkUploadRequest(
          this.uploadUrl,
          this.payload,
          this.offset,
          this.final0);
    }
  }

}
