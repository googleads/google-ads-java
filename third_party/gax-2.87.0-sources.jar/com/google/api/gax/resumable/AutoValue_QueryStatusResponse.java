package com.google.api.gax.resumable;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_QueryStatusResponse<ResponseT> extends QueryStatusResponse<ResponseT> {

  private final @Nullable Long committedOffset;

  private final @Nullable ResponseT response;

  private final ResumableUploadStatus uploadStatus;

  private AutoValue_QueryStatusResponse(
      @Nullable Long committedOffset,
      @Nullable ResponseT response,
      ResumableUploadStatus uploadStatus) {
    this.committedOffset = committedOffset;
    this.response = response;
    this.uploadStatus = uploadStatus;
  }

  @Override
  public @Nullable Long getCommittedOffset() {
    return committedOffset;
  }

  @Override
  public @Nullable ResponseT getResponse() {
    return response;
  }

  @Override
  public ResumableUploadStatus getUploadStatus() {
    return uploadStatus;
  }

  @Override
  public String toString() {
    return "QueryStatusResponse{"
        + "committedOffset=" + committedOffset + ", "
        + "response=" + response + ", "
        + "uploadStatus=" + uploadStatus
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof QueryStatusResponse) {
      QueryStatusResponse<?> that = (QueryStatusResponse<?>) o;
      return (this.committedOffset == null ? that.getCommittedOffset() == null : this.committedOffset.equals(that.getCommittedOffset()))
          && (this.response == null ? that.getResponse() == null : this.response.equals(that.getResponse()))
          && this.uploadStatus.equals(that.getUploadStatus());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (committedOffset == null) ? 0 : committedOffset.hashCode();
    h$ *= 1000003;
    h$ ^= (response == null) ? 0 : response.hashCode();
    h$ *= 1000003;
    h$ ^= uploadStatus.hashCode();
    return h$;
  }

  @Override
  public QueryStatusResponse.Builder<ResponseT> toBuilder() {
    return new AutoValue_QueryStatusResponse.Builder<ResponseT>(this);
  }

  static final class Builder<ResponseT> extends QueryStatusResponse.Builder<ResponseT> {
    private @Nullable Long committedOffset;
    private @Nullable ResponseT response;
    private @Nullable ResumableUploadStatus uploadStatus;
    Builder() {
    }
    Builder(QueryStatusResponse<ResponseT> source) {
      this.committedOffset = source.getCommittedOffset();
      this.response = source.getResponse();
      this.uploadStatus = source.getUploadStatus();
    }
    @Override
    public QueryStatusResponse.Builder<ResponseT> setCommittedOffset(@Nullable Long committedOffset) {
      this.committedOffset = committedOffset;
      return this;
    }
    @Override
    public QueryStatusResponse.Builder<ResponseT> setResponse(ResponseT response) {
      this.response = response;
      return this;
    }
    @Override
    public QueryStatusResponse.Builder<ResponseT> setUploadStatus(ResumableUploadStatus uploadStatus) {
      if (uploadStatus == null) {
        throw new NullPointerException("Null uploadStatus");
      }
      this.uploadStatus = uploadStatus;
      return this;
    }
    @Override
    public QueryStatusResponse<ResponseT> build() {
      if (this.uploadStatus == null) {
        String missing = " uploadStatus";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_QueryStatusResponse<ResponseT>(
          this.committedOffset,
          this.response,
          this.uploadStatus);
    }
  }

}
