package com.google.api.gax.resumable;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ResumableUploadSession extends ResumableUploadSession {

  private final String uploadUrl;

  private final long chunkGranularity;

  private AutoValue_ResumableUploadSession(
      String uploadUrl,
      long chunkGranularity) {
    this.uploadUrl = uploadUrl;
    this.chunkGranularity = chunkGranularity;
  }

  @Override
  public String getUploadUrl() {
    return uploadUrl;
  }

  @Override
  public long getChunkGranularity() {
    return chunkGranularity;
  }

  @Override
  public String toString() {
    return "ResumableUploadSession{"
        + "uploadUrl=" + uploadUrl + ", "
        + "chunkGranularity=" + chunkGranularity
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ResumableUploadSession) {
      ResumableUploadSession that = (ResumableUploadSession) o;
      return this.uploadUrl.equals(that.getUploadUrl())
          && this.chunkGranularity == that.getChunkGranularity();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= uploadUrl.hashCode();
    h$ *= 1000003;
    h$ ^= (int) ((chunkGranularity >>> 32) ^ chunkGranularity);
    return h$;
  }

  @Override
  public ResumableUploadSession.Builder toBuilder() {
    return new AutoValue_ResumableUploadSession.Builder(this);
  }

  static final class Builder extends ResumableUploadSession.Builder {
    private String uploadUrl;
    private long chunkGranularity;
    private byte set$0;
    Builder() {
    }
    Builder(ResumableUploadSession source) {
      this.uploadUrl = source.getUploadUrl();
      this.chunkGranularity = source.getChunkGranularity();
      set$0 = (byte) 1;
    }
    @Override
    public ResumableUploadSession.Builder setUploadUrl(String uploadUrl) {
      if (uploadUrl == null) {
        throw new NullPointerException("Null uploadUrl");
      }
      this.uploadUrl = uploadUrl;
      return this;
    }
    @Override
    public ResumableUploadSession.Builder setChunkGranularity(long chunkGranularity) {
      this.chunkGranularity = chunkGranularity;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public ResumableUploadSession build() {
      if (set$0 != 1
          || this.uploadUrl == null) {
        StringBuilder missing = new StringBuilder();
        if (this.uploadUrl == null) {
          missing.append(" uploadUrl");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" chunkGranularity");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ResumableUploadSession(
          this.uploadUrl,
          this.chunkGranularity);
    }
  }

}
