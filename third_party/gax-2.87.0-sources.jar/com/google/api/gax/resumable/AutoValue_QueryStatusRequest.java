package com.google.api.gax.resumable;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_QueryStatusRequest extends QueryStatusRequest {

  private final String uploadUrl;

  AutoValue_QueryStatusRequest(
      String uploadUrl) {
    if (uploadUrl == null) {
      throw new NullPointerException("Null uploadUrl");
    }
    this.uploadUrl = uploadUrl;
  }

  @Override
  public String getUploadUrl() {
    return uploadUrl;
  }

  @Override
  public String toString() {
    return "QueryStatusRequest{"
        + "uploadUrl=" + uploadUrl
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof QueryStatusRequest) {
      QueryStatusRequest that = (QueryStatusRequest) o;
      return this.uploadUrl.equals(that.getUploadUrl());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= uploadUrl.hashCode();
    return h$;
  }

}
