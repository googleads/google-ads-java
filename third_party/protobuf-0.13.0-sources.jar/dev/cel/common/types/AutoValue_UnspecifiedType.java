package dev.cel.common.types;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_UnspecifiedType extends UnspecifiedType {

  AutoValue_UnspecifiedType() {
  }

  @Override
  public String toString() {
    return "UnspecifiedType{"
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof UnspecifiedType) {
      return true;
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    return h$;
  }

}
