package dev.cel.common;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.ImmutableSet;
import com.google.protobuf.Descriptors;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelDescriptors extends CelDescriptors {

  private final ImmutableSet<Descriptors.Descriptor> messageTypeDescriptors;

  private final ImmutableSet<Descriptors.EnumDescriptor> enumDescriptors;

  private final ImmutableMultimap<String, Descriptors.FieldDescriptor> extensionDescriptors;

  private final ImmutableSet<Descriptors.FileDescriptor> fileDescriptors;

  private AutoValue_CelDescriptors(
      ImmutableSet<Descriptors.Descriptor> messageTypeDescriptors,
      ImmutableSet<Descriptors.EnumDescriptor> enumDescriptors,
      ImmutableMultimap<String, Descriptors.FieldDescriptor> extensionDescriptors,
      ImmutableSet<Descriptors.FileDescriptor> fileDescriptors) {
    this.messageTypeDescriptors = messageTypeDescriptors;
    this.enumDescriptors = enumDescriptors;
    this.extensionDescriptors = extensionDescriptors;
    this.fileDescriptors = fileDescriptors;
  }

  @Override
  public ImmutableSet<Descriptors.Descriptor> messageTypeDescriptors() {
    return messageTypeDescriptors;
  }

  @Override
  public ImmutableSet<Descriptors.EnumDescriptor> enumDescriptors() {
    return enumDescriptors;
  }

  @Override
  public ImmutableMultimap<String, Descriptors.FieldDescriptor> extensionDescriptors() {
    return extensionDescriptors;
  }

  @Override
  public ImmutableSet<Descriptors.FileDescriptor> fileDescriptors() {
    return fileDescriptors;
  }

  @Override
  public String toString() {
    return "CelDescriptors{"
        + "messageTypeDescriptors=" + messageTypeDescriptors + ", "
        + "enumDescriptors=" + enumDescriptors + ", "
        + "extensionDescriptors=" + extensionDescriptors + ", "
        + "fileDescriptors=" + fileDescriptors
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelDescriptors) {
      CelDescriptors that = (CelDescriptors) o;
      return this.messageTypeDescriptors.equals(that.messageTypeDescriptors())
          && this.enumDescriptors.equals(that.enumDescriptors())
          && this.extensionDescriptors.equals(that.extensionDescriptors())
          && this.fileDescriptors.equals(that.fileDescriptors());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= messageTypeDescriptors.hashCode();
    h$ *= 1000003;
    h$ ^= enumDescriptors.hashCode();
    h$ *= 1000003;
    h$ ^= extensionDescriptors.hashCode();
    h$ *= 1000003;
    h$ ^= fileDescriptors.hashCode();
    return h$;
  }

  static final class Builder extends CelDescriptors.Builder {
    private ImmutableSet.Builder<Descriptors.Descriptor> messageTypeDescriptorsBuilder$;
    private ImmutableSet<Descriptors.Descriptor> messageTypeDescriptors;
    private ImmutableSet.Builder<Descriptors.EnumDescriptor> enumDescriptorsBuilder$;
    private ImmutableSet<Descriptors.EnumDescriptor> enumDescriptors;
    private ImmutableMultimap.Builder<String, Descriptors.FieldDescriptor> extensionDescriptorsBuilder$;
    private ImmutableMultimap<String, Descriptors.FieldDescriptor> extensionDescriptors;
    private ImmutableSet.Builder<Descriptors.FileDescriptor> fileDescriptorsBuilder$;
    private ImmutableSet<Descriptors.FileDescriptor> fileDescriptors;
    Builder() {
    }
    @Override
    CelDescriptors.Builder setMessageTypeDescriptors(ImmutableSet<Descriptors.Descriptor> messageTypeDescriptors) {
      if (messageTypeDescriptors == null) {
        throw new NullPointerException("Null messageTypeDescriptors");
      }
      if (messageTypeDescriptorsBuilder$ != null) {
        throw new IllegalStateException("Cannot set messageTypeDescriptors after calling messageTypeDescriptorsBuilder()");
      }
      this.messageTypeDescriptors = messageTypeDescriptors;
      return this;
    }
    @Override
    protected ImmutableSet.Builder<Descriptors.Descriptor> messageTypeDescriptorsBuilder() {
      if (messageTypeDescriptorsBuilder$ == null) {
        if (messageTypeDescriptors == null) {
          messageTypeDescriptorsBuilder$ = ImmutableSet.builder();
        } else {
          messageTypeDescriptorsBuilder$ = ImmutableSet.builder();
          messageTypeDescriptorsBuilder$.addAll(messageTypeDescriptors);
          messageTypeDescriptors = null;
        }
      }
      return messageTypeDescriptorsBuilder$;
    }
    @Override
    CelDescriptors.Builder setEnumDescriptors(ImmutableSet<Descriptors.EnumDescriptor> enumDescriptors) {
      if (enumDescriptors == null) {
        throw new NullPointerException("Null enumDescriptors");
      }
      if (enumDescriptorsBuilder$ != null) {
        throw new IllegalStateException("Cannot set enumDescriptors after calling enumDescriptorsBuilder()");
      }
      this.enumDescriptors = enumDescriptors;
      return this;
    }
    @Override
    protected ImmutableSet.Builder<Descriptors.EnumDescriptor> enumDescriptorsBuilder() {
      if (enumDescriptorsBuilder$ == null) {
        if (enumDescriptors == null) {
          enumDescriptorsBuilder$ = ImmutableSet.builder();
        } else {
          enumDescriptorsBuilder$ = ImmutableSet.builder();
          enumDescriptorsBuilder$.addAll(enumDescriptors);
          enumDescriptors = null;
        }
      }
      return enumDescriptorsBuilder$;
    }
    @Override
    CelDescriptors.Builder setExtensionDescriptors(ImmutableMultimap<String, Descriptors.FieldDescriptor> extensionDescriptors) {
      if (extensionDescriptors == null) {
        throw new NullPointerException("Null extensionDescriptors");
      }
      if (extensionDescriptorsBuilder$ != null) {
        throw new IllegalStateException("Cannot set extensionDescriptors after calling extensionDescriptorsBuilder()");
      }
      this.extensionDescriptors = extensionDescriptors;
      return this;
    }
    @Override
    protected ImmutableMultimap.Builder<String, Descriptors.FieldDescriptor> extensionDescriptorsBuilder() {
      if (extensionDescriptorsBuilder$ == null) {
        if (extensionDescriptors == null) {
          extensionDescriptorsBuilder$ = ImmutableMultimap.builder();
        } else {
          extensionDescriptorsBuilder$ = ImmutableMultimap.builder();
          extensionDescriptorsBuilder$.putAll(extensionDescriptors);
          extensionDescriptors = null;
        }
      }
      return extensionDescriptorsBuilder$;
    }
    @Override
    CelDescriptors.Builder setFileDescriptors(ImmutableSet<Descriptors.FileDescriptor> fileDescriptors) {
      if (fileDescriptors == null) {
        throw new NullPointerException("Null fileDescriptors");
      }
      if (fileDescriptorsBuilder$ != null) {
        throw new IllegalStateException("Cannot set fileDescriptors after calling fileDescriptorsBuilder()");
      }
      this.fileDescriptors = fileDescriptors;
      return this;
    }
    @Override
    protected ImmutableSet.Builder<Descriptors.FileDescriptor> fileDescriptorsBuilder() {
      if (fileDescriptorsBuilder$ == null) {
        if (fileDescriptors == null) {
          fileDescriptorsBuilder$ = ImmutableSet.builder();
        } else {
          fileDescriptorsBuilder$ = ImmutableSet.builder();
          fileDescriptorsBuilder$.addAll(fileDescriptors);
          fileDescriptors = null;
        }
      }
      return fileDescriptorsBuilder$;
    }
    @Override
    public CelDescriptors build() {
      if (messageTypeDescriptorsBuilder$ != null) {
        this.messageTypeDescriptors = messageTypeDescriptorsBuilder$.build();
      } else if (this.messageTypeDescriptors == null) {
        this.messageTypeDescriptors = ImmutableSet.of();
      }
      if (enumDescriptorsBuilder$ != null) {
        this.enumDescriptors = enumDescriptorsBuilder$.build();
      } else if (this.enumDescriptors == null) {
        this.enumDescriptors = ImmutableSet.of();
      }
      if (extensionDescriptorsBuilder$ != null) {
        this.extensionDescriptors = extensionDescriptorsBuilder$.build();
      } else if (this.extensionDescriptors == null) {
        this.extensionDescriptors = ImmutableMultimap.of();
      }
      if (fileDescriptorsBuilder$ != null) {
        this.fileDescriptors = fileDescriptorsBuilder$.build();
      } else if (this.fileDescriptors == null) {
        this.fileDescriptors = ImmutableSet.of();
      }
      return new AutoValue_CelDescriptors(
          this.messageTypeDescriptors,
          this.enumDescriptors,
          this.extensionDescriptors,
          this.fileDescriptors);
    }
  }

}
