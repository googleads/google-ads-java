package dev.cel.common.types;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_TypeType extends TypeType {

  private final ImmutableList<CelType> parameters;

  AutoValue_TypeType(
      ImmutableList<CelType> parameters) {
    if (parameters == null) {
      throw new NullPointerException("Null parameters");
    }
    this.parameters = parameters;
  }

  @Override
  public ImmutableList<CelType> parameters() {
    return parameters;
  }

  @Override
  public String toString() {
    return "TypeType{"
        + "parameters=" + parameters
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof TypeType) {
      TypeType that = (TypeType) o;
      return this.parameters.equals(that.parameters());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= parameters.hashCode();
    return h$;
  }

}
