package dev.cel.common.types;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_NullableType extends NullableType {

  private final CelKind kind;

  private final String name;

  private final CelType targetType;

  AutoValue_NullableType(
      CelKind kind,
      String name,
      CelType targetType) {
    if (kind == null) {
      throw new NullPointerException("Null kind");
    }
    this.kind = kind;
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
    if (targetType == null) {
      throw new NullPointerException("Null targetType");
    }
    this.targetType = targetType;
  }

  @Override
  public CelKind kind() {
    return kind;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public CelType targetType() {
    return targetType;
  }

  @Override
  public String toString() {
    return "NullableType{"
        + "kind=" + kind + ", "
        + "name=" + name + ", "
        + "targetType=" + targetType
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof NullableType) {
      NullableType that = (NullableType) o;
      return this.kind.equals(that.kind())
          && this.name.equals(that.name())
          && this.targetType.equals(that.targetType());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= kind.hashCode();
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= targetType.hashCode();
    return h$;
  }

}
