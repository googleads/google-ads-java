package dev.cel.common.types;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProtoMessageType_Extension extends ProtoMessageType.Extension {

  private final String name;

  private final CelType type;

  private final CelType messageType;

  AutoValue_ProtoMessageType_Extension(
      String name,
      CelType type,
      CelType messageType) {
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
    if (type == null) {
      throw new NullPointerException("Null type");
    }
    this.type = type;
    if (messageType == null) {
      throw new NullPointerException("Null messageType");
    }
    this.messageType = messageType;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public CelType type() {
    return type;
  }

  @Override
  public CelType messageType() {
    return messageType;
  }

  @Override
  public String toString() {
    return "Extension{"
        + "name=" + name + ", "
        + "type=" + type + ", "
        + "messageType=" + messageType
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProtoMessageType.Extension) {
      ProtoMessageType.Extension that = (ProtoMessageType.Extension) o;
      return this.name.equals(that.name())
          && this.type.equals(that.type())
          && this.messageType.equals(that.messageType());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= type.hashCode();
    h$ *= 1000003;
    h$ ^= messageType.hashCode();
    return h$;
  }

}
