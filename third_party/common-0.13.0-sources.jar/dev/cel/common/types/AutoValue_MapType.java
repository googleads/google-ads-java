package dev.cel.common.types;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_MapType extends MapType {

  private final CelKind kind;

  private final String name;

  private final ImmutableList<CelType> parameters;

  AutoValue_MapType(
      CelKind kind,
      String name,
      ImmutableList<CelType> parameters) {
    if (kind == null) {
      throw new NullPointerException("Null kind");
    }
    this.kind = kind;
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
    if (parameters == null) {
      throw new NullPointerException("Null parameters");
    }
    this.parameters = parameters;
  }

  @Override
  public CelKind kind() {
    return kind;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public ImmutableList<CelType> parameters() {
    return parameters;
  }

  @Override
  public String toString() {
    return "MapType{"
        + "kind=" + kind + ", "
        + "name=" + name + ", "
        + "parameters=" + parameters
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof MapType) {
      MapType that = (MapType) o;
      return this.kind.equals(that.kind())
          && this.name.equals(that.name())
          && this.parameters.equals(that.parameters());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= kind.hashCode();
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= parameters.hashCode();
    return h$;
  }

}
