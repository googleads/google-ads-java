package dev.cel.common.types;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_StructType_Field extends StructType.Field {

  private final String name;

  private final CelType type;

  AutoValue_StructType_Field(
      String name,
      CelType type) {
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
    if (type == null) {
      throw new NullPointerException("Null type");
    }
    this.type = type;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public CelType type() {
    return type;
  }

  @Override
  public String toString() {
    return "Field{"
        + "name=" + name + ", "
        + "type=" + type
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof StructType.Field) {
      StructType.Field that = (StructType.Field) o;
      return this.name.equals(that.name())
          && this.type.equals(that.type());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= type.hashCode();
    return h$;
  }

}
