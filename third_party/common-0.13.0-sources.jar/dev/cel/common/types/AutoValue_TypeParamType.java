package dev.cel.common.types;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_TypeParamType extends TypeParamType {

  private final CelKind kind;

  private final String name;

  AutoValue_TypeParamType(
      CelKind kind,
      String name) {
    if (kind == null) {
      throw new NullPointerException("Null kind");
    }
    this.kind = kind;
    if (name == null) {
      throw new NullPointerException("Null name");
    }
    this.name = name;
  }

  @Override
  public CelKind kind() {
    return kind;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public String toString() {
    return "TypeParamType{"
        + "kind=" + kind + ", "
        + "name=" + name
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof TypeParamType) {
      TypeParamType that = (TypeParamType) o;
      return this.kind.equals(that.kind())
          && this.name.equals(that.name());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= kind.hashCode();
    h$ *= 1000003;
    h$ ^= name.hashCode();
    return h$;
  }

}
