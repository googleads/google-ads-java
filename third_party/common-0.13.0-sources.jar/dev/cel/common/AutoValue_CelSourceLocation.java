package dev.cel.common;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelSourceLocation extends CelSourceLocation {

  private final int line;

  private final int column;

  private AutoValue_CelSourceLocation(
      int line,
      int column) {
    this.line = line;
    this.column = column;
  }

  @Override
  public int getLine() {
    return line;
  }

  @Override
  public int getColumn() {
    return column;
  }

  @Override
  public String toString() {
    return "CelSourceLocation{"
        + "line=" + line + ", "
        + "column=" + column
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelSourceLocation) {
      CelSourceLocation that = (CelSourceLocation) o;
      return this.line == that.getLine()
          && this.column == that.getColumn();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= line;
    h$ *= 1000003;
    h$ ^= column;
    return h$;
  }

  static final class Builder extends CelSourceLocation.Builder {
    private int line;
    private int column;
    private byte set$0;
    Builder() {
    }
    @Override
    CelSourceLocation.Builder setLine(int line) {
      this.line = line;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    CelSourceLocation.Builder setColumn(int column) {
      this.column = column;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    CelSourceLocation build() {
      if (set$0 != 3) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" line");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" column");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelSourceLocation(
          this.line,
          this.column);
    }
  }

}
