package dev.cel.common;

import com.google.common.collect.ImmutableMap;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelContainer extends CelContainer {

  private final String name;

  private final ImmutableMap<String, CelContainer.AliasEntry> aliasMap;

  private AutoValue_CelContainer(
      String name,
      ImmutableMap<String, CelContainer.AliasEntry> aliasMap) {
    this.name = name;
    this.aliasMap = aliasMap;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  ImmutableMap<String, CelContainer.AliasEntry> aliasMap() {
    return aliasMap;
  }

  @Override
  public String toString() {
    return "CelContainer{"
        + "name=" + name + ", "
        + "aliasMap=" + aliasMap
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelContainer) {
      CelContainer that = (CelContainer) o;
      return this.name.equals(that.name())
          && this.aliasMap.equals(that.aliasMap());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= name.hashCode();
    h$ *= 1000003;
    h$ ^= aliasMap.hashCode();
    return h$;
  }

  @Override
  CelContainer.Builder autoToBuilder() {
    return new AutoValue_CelContainer.Builder(this);
  }

  static final class Builder extends CelContainer.Builder {
    private String name;
    private ImmutableMap<String, CelContainer.AliasEntry> aliasMap;
    Builder() {
    }
    Builder(CelContainer source) {
      this.name = source.name();
      this.aliasMap = source.aliasMap();
    }
    @Override
    public CelContainer.Builder setName(String name) {
      if (name == null) {
        throw new NullPointerException("Null name");
      }
      this.name = name;
      return this;
    }
    @Override
    String name() {
      if (this.name == null) {
        throw new IllegalStateException("Property \"name\" has not been set");
      }
      return name;
    }
    @Override
    CelContainer.Builder setAliasMap(ImmutableMap<String, CelContainer.AliasEntry> aliasMap) {
      if (aliasMap == null) {
        throw new NullPointerException("Null aliasMap");
      }
      this.aliasMap = aliasMap;
      return this;
    }
    @Override
    CelContainer autoBuild() {
      if (this.name == null
          || this.aliasMap == null) {
        StringBuilder missing = new StringBuilder();
        if (this.name == null) {
          missing.append(" name");
        }
        if (this.aliasMap == null) {
          missing.append(" aliasMap");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelContainer(
          this.name,
          this.aliasMap);
    }
  }

}
