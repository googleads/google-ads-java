package dev.cel.common.values;

import dev.cel.common.types.OpaqueType;
import javax.annotation.Generated;

@SuppressWarnings("Immutable")
@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_OpaqueValue extends OpaqueValue {

  private final Object value;

  private final OpaqueType celType;

  AutoValue_OpaqueValue(
      Object value,
      OpaqueType celType) {
    if (value == null) {
      throw new NullPointerException("Null value");
    }
    this.value = value;
    if (celType == null) {
      throw new NullPointerException("Null celType");
    }
    this.celType = celType;
  }

  @Override
  public Object value() {
    return value;
  }

  @Override
  public OpaqueType celType() {
    return celType;
  }

  @Override
  public String toString() {
    return "OpaqueValue{"
        + "value=" + value + ", "
        + "celType=" + celType
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof OpaqueValue) {
      OpaqueValue that = (OpaqueValue) o;
      return this.value.equals(that.value())
          && this.celType.equals(that.celType());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= value.hashCode();
    h$ *= 1000003;
    h$ ^= celType.hashCode();
    return h$;
  }

}
