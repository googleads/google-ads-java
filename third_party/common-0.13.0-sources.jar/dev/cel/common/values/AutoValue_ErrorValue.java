package dev.cel.common.values;

import dev.cel.common.annotations.Internal;
import javax.annotation.Generated;

@Internal
@SuppressWarnings("Immutable")
@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ErrorValue extends ErrorValue {

  private final long exprId;

  private final Exception value;

  AutoValue_ErrorValue(
      long exprId,
      Exception value) {
    this.exprId = exprId;
    if (value == null) {
      throw new NullPointerException("Null value");
    }
    this.value = value;
  }

  @Override
  public long exprId() {
    return exprId;
  }

  @Override
  public Exception value() {
    return value;
  }

  @Override
  public String toString() {
    return "ErrorValue{"
        + "exprId=" + exprId + ", "
        + "value=" + value
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ErrorValue) {
      ErrorValue that = (ErrorValue) o;
      return this.exprId == that.exprId()
          && this.value.equals(that.value());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((exprId >>> 32) ^ exprId);
    h$ *= 1000003;
    h$ ^= value.hashCode();
    return h$;
  }

}
