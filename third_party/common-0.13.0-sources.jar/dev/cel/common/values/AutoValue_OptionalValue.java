package dev.cel.common.values;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_OptionalValue<E, T> extends OptionalValue<E, T> {

  private final @Nullable E innerValue;

  AutoValue_OptionalValue(
      @Nullable E innerValue) {
    this.innerValue = innerValue;
  }

  @Override
  @Nullable E innerValue() {
    return innerValue;
  }

  @Override
  public String toString() {
    return "OptionalValue{"
        + "innerValue=" + innerValue
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof OptionalValue) {
      OptionalValue<?, ?> that = (OptionalValue<?, ?>) o;
      return (this.innerValue == null ? that.innerValue() == null : this.innerValue.equals(that.innerValue()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (innerValue == null) ? 0 : innerValue.hashCode();
    return h$;
  }

}
