package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelConstant_CelConstantNotSet extends CelConstant.CelConstantNotSet {

  AutoValue_CelConstant_CelConstantNotSet() {
  }

  @Override
  public String toString() {
    return "CelConstantNotSet{"
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelConstant.CelConstantNotSet) {
      return true;
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    return h$;
  }

}
