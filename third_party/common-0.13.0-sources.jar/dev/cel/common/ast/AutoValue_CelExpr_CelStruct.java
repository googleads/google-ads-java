package dev.cel.common.ast;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelStruct extends CelExpr.CelStruct {

  private final String messageName;

  private final ImmutableList<CelExpr.CelStruct.Entry> entries;

  private AutoValue_CelExpr_CelStruct(
      String messageName,
      ImmutableList<CelExpr.CelStruct.Entry> entries) {
    this.messageName = messageName;
    this.entries = entries;
  }

  @Override
  public String messageName() {
    return messageName;
  }

  @Override
  public ImmutableList<CelExpr.CelStruct.Entry> entries() {
    return entries;
  }

  @Override
  public String toString() {
    return "CelStruct{"
        + "messageName=" + messageName + ", "
        + "entries=" + entries
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelStruct) {
      CelExpr.CelStruct that = (CelExpr.CelStruct) o;
      return this.messageName.equals(that.messageName())
          && this.entries.equals(that.entries());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= messageName.hashCode();
    h$ *= 1000003;
    h$ ^= entries.hashCode();
    return h$;
  }

  @Override
  CelExpr.CelStruct.Builder autoToBuilder() {
    return new AutoValue_CelExpr_CelStruct.Builder(this);
  }

  static final class Builder extends CelExpr.CelStruct.Builder {
    private String messageName;
    private ImmutableList<CelExpr.CelStruct.Entry> entries;
    Builder() {
    }
    Builder(CelExpr.CelStruct source) {
      this.messageName = source.messageName();
      this.entries = source.entries();
    }
    @Override
    public CelExpr.CelStruct.Builder setMessageName(String messageName) {
      if (messageName == null) {
        throw new NullPointerException("Null messageName");
      }
      this.messageName = messageName;
      return this;
    }
    @Override
    CelExpr.CelStruct.Builder setEntries(ImmutableList<CelExpr.CelStruct.Entry> entries) {
      if (entries == null) {
        throw new NullPointerException("Null entries");
      }
      this.entries = entries;
      return this;
    }
    @Override
    ImmutableList<CelExpr.CelStruct.Entry> entries() {
      if (this.entries == null) {
        throw new IllegalStateException("Property \"entries\" has not been set");
      }
      return entries;
    }
    @Override
    CelExpr.CelStruct autoBuild() {
      if (this.messageName == null
          || this.entries == null) {
        StringBuilder missing = new StringBuilder();
        if (this.messageName == null) {
          missing.append(" messageName");
        }
        if (this.entries == null) {
          missing.append(" entries");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelStruct(
          this.messageName,
          this.entries);
    }
  }

}
