package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelSelect extends CelExpr.CelSelect {

  private final CelExpr operand;

  private final String field;

  private final boolean testOnly;

  private AutoValue_CelExpr_CelSelect(
      CelExpr operand,
      String field,
      boolean testOnly) {
    this.operand = operand;
    this.field = field;
    this.testOnly = testOnly;
  }

  @Override
  public CelExpr operand() {
    return operand;
  }

  @Override
  public String field() {
    return field;
  }

  @Override
  public boolean testOnly() {
    return testOnly;
  }

  @Override
  public String toString() {
    return "CelSelect{"
        + "operand=" + operand + ", "
        + "field=" + field + ", "
        + "testOnly=" + testOnly
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelSelect) {
      CelExpr.CelSelect that = (CelExpr.CelSelect) o;
      return this.operand.equals(that.operand())
          && this.field.equals(that.field())
          && this.testOnly == that.testOnly();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= operand.hashCode();
    h$ *= 1000003;
    h$ ^= field.hashCode();
    h$ *= 1000003;
    h$ ^= testOnly ? 1231 : 1237;
    return h$;
  }

  @Override
  public CelExpr.CelSelect.Builder toBuilder() {
    return new AutoValue_CelExpr_CelSelect.Builder(this);
  }

  static final class Builder extends CelExpr.CelSelect.Builder {
    private CelExpr operand;
    private String field;
    private boolean testOnly;
    private byte set$0;
    Builder() {
    }
    Builder(CelExpr.CelSelect source) {
      this.operand = source.operand();
      this.field = source.field();
      this.testOnly = source.testOnly();
      set$0 = (byte) 1;
    }
    @Override
    public CelExpr.CelSelect.Builder setOperand(CelExpr operand) {
      if (operand == null) {
        throw new NullPointerException("Null operand");
      }
      this.operand = operand;
      return this;
    }
    @Override
    public CelExpr operand() {
      if (this.operand == null) {
        throw new IllegalStateException("Property \"operand\" has not been set");
      }
      return operand;
    }
    @Override
    public CelExpr.CelSelect.Builder setField(String field) {
      if (field == null) {
        throw new NullPointerException("Null field");
      }
      this.field = field;
      return this;
    }
    @Override
    public String field() {
      if (this.field == null) {
        throw new IllegalStateException("Property \"field\" has not been set");
      }
      return field;
    }
    @Override
    public CelExpr.CelSelect.Builder setTestOnly(boolean testOnly) {
      this.testOnly = testOnly;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public boolean testOnly() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"testOnly\" has not been set");
      }
      return testOnly;
    }
    @Override
    public CelExpr.CelSelect build() {
      if (set$0 != 1
          || this.operand == null
          || this.field == null) {
        StringBuilder missing = new StringBuilder();
        if (this.operand == null) {
          missing.append(" operand");
        }
        if (this.field == null) {
          missing.append(" field");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" testOnly");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelSelect(
          this.operand,
          this.field,
          this.testOnly);
    }
  }

}
