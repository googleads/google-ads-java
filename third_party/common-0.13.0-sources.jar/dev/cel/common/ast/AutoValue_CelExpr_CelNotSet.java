package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelNotSet extends CelExpr.CelNotSet {

  AutoValue_CelExpr_CelNotSet() {
  }

  @Override
  public String toString() {
    return "CelNotSet{"
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelNotSet) {
      return true;
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    return h$;
  }

}
