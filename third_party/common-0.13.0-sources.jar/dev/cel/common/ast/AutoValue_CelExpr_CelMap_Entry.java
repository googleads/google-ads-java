package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelMap_Entry extends CelExpr.CelMap.Entry {

  private final long id;

  private final CelExpr key;

  private final CelExpr value;

  private final boolean optionalEntry;

  private AutoValue_CelExpr_CelMap_Entry(
      long id,
      CelExpr key,
      CelExpr value,
      boolean optionalEntry) {
    this.id = id;
    this.key = key;
    this.value = value;
    this.optionalEntry = optionalEntry;
  }

  @Override
  public long id() {
    return id;
  }

  @Override
  public CelExpr key() {
    return key;
  }

  @Override
  public CelExpr value() {
    return value;
  }

  @Override
  public boolean optionalEntry() {
    return optionalEntry;
  }

  @Override
  public String toString() {
    return "Entry{"
        + "id=" + id + ", "
        + "key=" + key + ", "
        + "value=" + value + ", "
        + "optionalEntry=" + optionalEntry
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelMap.Entry) {
      CelExpr.CelMap.Entry that = (CelExpr.CelMap.Entry) o;
      return this.id == that.id()
          && this.key.equals(that.key())
          && this.value.equals(that.value())
          && this.optionalEntry == that.optionalEntry();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((id >>> 32) ^ id);
    h$ *= 1000003;
    h$ ^= key.hashCode();
    h$ *= 1000003;
    h$ ^= value.hashCode();
    h$ *= 1000003;
    h$ ^= optionalEntry ? 1231 : 1237;
    return h$;
  }

  @Override
  public CelExpr.CelMap.Entry.Builder toBuilder() {
    return new AutoValue_CelExpr_CelMap_Entry.Builder(this);
  }

  static final class Builder extends CelExpr.CelMap.Entry.Builder {
    private long id;
    private CelExpr key;
    private CelExpr value;
    private boolean optionalEntry;
    private byte set$0;
    Builder() {
    }
    Builder(CelExpr.CelMap.Entry source) {
      this.id = source.id();
      this.key = source.key();
      this.value = source.value();
      this.optionalEntry = source.optionalEntry();
      set$0 = (byte) 3;
    }
    @Override
    public CelExpr.CelMap.Entry.Builder setId(long id) {
      this.id = id;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public long id() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"id\" has not been set");
      }
      return id;
    }
    @Override
    public CelExpr.CelMap.Entry.Builder setKey(CelExpr key) {
      if (key == null) {
        throw new NullPointerException("Null key");
      }
      this.key = key;
      return this;
    }
    @Override
    public CelExpr key() {
      if (this.key == null) {
        throw new IllegalStateException("Property \"key\" has not been set");
      }
      return key;
    }
    @Override
    public CelExpr.CelMap.Entry.Builder setValue(CelExpr value) {
      if (value == null) {
        throw new NullPointerException("Null value");
      }
      this.value = value;
      return this;
    }
    @Override
    public CelExpr value() {
      if (this.value == null) {
        throw new IllegalStateException("Property \"value\" has not been set");
      }
      return value;
    }
    @Override
    public CelExpr.CelMap.Entry.Builder setOptionalEntry(boolean optionalEntry) {
      this.optionalEntry = optionalEntry;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public CelExpr.CelMap.Entry build() {
      if (set$0 != 3
          || this.key == null
          || this.value == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" id");
        }
        if (this.key == null) {
          missing.append(" key");
        }
        if (this.value == null) {
          missing.append(" value");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" optionalEntry");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelMap_Entry(
          this.id,
          this.key,
          this.value,
          this.optionalEntry);
    }
  }

}
