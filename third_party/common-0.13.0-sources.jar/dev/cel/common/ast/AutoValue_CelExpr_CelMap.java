package dev.cel.common.ast;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelMap extends CelExpr.CelMap {

  private final ImmutableList<CelExpr.CelMap.Entry> entries;

  private AutoValue_CelExpr_CelMap(
      ImmutableList<CelExpr.CelMap.Entry> entries) {
    this.entries = entries;
  }

  @Override
  public ImmutableList<CelExpr.CelMap.Entry> entries() {
    return entries;
  }

  @Override
  public String toString() {
    return "CelMap{"
        + "entries=" + entries
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelMap) {
      CelExpr.CelMap that = (CelExpr.CelMap) o;
      return this.entries.equals(that.entries());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= entries.hashCode();
    return h$;
  }

  @Override
  CelExpr.CelMap.Builder autoToBuilder() {
    return new AutoValue_CelExpr_CelMap.Builder(this);
  }

  static final class Builder extends CelExpr.CelMap.Builder {
    private ImmutableList<CelExpr.CelMap.Entry> entries;
    Builder() {
    }
    Builder(CelExpr.CelMap source) {
      this.entries = source.entries();
    }
    @Override
    CelExpr.CelMap.Builder setEntries(ImmutableList<CelExpr.CelMap.Entry> entries) {
      if (entries == null) {
        throw new NullPointerException("Null entries");
      }
      this.entries = entries;
      return this;
    }
    @Override
    ImmutableList<CelExpr.CelMap.Entry> entries() {
      if (this.entries == null) {
        throw new IllegalStateException("Property \"entries\" has not been set");
      }
      return entries;
    }
    @Override
    CelExpr.CelMap autoBuild() {
      if (this.entries == null) {
        String missing = " entries";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelMap(
          this.entries);
    }
  }

}
