package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelStruct_Entry extends CelExpr.CelStruct.Entry {

  private final long id;

  private final String fieldKey;

  private final CelExpr value;

  private final boolean optionalEntry;

  private AutoValue_CelExpr_CelStruct_Entry(
      long id,
      String fieldKey,
      CelExpr value,
      boolean optionalEntry) {
    this.id = id;
    this.fieldKey = fieldKey;
    this.value = value;
    this.optionalEntry = optionalEntry;
  }

  @Override
  public long id() {
    return id;
  }

  @Override
  public String fieldKey() {
    return fieldKey;
  }

  @Override
  public CelExpr value() {
    return value;
  }

  @Override
  public boolean optionalEntry() {
    return optionalEntry;
  }

  @Override
  public String toString() {
    return "Entry{"
        + "id=" + id + ", "
        + "fieldKey=" + fieldKey + ", "
        + "value=" + value + ", "
        + "optionalEntry=" + optionalEntry
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelStruct.Entry) {
      CelExpr.CelStruct.Entry that = (CelExpr.CelStruct.Entry) o;
      return this.id == that.id()
          && this.fieldKey.equals(that.fieldKey())
          && this.value.equals(that.value())
          && this.optionalEntry == that.optionalEntry();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((id >>> 32) ^ id);
    h$ *= 1000003;
    h$ ^= fieldKey.hashCode();
    h$ *= 1000003;
    h$ ^= value.hashCode();
    h$ *= 1000003;
    h$ ^= optionalEntry ? 1231 : 1237;
    return h$;
  }

  @Override
  public CelExpr.CelStruct.Entry.Builder toBuilder() {
    return new AutoValue_CelExpr_CelStruct_Entry.Builder(this);
  }

  static final class Builder extends CelExpr.CelStruct.Entry.Builder {
    private long id;
    private String fieldKey;
    private CelExpr value;
    private boolean optionalEntry;
    private byte set$0;
    Builder() {
    }
    Builder(CelExpr.CelStruct.Entry source) {
      this.id = source.id();
      this.fieldKey = source.fieldKey();
      this.value = source.value();
      this.optionalEntry = source.optionalEntry();
      set$0 = (byte) 3;
    }
    @Override
    public CelExpr.CelStruct.Entry.Builder setId(long id) {
      this.id = id;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public long id() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"id\" has not been set");
      }
      return id;
    }
    @Override
    public CelExpr.CelStruct.Entry.Builder setFieldKey(String fieldKey) {
      if (fieldKey == null) {
        throw new NullPointerException("Null fieldKey");
      }
      this.fieldKey = fieldKey;
      return this;
    }
    @Override
    public CelExpr.CelStruct.Entry.Builder setValue(CelExpr value) {
      if (value == null) {
        throw new NullPointerException("Null value");
      }
      this.value = value;
      return this;
    }
    @Override
    public CelExpr value() {
      if (this.value == null) {
        throw new IllegalStateException("Property \"value\" has not been set");
      }
      return value;
    }
    @Override
    public CelExpr.CelStruct.Entry.Builder setOptionalEntry(boolean optionalEntry) {
      this.optionalEntry = optionalEntry;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public CelExpr.CelStruct.Entry build() {
      if (set$0 != 3
          || this.fieldKey == null
          || this.value == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" id");
        }
        if (this.fieldKey == null) {
          missing.append(" fieldKey");
        }
        if (this.value == null) {
          missing.append(" value");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" optionalEntry");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelStruct_Entry(
          this.id,
          this.fieldKey,
          this.value,
          this.optionalEntry);
    }
  }

}
