package dev.cel.common.ast;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelList extends CelExpr.CelList {

  private final ImmutableList<CelExpr> elements;

  private final ImmutableList<Integer> optionalIndices;

  private AutoValue_CelExpr_CelList(
      ImmutableList<CelExpr> elements,
      ImmutableList<Integer> optionalIndices) {
    this.elements = elements;
    this.optionalIndices = optionalIndices;
  }

  @Override
  public ImmutableList<CelExpr> elements() {
    return elements;
  }

  @Override
  public ImmutableList<Integer> optionalIndices() {
    return optionalIndices;
  }

  @Override
  public String toString() {
    return "CelList{"
        + "elements=" + elements + ", "
        + "optionalIndices=" + optionalIndices
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelList) {
      CelExpr.CelList that = (CelExpr.CelList) o;
      return this.elements.equals(that.elements())
          && this.optionalIndices.equals(that.optionalIndices());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= elements.hashCode();
    h$ *= 1000003;
    h$ ^= optionalIndices.hashCode();
    return h$;
  }

  @Override
  CelExpr.CelList.Builder autoToBuilder() {
    return new AutoValue_CelExpr_CelList.Builder(this);
  }

  static final class Builder extends CelExpr.CelList.Builder {
    private ImmutableList<CelExpr> elements;
    private ImmutableList.Builder<Integer> optionalIndicesBuilder$;
    private ImmutableList<Integer> optionalIndices;
    Builder() {
    }
    Builder(CelExpr.CelList source) {
      this.elements = source.elements();
      this.optionalIndices = source.optionalIndices();
    }
    @Override
    CelExpr.CelList.Builder setElements(ImmutableList<CelExpr> elements) {
      if (elements == null) {
        throw new NullPointerException("Null elements");
      }
      this.elements = elements;
      return this;
    }
    @Override
    ImmutableList<CelExpr> elements() {
      if (this.elements == null) {
        throw new IllegalStateException("Property \"elements\" has not been set");
      }
      return elements;
    }
    @Override
    ImmutableList.Builder<Integer> optionalIndicesBuilder() {
      if (optionalIndicesBuilder$ == null) {
        if (optionalIndices == null) {
          optionalIndicesBuilder$ = ImmutableList.builder();
        } else {
          optionalIndicesBuilder$ = ImmutableList.builder();
          optionalIndicesBuilder$.addAll(optionalIndices);
          optionalIndices = null;
        }
      }
      return optionalIndicesBuilder$;
    }
    @Override
    CelExpr.CelList autoBuild() {
      if (optionalIndicesBuilder$ != null) {
        this.optionalIndices = optionalIndicesBuilder$.build();
      } else if (this.optionalIndices == null) {
        this.optionalIndices = ImmutableList.of();
      }
      if (this.elements == null) {
        String missing = " elements";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelList(
          this.elements,
          this.optionalIndices);
    }
  }

}
