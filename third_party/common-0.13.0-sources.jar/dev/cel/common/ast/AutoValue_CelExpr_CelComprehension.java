package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelComprehension extends CelExpr.CelComprehension {

  private final String iterVar;

  private final String iterVar2;

  private final CelExpr iterRange;

  private final String accuVar;

  private final CelExpr accuInit;

  private final CelExpr loopCondition;

  private final CelExpr loopStep;

  private final CelExpr result;

  private AutoValue_CelExpr_CelComprehension(
      String iterVar,
      String iterVar2,
      CelExpr iterRange,
      String accuVar,
      CelExpr accuInit,
      CelExpr loopCondition,
      CelExpr loopStep,
      CelExpr result) {
    this.iterVar = iterVar;
    this.iterVar2 = iterVar2;
    this.iterRange = iterRange;
    this.accuVar = accuVar;
    this.accuInit = accuInit;
    this.loopCondition = loopCondition;
    this.loopStep = loopStep;
    this.result = result;
  }

  @Override
  public String iterVar() {
    return iterVar;
  }

  @Override
  public String iterVar2() {
    return iterVar2;
  }

  @Override
  public CelExpr iterRange() {
    return iterRange;
  }

  @Override
  public String accuVar() {
    return accuVar;
  }

  @Override
  public CelExpr accuInit() {
    return accuInit;
  }

  @Override
  public CelExpr loopCondition() {
    return loopCondition;
  }

  @Override
  public CelExpr loopStep() {
    return loopStep;
  }

  @Override
  public CelExpr result() {
    return result;
  }

  @Override
  public String toString() {
    return "CelComprehension{"
        + "iterVar=" + iterVar + ", "
        + "iterVar2=" + iterVar2 + ", "
        + "iterRange=" + iterRange + ", "
        + "accuVar=" + accuVar + ", "
        + "accuInit=" + accuInit + ", "
        + "loopCondition=" + loopCondition + ", "
        + "loopStep=" + loopStep + ", "
        + "result=" + result
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelComprehension) {
      CelExpr.CelComprehension that = (CelExpr.CelComprehension) o;
      return this.iterVar.equals(that.iterVar())
          && this.iterVar2.equals(that.iterVar2())
          && this.iterRange.equals(that.iterRange())
          && this.accuVar.equals(that.accuVar())
          && this.accuInit.equals(that.accuInit())
          && this.loopCondition.equals(that.loopCondition())
          && this.loopStep.equals(that.loopStep())
          && this.result.equals(that.result());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= iterVar.hashCode();
    h$ *= 1000003;
    h$ ^= iterVar2.hashCode();
    h$ *= 1000003;
    h$ ^= iterRange.hashCode();
    h$ *= 1000003;
    h$ ^= accuVar.hashCode();
    h$ *= 1000003;
    h$ ^= accuInit.hashCode();
    h$ *= 1000003;
    h$ ^= loopCondition.hashCode();
    h$ *= 1000003;
    h$ ^= loopStep.hashCode();
    h$ *= 1000003;
    h$ ^= result.hashCode();
    return h$;
  }

  @Override
  public CelExpr.CelComprehension.Builder toBuilder() {
    return new AutoValue_CelExpr_CelComprehension.Builder(this);
  }

  static final class Builder extends CelExpr.CelComprehension.Builder {
    private String iterVar;
    private String iterVar2;
    private CelExpr iterRange;
    private String accuVar;
    private CelExpr accuInit;
    private CelExpr loopCondition;
    private CelExpr loopStep;
    private CelExpr result;
    Builder() {
    }
    Builder(CelExpr.CelComprehension source) {
      this.iterVar = source.iterVar();
      this.iterVar2 = source.iterVar2();
      this.iterRange = source.iterRange();
      this.accuVar = source.accuVar();
      this.accuInit = source.accuInit();
      this.loopCondition = source.loopCondition();
      this.loopStep = source.loopStep();
      this.result = source.result();
    }
    @Override
    public CelExpr.CelComprehension.Builder setIterVar(String iterVar) {
      if (iterVar == null) {
        throw new NullPointerException("Null iterVar");
      }
      this.iterVar = iterVar;
      return this;
    }
    @Override
    public CelExpr.CelComprehension.Builder setIterVar2(String iterVar2) {
      if (iterVar2 == null) {
        throw new NullPointerException("Null iterVar2");
      }
      this.iterVar2 = iterVar2;
      return this;
    }
    @Override
    public CelExpr.CelComprehension.Builder setIterRange(CelExpr iterRange) {
      if (iterRange == null) {
        throw new NullPointerException("Null iterRange");
      }
      this.iterRange = iterRange;
      return this;
    }
    @Override
    public CelExpr iterRange() {
      if (this.iterRange == null) {
        throw new IllegalStateException("Property \"iterRange\" has not been set");
      }
      return iterRange;
    }
    @Override
    public CelExpr.CelComprehension.Builder setAccuVar(String accuVar) {
      if (accuVar == null) {
        throw new NullPointerException("Null accuVar");
      }
      this.accuVar = accuVar;
      return this;
    }
    @Override
    public String accuVar() {
      if (this.accuVar == null) {
        throw new IllegalStateException("Property \"accuVar\" has not been set");
      }
      return accuVar;
    }
    @Override
    public CelExpr.CelComprehension.Builder setAccuInit(CelExpr accuInit) {
      if (accuInit == null) {
        throw new NullPointerException("Null accuInit");
      }
      this.accuInit = accuInit;
      return this;
    }
    @Override
    public CelExpr accuInit() {
      if (this.accuInit == null) {
        throw new IllegalStateException("Property \"accuInit\" has not been set");
      }
      return accuInit;
    }
    @Override
    public CelExpr.CelComprehension.Builder setLoopCondition(CelExpr loopCondition) {
      if (loopCondition == null) {
        throw new NullPointerException("Null loopCondition");
      }
      this.loopCondition = loopCondition;
      return this;
    }
    @Override
    public CelExpr loopCondition() {
      if (this.loopCondition == null) {
        throw new IllegalStateException("Property \"loopCondition\" has not been set");
      }
      return loopCondition;
    }
    @Override
    public CelExpr.CelComprehension.Builder setLoopStep(CelExpr loopStep) {
      if (loopStep == null) {
        throw new NullPointerException("Null loopStep");
      }
      this.loopStep = loopStep;
      return this;
    }
    @Override
    public CelExpr loopStep() {
      if (this.loopStep == null) {
        throw new IllegalStateException("Property \"loopStep\" has not been set");
      }
      return loopStep;
    }
    @Override
    public CelExpr.CelComprehension.Builder setResult(CelExpr result) {
      if (result == null) {
        throw new NullPointerException("Null result");
      }
      this.result = result;
      return this;
    }
    @Override
    public CelExpr result() {
      if (this.result == null) {
        throw new IllegalStateException("Property \"result\" has not been set");
      }
      return result;
    }
    @Override
    public CelExpr.CelComprehension build() {
      if (this.iterVar == null
          || this.iterVar2 == null
          || this.iterRange == null
          || this.accuVar == null
          || this.accuInit == null
          || this.loopCondition == null
          || this.loopStep == null
          || this.result == null) {
        StringBuilder missing = new StringBuilder();
        if (this.iterVar == null) {
          missing.append(" iterVar");
        }
        if (this.iterVar2 == null) {
          missing.append(" iterVar2");
        }
        if (this.iterRange == null) {
          missing.append(" iterRange");
        }
        if (this.accuVar == null) {
          missing.append(" accuVar");
        }
        if (this.accuInit == null) {
          missing.append(" accuInit");
        }
        if (this.loopCondition == null) {
          missing.append(" loopCondition");
        }
        if (this.loopStep == null) {
          missing.append(" loopStep");
        }
        if (this.result == null) {
          missing.append(" result");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelComprehension(
          this.iterVar,
          this.iterVar2,
          this.iterRange,
          this.accuVar,
          this.accuInit,
          this.loopCondition,
          this.loopStep,
          this.result);
    }
  }

}
