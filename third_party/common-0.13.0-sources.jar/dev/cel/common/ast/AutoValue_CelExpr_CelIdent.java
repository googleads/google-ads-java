package dev.cel.common.ast;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelExpr_CelIdent extends CelExpr.CelIdent {

  private final String name;

  private AutoValue_CelExpr_CelIdent(
      String name) {
    this.name = name;
  }

  @Override
  public String name() {
    return name;
  }

  @Override
  public String toString() {
    return "CelIdent{"
        + "name=" + name
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelExpr.CelIdent) {
      CelExpr.CelIdent that = (CelExpr.CelIdent) o;
      return this.name.equals(that.name());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= name.hashCode();
    return h$;
  }

  @Override
  public CelExpr.CelIdent.Builder toBuilder() {
    return new AutoValue_CelExpr_CelIdent.Builder(this);
  }

  static final class Builder extends CelExpr.CelIdent.Builder {
    private String name;
    Builder() {
    }
    Builder(CelExpr.CelIdent source) {
      this.name = source.name();
    }
    @Override
    public CelExpr.CelIdent.Builder setName(String name) {
      if (name == null) {
        throw new NullPointerException("Null name");
      }
      this.name = name;
      return this;
    }
    @Override
    public CelExpr.CelIdent build() {
      if (this.name == null) {
        String missing = " name";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelExpr_CelIdent(
          this.name);
    }
  }

}
