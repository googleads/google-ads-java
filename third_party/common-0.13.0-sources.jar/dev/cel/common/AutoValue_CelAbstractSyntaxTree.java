package dev.cel.common;

import com.google.common.collect.ImmutableMap;
import dev.cel.common.ast.CelExpr;
import dev.cel.common.ast.CelReference;
import dev.cel.common.types.CelType;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelAbstractSyntaxTree extends CelAbstractSyntaxTree {

  private final CelSource celSource;

  private final CelExpr celExpr;

  private final ImmutableMap<Long, CelReference> references;

  private final ImmutableMap<Long, CelType> types;

  AutoValue_CelAbstractSyntaxTree(
      CelSource celSource,
      CelExpr celExpr,
      ImmutableMap<Long, CelReference> references,
      ImmutableMap<Long, CelType> types) {
    if (celSource == null) {
      throw new NullPointerException("Null celSource");
    }
    this.celSource = celSource;
    if (celExpr == null) {
      throw new NullPointerException("Null celExpr");
    }
    this.celExpr = celExpr;
    if (references == null) {
      throw new NullPointerException("Null references");
    }
    this.references = references;
    if (types == null) {
      throw new NullPointerException("Null types");
    }
    this.types = types;
  }

  @Override
  CelSource celSource() {
    return celSource;
  }

  @Override
  CelExpr celExpr() {
    return celExpr;
  }

  @Override
  ImmutableMap<Long, CelReference> references() {
    return references;
  }

  @Override
  ImmutableMap<Long, CelType> types() {
    return types;
  }

  @Override
  public String toString() {
    return "CelAbstractSyntaxTree{"
        + "celSource=" + celSource + ", "
        + "celExpr=" + celExpr + ", "
        + "references=" + references + ", "
        + "types=" + types
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelAbstractSyntaxTree) {
      CelAbstractSyntaxTree that = (CelAbstractSyntaxTree) o;
      return this.celSource.equals(that.celSource())
          && this.celExpr.equals(that.celExpr())
          && this.references.equals(that.references())
          && this.types.equals(that.types());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= celSource.hashCode();
    h$ *= 1000003;
    h$ ^= celExpr.hashCode();
    h$ *= 1000003;
    h$ ^= references.hashCode();
    h$ *= 1000003;
    h$ ^= types.hashCode();
    return h$;
  }

}
