package dev.cel.common;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelOptions extends CelOptions {

  private final boolean enableReservedIds;

  private final boolean enableOptionalSyntax;

  private final int maxExpressionCodePointSize;

  private final int maxParseErrorRecoveryLimit;

  private final int maxParseRecursionDepth;

  private final boolean populateMacroCalls;

  private final boolean retainRepeatedUnaryOperators;

  private final boolean retainUnbalancedLogicalExpressions;

  private final boolean enableHiddenAccumulatorVar;

  private final boolean enableQuotedIdentifierSyntax;

  private final boolean enableCompileTimeOverloadResolution;

  private final boolean enableHomogeneousLiterals;

  private final boolean enableTimestampEpoch;

  private final boolean enableHeterogeneousNumericComparisons;

  private final boolean enableNamespacedDeclarations;

  private final boolean enableJsonFieldNames;

  private final boolean disableCelStandardEquality;

  private final boolean enableShortCircuiting;

  private final boolean enableRegexPartialMatch;

  private final boolean enableUnsignedComparisonAndArithmeticIsUnsigned;

  private final boolean enableUnsignedLongs;

  private final boolean enableProtoDifferencerEquality;

  private final boolean errorOnDuplicateMapKeys;

  private final boolean errorOnIntWrap;

  private final boolean resolveTypeDependencies;

  private final boolean enableUnknownTracking;

  private final boolean enableCelValue;

  private final int comprehensionMaxIterations;

  private final boolean evaluateCanonicalTypesToNativeValues;

  private final boolean unwrapWellKnownTypesOnFunctionDispatch;

  private final CelOptions.ProtoUnsetFieldOptions fromProtoUnsetFieldOption;

  private final boolean enableComprehension;

  private final int maxRegexProgramSize;

  private AutoValue_CelOptions(
      boolean enableReservedIds,
      boolean enableOptionalSyntax,
      int maxExpressionCodePointSize,
      int maxParseErrorRecoveryLimit,
      int maxParseRecursionDepth,
      boolean populateMacroCalls,
      boolean retainRepeatedUnaryOperators,
      boolean retainUnbalancedLogicalExpressions,
      boolean enableHiddenAccumulatorVar,
      boolean enableQuotedIdentifierSyntax,
      boolean enableCompileTimeOverloadResolution,
      boolean enableHomogeneousLiterals,
      boolean enableTimestampEpoch,
      boolean enableHeterogeneousNumericComparisons,
      boolean enableNamespacedDeclarations,
      boolean enableJsonFieldNames,
      boolean disableCelStandardEquality,
      boolean enableShortCircuiting,
      boolean enableRegexPartialMatch,
      boolean enableUnsignedComparisonAndArithmeticIsUnsigned,
      boolean enableUnsignedLongs,
      boolean enableProtoDifferencerEquality,
      boolean errorOnDuplicateMapKeys,
      boolean errorOnIntWrap,
      boolean resolveTypeDependencies,
      boolean enableUnknownTracking,
      boolean enableCelValue,
      int comprehensionMaxIterations,
      boolean evaluateCanonicalTypesToNativeValues,
      boolean unwrapWellKnownTypesOnFunctionDispatch,
      CelOptions.ProtoUnsetFieldOptions fromProtoUnsetFieldOption,
      boolean enableComprehension,
      int maxRegexProgramSize) {
    this.enableReservedIds = enableReservedIds;
    this.enableOptionalSyntax = enableOptionalSyntax;
    this.maxExpressionCodePointSize = maxExpressionCodePointSize;
    this.maxParseErrorRecoveryLimit = maxParseErrorRecoveryLimit;
    this.maxParseRecursionDepth = maxParseRecursionDepth;
    this.populateMacroCalls = populateMacroCalls;
    this.retainRepeatedUnaryOperators = retainRepeatedUnaryOperators;
    this.retainUnbalancedLogicalExpressions = retainUnbalancedLogicalExpressions;
    this.enableHiddenAccumulatorVar = enableHiddenAccumulatorVar;
    this.enableQuotedIdentifierSyntax = enableQuotedIdentifierSyntax;
    this.enableCompileTimeOverloadResolution = enableCompileTimeOverloadResolution;
    this.enableHomogeneousLiterals = enableHomogeneousLiterals;
    this.enableTimestampEpoch = enableTimestampEpoch;
    this.enableHeterogeneousNumericComparisons = enableHeterogeneousNumericComparisons;
    this.enableNamespacedDeclarations = enableNamespacedDeclarations;
    this.enableJsonFieldNames = enableJsonFieldNames;
    this.disableCelStandardEquality = disableCelStandardEquality;
    this.enableShortCircuiting = enableShortCircuiting;
    this.enableRegexPartialMatch = enableRegexPartialMatch;
    this.enableUnsignedComparisonAndArithmeticIsUnsigned = enableUnsignedComparisonAndArithmeticIsUnsigned;
    this.enableUnsignedLongs = enableUnsignedLongs;
    this.enableProtoDifferencerEquality = enableProtoDifferencerEquality;
    this.errorOnDuplicateMapKeys = errorOnDuplicateMapKeys;
    this.errorOnIntWrap = errorOnIntWrap;
    this.resolveTypeDependencies = resolveTypeDependencies;
    this.enableUnknownTracking = enableUnknownTracking;
    this.enableCelValue = enableCelValue;
    this.comprehensionMaxIterations = comprehensionMaxIterations;
    this.evaluateCanonicalTypesToNativeValues = evaluateCanonicalTypesToNativeValues;
    this.unwrapWellKnownTypesOnFunctionDispatch = unwrapWellKnownTypesOnFunctionDispatch;
    this.fromProtoUnsetFieldOption = fromProtoUnsetFieldOption;
    this.enableComprehension = enableComprehension;
    this.maxRegexProgramSize = maxRegexProgramSize;
  }

  @Override
  public boolean enableReservedIds() {
    return enableReservedIds;
  }

  @Override
  public boolean enableOptionalSyntax() {
    return enableOptionalSyntax;
  }

  @Override
  public int maxExpressionCodePointSize() {
    return maxExpressionCodePointSize;
  }

  @Override
  public int maxParseErrorRecoveryLimit() {
    return maxParseErrorRecoveryLimit;
  }

  @Override
  public int maxParseRecursionDepth() {
    return maxParseRecursionDepth;
  }

  @Override
  public boolean populateMacroCalls() {
    return populateMacroCalls;
  }

  @Override
  public boolean retainRepeatedUnaryOperators() {
    return retainRepeatedUnaryOperators;
  }

  @Override
  public boolean retainUnbalancedLogicalExpressions() {
    return retainUnbalancedLogicalExpressions;
  }

  @Override
  public boolean enableHiddenAccumulatorVar() {
    return enableHiddenAccumulatorVar;
  }

  @Override
  public boolean enableQuotedIdentifierSyntax() {
    return enableQuotedIdentifierSyntax;
  }

  @Override
  public boolean enableCompileTimeOverloadResolution() {
    return enableCompileTimeOverloadResolution;
  }

  @Override
  public boolean enableHomogeneousLiterals() {
    return enableHomogeneousLiterals;
  }

  @Override
  public boolean enableTimestampEpoch() {
    return enableTimestampEpoch;
  }

  @Override
  public boolean enableHeterogeneousNumericComparisons() {
    return enableHeterogeneousNumericComparisons;
  }

  @Override
  public boolean enableNamespacedDeclarations() {
    return enableNamespacedDeclarations;
  }

  @Override
  public boolean enableJsonFieldNames() {
    return enableJsonFieldNames;
  }

  @Override
  public boolean disableCelStandardEquality() {
    return disableCelStandardEquality;
  }

  @Override
  public boolean enableShortCircuiting() {
    return enableShortCircuiting;
  }

  @Override
  public boolean enableRegexPartialMatch() {
    return enableRegexPartialMatch;
  }

  @Override
  public boolean enableUnsignedComparisonAndArithmeticIsUnsigned() {
    return enableUnsignedComparisonAndArithmeticIsUnsigned;
  }

  @Override
  public boolean enableUnsignedLongs() {
    return enableUnsignedLongs;
  }

  @Override
  public boolean enableProtoDifferencerEquality() {
    return enableProtoDifferencerEquality;
  }

  @Override
  public boolean errorOnDuplicateMapKeys() {
    return errorOnDuplicateMapKeys;
  }

  @Override
  public boolean errorOnIntWrap() {
    return errorOnIntWrap;
  }

  @Override
  public boolean resolveTypeDependencies() {
    return resolveTypeDependencies;
  }

  @Override
  public boolean enableUnknownTracking() {
    return enableUnknownTracking;
  }

  @Override
  public boolean enableCelValue() {
    return enableCelValue;
  }

  @Override
  public int comprehensionMaxIterations() {
    return comprehensionMaxIterations;
  }

  @Override
  public boolean evaluateCanonicalTypesToNativeValues() {
    return evaluateCanonicalTypesToNativeValues;
  }

  @Override
  public boolean unwrapWellKnownTypesOnFunctionDispatch() {
    return unwrapWellKnownTypesOnFunctionDispatch;
  }

  @Override
  public CelOptions.ProtoUnsetFieldOptions fromProtoUnsetFieldOption() {
    return fromProtoUnsetFieldOption;
  }

  @Override
  public boolean enableComprehension() {
    return enableComprehension;
  }

  @Override
  public int maxRegexProgramSize() {
    return maxRegexProgramSize;
  }

  @Override
  public String toString() {
    return "CelOptions{"
        + "enableReservedIds=" + enableReservedIds + ", "
        + "enableOptionalSyntax=" + enableOptionalSyntax + ", "
        + "maxExpressionCodePointSize=" + maxExpressionCodePointSize + ", "
        + "maxParseErrorRecoveryLimit=" + maxParseErrorRecoveryLimit + ", "
        + "maxParseRecursionDepth=" + maxParseRecursionDepth + ", "
        + "populateMacroCalls=" + populateMacroCalls + ", "
        + "retainRepeatedUnaryOperators=" + retainRepeatedUnaryOperators + ", "
        + "retainUnbalancedLogicalExpressions=" + retainUnbalancedLogicalExpressions + ", "
        + "enableHiddenAccumulatorVar=" + enableHiddenAccumulatorVar + ", "
        + "enableQuotedIdentifierSyntax=" + enableQuotedIdentifierSyntax + ", "
        + "enableCompileTimeOverloadResolution=" + enableCompileTimeOverloadResolution + ", "
        + "enableHomogeneousLiterals=" + enableHomogeneousLiterals + ", "
        + "enableTimestampEpoch=" + enableTimestampEpoch + ", "
        + "enableHeterogeneousNumericComparisons=" + enableHeterogeneousNumericComparisons + ", "
        + "enableNamespacedDeclarations=" + enableNamespacedDeclarations + ", "
        + "enableJsonFieldNames=" + enableJsonFieldNames + ", "
        + "disableCelStandardEquality=" + disableCelStandardEquality + ", "
        + "enableShortCircuiting=" + enableShortCircuiting + ", "
        + "enableRegexPartialMatch=" + enableRegexPartialMatch + ", "
        + "enableUnsignedComparisonAndArithmeticIsUnsigned=" + enableUnsignedComparisonAndArithmeticIsUnsigned + ", "
        + "enableUnsignedLongs=" + enableUnsignedLongs + ", "
        + "enableProtoDifferencerEquality=" + enableProtoDifferencerEquality + ", "
        + "errorOnDuplicateMapKeys=" + errorOnDuplicateMapKeys + ", "
        + "errorOnIntWrap=" + errorOnIntWrap + ", "
        + "resolveTypeDependencies=" + resolveTypeDependencies + ", "
        + "enableUnknownTracking=" + enableUnknownTracking + ", "
        + "enableCelValue=" + enableCelValue + ", "
        + "comprehensionMaxIterations=" + comprehensionMaxIterations + ", "
        + "evaluateCanonicalTypesToNativeValues=" + evaluateCanonicalTypesToNativeValues + ", "
        + "unwrapWellKnownTypesOnFunctionDispatch=" + unwrapWellKnownTypesOnFunctionDispatch + ", "
        + "fromProtoUnsetFieldOption=" + fromProtoUnsetFieldOption + ", "
        + "enableComprehension=" + enableComprehension + ", "
        + "maxRegexProgramSize=" + maxRegexProgramSize
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelOptions) {
      CelOptions that = (CelOptions) o;
      return this.enableReservedIds == that.enableReservedIds()
          && this.enableOptionalSyntax == that.enableOptionalSyntax()
          && this.maxExpressionCodePointSize == that.maxExpressionCodePointSize()
          && this.maxParseErrorRecoveryLimit == that.maxParseErrorRecoveryLimit()
          && this.maxParseRecursionDepth == that.maxParseRecursionDepth()
          && this.populateMacroCalls == that.populateMacroCalls()
          && this.retainRepeatedUnaryOperators == that.retainRepeatedUnaryOperators()
          && this.retainUnbalancedLogicalExpressions == that.retainUnbalancedLogicalExpressions()
          && this.enableHiddenAccumulatorVar == that.enableHiddenAccumulatorVar()
          && this.enableQuotedIdentifierSyntax == that.enableQuotedIdentifierSyntax()
          && this.enableCompileTimeOverloadResolution == that.enableCompileTimeOverloadResolution()
          && this.enableHomogeneousLiterals == that.enableHomogeneousLiterals()
          && this.enableTimestampEpoch == that.enableTimestampEpoch()
          && this.enableHeterogeneousNumericComparisons == that.enableHeterogeneousNumericComparisons()
          && this.enableNamespacedDeclarations == that.enableNamespacedDeclarations()
          && this.enableJsonFieldNames == that.enableJsonFieldNames()
          && this.disableCelStandardEquality == that.disableCelStandardEquality()
          && this.enableShortCircuiting == that.enableShortCircuiting()
          && this.enableRegexPartialMatch == that.enableRegexPartialMatch()
          && this.enableUnsignedComparisonAndArithmeticIsUnsigned == that.enableUnsignedComparisonAndArithmeticIsUnsigned()
          && this.enableUnsignedLongs == that.enableUnsignedLongs()
          && this.enableProtoDifferencerEquality == that.enableProtoDifferencerEquality()
          && this.errorOnDuplicateMapKeys == that.errorOnDuplicateMapKeys()
          && this.errorOnIntWrap == that.errorOnIntWrap()
          && this.resolveTypeDependencies == that.resolveTypeDependencies()
          && this.enableUnknownTracking == that.enableUnknownTracking()
          && this.enableCelValue == that.enableCelValue()
          && this.comprehensionMaxIterations == that.comprehensionMaxIterations()
          && this.evaluateCanonicalTypesToNativeValues == that.evaluateCanonicalTypesToNativeValues()
          && this.unwrapWellKnownTypesOnFunctionDispatch == that.unwrapWellKnownTypesOnFunctionDispatch()
          && this.fromProtoUnsetFieldOption.equals(that.fromProtoUnsetFieldOption())
          && this.enableComprehension == that.enableComprehension()
          && this.maxRegexProgramSize == that.maxRegexProgramSize();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= enableReservedIds ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableOptionalSyntax ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= maxExpressionCodePointSize;
    h$ *= 1000003;
    h$ ^= maxParseErrorRecoveryLimit;
    h$ *= 1000003;
    h$ ^= maxParseRecursionDepth;
    h$ *= 1000003;
    h$ ^= populateMacroCalls ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= retainRepeatedUnaryOperators ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= retainUnbalancedLogicalExpressions ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableHiddenAccumulatorVar ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableQuotedIdentifierSyntax ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableCompileTimeOverloadResolution ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableHomogeneousLiterals ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableTimestampEpoch ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableHeterogeneousNumericComparisons ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableNamespacedDeclarations ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableJsonFieldNames ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= disableCelStandardEquality ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableShortCircuiting ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableRegexPartialMatch ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableUnsignedComparisonAndArithmeticIsUnsigned ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableUnsignedLongs ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableProtoDifferencerEquality ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= errorOnDuplicateMapKeys ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= errorOnIntWrap ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= resolveTypeDependencies ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableUnknownTracking ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= enableCelValue ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= comprehensionMaxIterations;
    h$ *= 1000003;
    h$ ^= evaluateCanonicalTypesToNativeValues ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= unwrapWellKnownTypesOnFunctionDispatch ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= fromProtoUnsetFieldOption.hashCode();
    h$ *= 1000003;
    h$ ^= enableComprehension ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= maxRegexProgramSize;
    return h$;
  }

  @Override
  public CelOptions.Builder toBuilder() {
    return new AutoValue_CelOptions.Builder(this);
  }

  static final class Builder extends CelOptions.Builder {
    private boolean enableReservedIds;
    private boolean enableOptionalSyntax;
    private int maxExpressionCodePointSize;
    private int maxParseErrorRecoveryLimit;
    private int maxParseRecursionDepth;
    private boolean populateMacroCalls;
    private boolean retainRepeatedUnaryOperators;
    private boolean retainUnbalancedLogicalExpressions;
    private boolean enableHiddenAccumulatorVar;
    private boolean enableQuotedIdentifierSyntax;
    private boolean enableCompileTimeOverloadResolution;
    private boolean enableHomogeneousLiterals;
    private boolean enableTimestampEpoch;
    private boolean enableHeterogeneousNumericComparisons;
    private boolean enableNamespacedDeclarations;
    private boolean enableJsonFieldNames;
    private boolean disableCelStandardEquality;
    private boolean enableShortCircuiting;
    private boolean enableRegexPartialMatch;
    private boolean enableUnsignedComparisonAndArithmeticIsUnsigned;
    private boolean enableUnsignedLongs;
    private boolean enableProtoDifferencerEquality;
    private boolean errorOnDuplicateMapKeys;
    private boolean errorOnIntWrap;
    private boolean resolveTypeDependencies;
    private boolean enableUnknownTracking;
    private boolean enableCelValue;
    private int comprehensionMaxIterations;
    private boolean evaluateCanonicalTypesToNativeValues;
    private boolean unwrapWellKnownTypesOnFunctionDispatch;
    private CelOptions.ProtoUnsetFieldOptions fromProtoUnsetFieldOption;
    private boolean enableComprehension;
    private int maxRegexProgramSize;
    private int set$0;
    Builder() {
    }
    Builder(CelOptions source) {
      this.enableReservedIds = source.enableReservedIds();
      this.enableOptionalSyntax = source.enableOptionalSyntax();
      this.maxExpressionCodePointSize = source.maxExpressionCodePointSize();
      this.maxParseErrorRecoveryLimit = source.maxParseErrorRecoveryLimit();
      this.maxParseRecursionDepth = source.maxParseRecursionDepth();
      this.populateMacroCalls = source.populateMacroCalls();
      this.retainRepeatedUnaryOperators = source.retainRepeatedUnaryOperators();
      this.retainUnbalancedLogicalExpressions = source.retainUnbalancedLogicalExpressions();
      this.enableHiddenAccumulatorVar = source.enableHiddenAccumulatorVar();
      this.enableQuotedIdentifierSyntax = source.enableQuotedIdentifierSyntax();
      this.enableCompileTimeOverloadResolution = source.enableCompileTimeOverloadResolution();
      this.enableHomogeneousLiterals = source.enableHomogeneousLiterals();
      this.enableTimestampEpoch = source.enableTimestampEpoch();
      this.enableHeterogeneousNumericComparisons = source.enableHeterogeneousNumericComparisons();
      this.enableNamespacedDeclarations = source.enableNamespacedDeclarations();
      this.enableJsonFieldNames = source.enableJsonFieldNames();
      this.disableCelStandardEquality = source.disableCelStandardEquality();
      this.enableShortCircuiting = source.enableShortCircuiting();
      this.enableRegexPartialMatch = source.enableRegexPartialMatch();
      this.enableUnsignedComparisonAndArithmeticIsUnsigned = source.enableUnsignedComparisonAndArithmeticIsUnsigned();
      this.enableUnsignedLongs = source.enableUnsignedLongs();
      this.enableProtoDifferencerEquality = source.enableProtoDifferencerEquality();
      this.errorOnDuplicateMapKeys = source.errorOnDuplicateMapKeys();
      this.errorOnIntWrap = source.errorOnIntWrap();
      this.resolveTypeDependencies = source.resolveTypeDependencies();
      this.enableUnknownTracking = source.enableUnknownTracking();
      this.enableCelValue = source.enableCelValue();
      this.comprehensionMaxIterations = source.comprehensionMaxIterations();
      this.evaluateCanonicalTypesToNativeValues = source.evaluateCanonicalTypesToNativeValues();
      this.unwrapWellKnownTypesOnFunctionDispatch = source.unwrapWellKnownTypesOnFunctionDispatch();
      this.fromProtoUnsetFieldOption = source.fromProtoUnsetFieldOption();
      this.enableComprehension = source.enableComprehension();
      this.maxRegexProgramSize = source.maxRegexProgramSize();
      set$0 = -1;
    }
    @Override
    public CelOptions.Builder enableReservedIds(boolean enableReservedIds) {
      this.enableReservedIds = enableReservedIds;
      set$0 |= 1;
      return this;
    }
    @Override
    public CelOptions.Builder enableOptionalSyntax(boolean enableOptionalSyntax) {
      this.enableOptionalSyntax = enableOptionalSyntax;
      set$0 |= 2;
      return this;
    }
    @Override
    public CelOptions.Builder maxExpressionCodePointSize(int maxExpressionCodePointSize) {
      this.maxExpressionCodePointSize = maxExpressionCodePointSize;
      set$0 |= 4;
      return this;
    }
    @Override
    public CelOptions.Builder maxParseErrorRecoveryLimit(int maxParseErrorRecoveryLimit) {
      this.maxParseErrorRecoveryLimit = maxParseErrorRecoveryLimit;
      set$0 |= 8;
      return this;
    }
    @Override
    public CelOptions.Builder maxParseRecursionDepth(int maxParseRecursionDepth) {
      this.maxParseRecursionDepth = maxParseRecursionDepth;
      set$0 |= 0x10;
      return this;
    }
    @Override
    public CelOptions.Builder populateMacroCalls(boolean populateMacroCalls) {
      this.populateMacroCalls = populateMacroCalls;
      set$0 |= 0x20;
      return this;
    }
    @Override
    public CelOptions.Builder retainRepeatedUnaryOperators(boolean retainRepeatedUnaryOperators) {
      this.retainRepeatedUnaryOperators = retainRepeatedUnaryOperators;
      set$0 |= 0x40;
      return this;
    }
    @Override
    public CelOptions.Builder retainUnbalancedLogicalExpressions(boolean retainUnbalancedLogicalExpressions) {
      this.retainUnbalancedLogicalExpressions = retainUnbalancedLogicalExpressions;
      set$0 |= 0x80;
      return this;
    }
    @Override
    public CelOptions.Builder enableHiddenAccumulatorVar(boolean enableHiddenAccumulatorVar) {
      this.enableHiddenAccumulatorVar = enableHiddenAccumulatorVar;
      set$0 |= 0x100;
      return this;
    }
    @Override
    public CelOptions.Builder enableQuotedIdentifierSyntax(boolean enableQuotedIdentifierSyntax) {
      this.enableQuotedIdentifierSyntax = enableQuotedIdentifierSyntax;
      set$0 |= 0x200;
      return this;
    }
    @Override
    public CelOptions.Builder enableCompileTimeOverloadResolution(boolean enableCompileTimeOverloadResolution) {
      this.enableCompileTimeOverloadResolution = enableCompileTimeOverloadResolution;
      set$0 |= 0x400;
      return this;
    }
    @Override
    public CelOptions.Builder enableHomogeneousLiterals(boolean enableHomogeneousLiterals) {
      this.enableHomogeneousLiterals = enableHomogeneousLiterals;
      set$0 |= 0x800;
      return this;
    }
    @Override
    public CelOptions.Builder enableTimestampEpoch(boolean enableTimestampEpoch) {
      this.enableTimestampEpoch = enableTimestampEpoch;
      set$0 |= 0x1000;
      return this;
    }
    @Override
    public CelOptions.Builder enableHeterogeneousNumericComparisons(boolean enableHeterogeneousNumericComparisons) {
      this.enableHeterogeneousNumericComparisons = enableHeterogeneousNumericComparisons;
      set$0 |= 0x2000;
      return this;
    }
    @Override
    public CelOptions.Builder enableNamespacedDeclarations(boolean enableNamespacedDeclarations) {
      this.enableNamespacedDeclarations = enableNamespacedDeclarations;
      set$0 |= 0x4000;
      return this;
    }
    @Override
    public CelOptions.Builder enableJsonFieldNames(boolean enableJsonFieldNames) {
      this.enableJsonFieldNames = enableJsonFieldNames;
      set$0 |= 0x8000;
      return this;
    }
    @Override
    public CelOptions.Builder disableCelStandardEquality(boolean disableCelStandardEquality) {
      this.disableCelStandardEquality = disableCelStandardEquality;
      set$0 |= 0x1_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableShortCircuiting(boolean enableShortCircuiting) {
      this.enableShortCircuiting = enableShortCircuiting;
      set$0 |= 0x2_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableRegexPartialMatch(boolean enableRegexPartialMatch) {
      this.enableRegexPartialMatch = enableRegexPartialMatch;
      set$0 |= 0x4_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableUnsignedComparisonAndArithmeticIsUnsigned(boolean enableUnsignedComparisonAndArithmeticIsUnsigned) {
      this.enableUnsignedComparisonAndArithmeticIsUnsigned = enableUnsignedComparisonAndArithmeticIsUnsigned;
      set$0 |= 0x8_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableUnsignedLongs(boolean enableUnsignedLongs) {
      this.enableUnsignedLongs = enableUnsignedLongs;
      set$0 |= 0x10_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableProtoDifferencerEquality(boolean enableProtoDifferencerEquality) {
      this.enableProtoDifferencerEquality = enableProtoDifferencerEquality;
      set$0 |= 0x20_0000;
      return this;
    }
    @Override
    public CelOptions.Builder errorOnDuplicateMapKeys(boolean errorOnDuplicateMapKeys) {
      this.errorOnDuplicateMapKeys = errorOnDuplicateMapKeys;
      set$0 |= 0x40_0000;
      return this;
    }
    @Override
    public CelOptions.Builder errorOnIntWrap(boolean errorOnIntWrap) {
      this.errorOnIntWrap = errorOnIntWrap;
      set$0 |= 0x80_0000;
      return this;
    }
    @Override
    public CelOptions.Builder resolveTypeDependencies(boolean resolveTypeDependencies) {
      this.resolveTypeDependencies = resolveTypeDependencies;
      set$0 |= 0x100_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableUnknownTracking(boolean enableUnknownTracking) {
      this.enableUnknownTracking = enableUnknownTracking;
      set$0 |= 0x200_0000;
      return this;
    }
    @Override
    public CelOptions.Builder enableCelValue(boolean enableCelValue) {
      this.enableCelValue = enableCelValue;
      set$0 |= 0x400_0000;
      return this;
    }
    @Override
    public CelOptions.Builder comprehensionMaxIterations(int comprehensionMaxIterations) {
      this.comprehensionMaxIterations = comprehensionMaxIterations;
      set$0 |= 0x800_0000;
      return this;
    }
    @Override
    public CelOptions.Builder evaluateCanonicalTypesToNativeValues(boolean evaluateCanonicalTypesToNativeValues) {
      this.evaluateCanonicalTypesToNativeValues = evaluateCanonicalTypesToNativeValues;
      set$0 |= 0x1000_0000;
      return this;
    }
    @Override
    public CelOptions.Builder unwrapWellKnownTypesOnFunctionDispatch(boolean unwrapWellKnownTypesOnFunctionDispatch) {
      this.unwrapWellKnownTypesOnFunctionDispatch = unwrapWellKnownTypesOnFunctionDispatch;
      set$0 |= 0x2000_0000;
      return this;
    }
    @Override
    public CelOptions.Builder fromProtoUnsetFieldOption(CelOptions.ProtoUnsetFieldOptions fromProtoUnsetFieldOption) {
      if (fromProtoUnsetFieldOption == null) {
        throw new NullPointerException("Null fromProtoUnsetFieldOption");
      }
      this.fromProtoUnsetFieldOption = fromProtoUnsetFieldOption;
      return this;
    }
    @Override
    public CelOptions.Builder enableComprehension(boolean enableComprehension) {
      this.enableComprehension = enableComprehension;
      set$0 |= 0x4000_0000;
      return this;
    }
    @Override
    public CelOptions.Builder maxRegexProgramSize(int maxRegexProgramSize) {
      this.maxRegexProgramSize = maxRegexProgramSize;
      set$0 |= 0x8000_0000;
      return this;
    }
    @Override
    public CelOptions build() {
      if (set$0 != -1
          || this.fromProtoUnsetFieldOption == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" enableReservedIds");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" enableOptionalSyntax");
        }
        if ((set$0 & 4) == 0) {
          missing.append(" maxExpressionCodePointSize");
        }
        if ((set$0 & 8) == 0) {
          missing.append(" maxParseErrorRecoveryLimit");
        }
        if ((set$0 & 0x10) == 0) {
          missing.append(" maxParseRecursionDepth");
        }
        if ((set$0 & 0x20) == 0) {
          missing.append(" populateMacroCalls");
        }
        if ((set$0 & 0x40) == 0) {
          missing.append(" retainRepeatedUnaryOperators");
        }
        if ((set$0 & 0x80) == 0) {
          missing.append(" retainUnbalancedLogicalExpressions");
        }
        if ((set$0 & 0x100) == 0) {
          missing.append(" enableHiddenAccumulatorVar");
        }
        if ((set$0 & 0x200) == 0) {
          missing.append(" enableQuotedIdentifierSyntax");
        }
        if ((set$0 & 0x400) == 0) {
          missing.append(" enableCompileTimeOverloadResolution");
        }
        if ((set$0 & 0x800) == 0) {
          missing.append(" enableHomogeneousLiterals");
        }
        if ((set$0 & 0x1000) == 0) {
          missing.append(" enableTimestampEpoch");
        }
        if ((set$0 & 0x2000) == 0) {
          missing.append(" enableHeterogeneousNumericComparisons");
        }
        if ((set$0 & 0x4000) == 0) {
          missing.append(" enableNamespacedDeclarations");
        }
        if ((set$0 & 0x8000) == 0) {
          missing.append(" enableJsonFieldNames");
        }
        if ((set$0 & 0x1_0000) == 0) {
          missing.append(" disableCelStandardEquality");
        }
        if ((set$0 & 0x2_0000) == 0) {
          missing.append(" enableShortCircuiting");
        }
        if ((set$0 & 0x4_0000) == 0) {
          missing.append(" enableRegexPartialMatch");
        }
        if ((set$0 & 0x8_0000) == 0) {
          missing.append(" enableUnsignedComparisonAndArithmeticIsUnsigned");
        }
        if ((set$0 & 0x10_0000) == 0) {
          missing.append(" enableUnsignedLongs");
        }
        if ((set$0 & 0x20_0000) == 0) {
          missing.append(" enableProtoDifferencerEquality");
        }
        if ((set$0 & 0x40_0000) == 0) {
          missing.append(" errorOnDuplicateMapKeys");
        }
        if ((set$0 & 0x80_0000) == 0) {
          missing.append(" errorOnIntWrap");
        }
        if ((set$0 & 0x100_0000) == 0) {
          missing.append(" resolveTypeDependencies");
        }
        if ((set$0 & 0x200_0000) == 0) {
          missing.append(" enableUnknownTracking");
        }
        if ((set$0 & 0x400_0000) == 0) {
          missing.append(" enableCelValue");
        }
        if ((set$0 & 0x800_0000) == 0) {
          missing.append(" comprehensionMaxIterations");
        }
        if ((set$0 & 0x1000_0000) == 0) {
          missing.append(" evaluateCanonicalTypesToNativeValues");
        }
        if ((set$0 & 0x2000_0000) == 0) {
          missing.append(" unwrapWellKnownTypesOnFunctionDispatch");
        }
        if (this.fromProtoUnsetFieldOption == null) {
          missing.append(" fromProtoUnsetFieldOption");
        }
        if ((set$0 & 0x4000_0000) == 0) {
          missing.append(" enableComprehension");
        }
        if ((set$0 & 0x8000_0000) == 0) {
          missing.append(" maxRegexProgramSize");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelOptions(
          this.enableReservedIds,
          this.enableOptionalSyntax,
          this.maxExpressionCodePointSize,
          this.maxParseErrorRecoveryLimit,
          this.maxParseRecursionDepth,
          this.populateMacroCalls,
          this.retainRepeatedUnaryOperators,
          this.retainUnbalancedLogicalExpressions,
          this.enableHiddenAccumulatorVar,
          this.enableQuotedIdentifierSyntax,
          this.enableCompileTimeOverloadResolution,
          this.enableHomogeneousLiterals,
          this.enableTimestampEpoch,
          this.enableHeterogeneousNumericComparisons,
          this.enableNamespacedDeclarations,
          this.enableJsonFieldNames,
          this.disableCelStandardEquality,
          this.enableShortCircuiting,
          this.enableRegexPartialMatch,
          this.enableUnsignedComparisonAndArithmeticIsUnsigned,
          this.enableUnsignedLongs,
          this.enableProtoDifferencerEquality,
          this.errorOnDuplicateMapKeys,
          this.errorOnIntWrap,
          this.resolveTypeDependencies,
          this.enableUnknownTracking,
          this.enableCelValue,
          this.comprehensionMaxIterations,
          this.evaluateCanonicalTypesToNativeValues,
          this.unwrapWellKnownTypesOnFunctionDispatch,
          this.fromProtoUnsetFieldOption,
          this.enableComprehension,
          this.maxRegexProgramSize);
    }
  }

}
