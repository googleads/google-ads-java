package dev.cel.common;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelContainer_AliasEntry extends CelContainer.AliasEntry {

  private final CelContainer.AliasKind kind;

  private final String qualifiedName;

  AutoValue_CelContainer_AliasEntry(
      CelContainer.AliasKind kind,
      String qualifiedName) {
    if (kind == null) {
      throw new NullPointerException("Null kind");
    }
    this.kind = kind;
    if (qualifiedName == null) {
      throw new NullPointerException("Null qualifiedName");
    }
    this.qualifiedName = qualifiedName;
  }

  @Override
  CelContainer.AliasKind kind() {
    return kind;
  }

  @Override
  String qualifiedName() {
    return qualifiedName;
  }

  @Override
  public String toString() {
    return "AliasEntry{"
        + "kind=" + kind + ", "
        + "qualifiedName=" + qualifiedName
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelContainer.AliasEntry) {
      CelContainer.AliasEntry that = (CelContainer.AliasEntry) o;
      return this.kind.equals(that.kind())
          && this.qualifiedName.equals(that.qualifiedName());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= kind.hashCode();
    h$ *= 1000003;
    h$ ^= qualifiedName.hashCode();
    return h$;
  }

}
