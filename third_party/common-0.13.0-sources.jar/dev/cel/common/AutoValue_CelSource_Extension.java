package dev.cel.common;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelSource_Extension extends CelSource.Extension {

  private final String id;

  private final CelSource.Extension.Version version;

  private final ImmutableList<CelSource.Extension.Component> affectedComponents;

  AutoValue_CelSource_Extension(
      String id,
      CelSource.Extension.Version version,
      ImmutableList<CelSource.Extension.Component> affectedComponents) {
    if (id == null) {
      throw new NullPointerException("Null id");
    }
    this.id = id;
    if (version == null) {
      throw new NullPointerException("Null version");
    }
    this.version = version;
    if (affectedComponents == null) {
      throw new NullPointerException("Null affectedComponents");
    }
    this.affectedComponents = affectedComponents;
  }

  @Override
  String id() {
    return id;
  }

  @Override
  CelSource.Extension.Version version() {
    return version;
  }

  @Override
  ImmutableList<CelSource.Extension.Component> affectedComponents() {
    return affectedComponents;
  }

  @Override
  public String toString() {
    return "Extension{"
        + "id=" + id + ", "
        + "version=" + version + ", "
        + "affectedComponents=" + affectedComponents
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelSource.Extension) {
      CelSource.Extension that = (CelSource.Extension) o;
      return this.id.equals(that.id())
          && this.version.equals(that.version())
          && this.affectedComponents.equals(that.affectedComponents());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= id.hashCode();
    h$ *= 1000003;
    h$ ^= version.hashCode();
    h$ *= 1000003;
    h$ ^= affectedComponents.hashCode();
    return h$;
  }

}
