package dev.cel.common;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelSource_Extension_Version extends CelSource.Extension.Version {

  private final long major;

  private final long minor;

  AutoValue_CelSource_Extension_Version(
      long major,
      long minor) {
    this.major = major;
    this.minor = minor;
  }

  @Override
  long major() {
    return major;
  }

  @Override
  long minor() {
    return minor;
  }

  @Override
  public String toString() {
    return "Version{"
        + "major=" + major + ", "
        + "minor=" + minor
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelSource.Extension.Version) {
      CelSource.Extension.Version that = (CelSource.Extension.Version) o;
      return this.major == that.major()
          && this.minor == that.minor();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((major >>> 32) ^ major);
    h$ *= 1000003;
    h$ ^= (int) ((minor >>> 32) ^ minor);
    return h$;
  }

}
