/*
 * Copyright 2023 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.internal;

import io.grpc.NameResolver;
import io.grpc.NameResolver.Args;
import io.grpc.NameResolverProvider;
import io.grpc.Uri;
import java.net.URI;

public class NameResolverFactoryToProviderFacade extends NameResolverProvider {

  private NameResolver.Factory factory;

  NameResolverFactoryToProviderFacade(NameResolver.Factory factory) {
    this.factory = factory;
  }

  @Override
  public NameResolver newNameResolver(URI targetUri, Args args) {
    return factory.newNameResolver(targetUri, args);
  }

  @Override
  public NameResolver newNameResolver(Uri targetUri, Args args) {
    return factory.newNameResolver(targetUri, args);
  }

  @Override
  public String getDefaultScheme() {
    return factory.getDefaultScheme();
  }

  @Override
  protected boolean isAvailable() {
    return true;
  }

  @Override
  protected int priority() {
    return 5;
  }
}
