package com.google.api.gax.tracing;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_SpanName extends SpanName {

  private final String clientName;

  private final String methodName;

  AutoValue_SpanName(
      String clientName,
      String methodName) {
    if (clientName == null) {
      throw new NullPointerException("Null clientName");
    }
    this.clientName = clientName;
    if (methodName == null) {
      throw new NullPointerException("Null methodName");
    }
    this.methodName = methodName;
  }

  @Override
  public String getClientName() {
    return clientName;
  }

  @Override
  public String getMethodName() {
    return methodName;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof SpanName) {
      SpanName that = (SpanName) o;
      return this.clientName.equals(that.getClientName())
          && this.methodName.equals(that.getMethodName());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= clientName.hashCode();
    h$ *= 1000003;
    h$ ^= methodName.hashCode();
    return h$;
  }

}
