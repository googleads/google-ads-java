package com.google.api.gax.tracing;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_MethodName extends MethodName {

  private final String serviceName;

  private final String methodName;

  AutoValue_MethodName(
      String serviceName,
      String methodName) {
    if (serviceName == null) {
      throw new NullPointerException("Null serviceName");
    }
    this.serviceName = serviceName;
    if (methodName == null) {
      throw new NullPointerException("Null methodName");
    }
    this.methodName = methodName;
  }

  @Override
  public String getServiceName() {
    return serviceName;
  }

  @Override
  public String getMethodName() {
    return methodName;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof MethodName) {
      MethodName that = (MethodName) o;
      return this.serviceName.equals(that.getServiceName())
          && this.methodName.equals(that.getMethodName());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= serviceName.hashCode();
    h$ *= 1000003;
    h$ ^= methodName.hashCode();
    return h$;
  }

}
