package com.google.api.gax.httpjson;

import com.google.api.gax.tracing.ApiTracer;
import com.google.auth.Credentials;
import com.google.protobuf.TypeRegistry;
import java.time.Duration;
import java.time.Instant;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_HttpJsonCallOptions extends HttpJsonCallOptions {

  private final @Nullable Duration timeoutDuration;

  private final @Nullable Instant deadlineInstant;

  private final @Nullable Credentials credentials;

  private final @Nullable TypeRegistry typeRegistry;

  private final @Nullable ApiTracer tracer;

  private AutoValue_HttpJsonCallOptions(
      @Nullable Duration timeoutDuration,
      @Nullable Instant deadlineInstant,
      @Nullable Credentials credentials,
      @Nullable TypeRegistry typeRegistry,
      @Nullable ApiTracer tracer) {
    this.timeoutDuration = timeoutDuration;
    this.deadlineInstant = deadlineInstant;
    this.credentials = credentials;
    this.typeRegistry = typeRegistry;
    this.tracer = tracer;
  }

  @Override
  public @Nullable Duration getTimeoutDuration() {
    return timeoutDuration;
  }

  @Override
  public @Nullable Instant getDeadlineInstant() {
    return deadlineInstant;
  }

  @Override
  public @Nullable Credentials getCredentials() {
    return credentials;
  }

  @Override
  public @Nullable TypeRegistry getTypeRegistry() {
    return typeRegistry;
  }

  @Override
  public @Nullable ApiTracer getTracer() {
    return tracer;
  }

  @Override
  public String toString() {
    return "HttpJsonCallOptions{"
        + "timeoutDuration=" + timeoutDuration + ", "
        + "deadlineInstant=" + deadlineInstant + ", "
        + "credentials=" + credentials + ", "
        + "typeRegistry=" + typeRegistry + ", "
        + "tracer=" + tracer
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof HttpJsonCallOptions) {
      HttpJsonCallOptions that = (HttpJsonCallOptions) o;
      return (this.timeoutDuration == null ? that.getTimeoutDuration() == null : this.timeoutDuration.equals(that.getTimeoutDuration()))
          && (this.deadlineInstant == null ? that.getDeadlineInstant() == null : this.deadlineInstant.equals(that.getDeadlineInstant()))
          && (this.credentials == null ? that.getCredentials() == null : this.credentials.equals(that.getCredentials()))
          && (this.typeRegistry == null ? that.getTypeRegistry() == null : this.typeRegistry.equals(that.getTypeRegistry()))
          && (this.tracer == null ? that.getTracer() == null : this.tracer.equals(that.getTracer()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (timeoutDuration == null) ? 0 : timeoutDuration.hashCode();
    h$ *= 1000003;
    h$ ^= (deadlineInstant == null) ? 0 : deadlineInstant.hashCode();
    h$ *= 1000003;
    h$ ^= (credentials == null) ? 0 : credentials.hashCode();
    h$ *= 1000003;
    h$ ^= (typeRegistry == null) ? 0 : typeRegistry.hashCode();
    h$ *= 1000003;
    h$ ^= (tracer == null) ? 0 : tracer.hashCode();
    return h$;
  }

  @Override
  public HttpJsonCallOptions.Builder toBuilder() {
    return new AutoValue_HttpJsonCallOptions.Builder(this);
  }

  static final class Builder extends HttpJsonCallOptions.Builder {
    private @Nullable Duration timeoutDuration;
    private @Nullable Instant deadlineInstant;
    private @Nullable Credentials credentials;
    private @Nullable TypeRegistry typeRegistry;
    private @Nullable ApiTracer tracer;
    Builder() {
    }
    Builder(HttpJsonCallOptions source) {
      this.timeoutDuration = source.getTimeoutDuration();
      this.deadlineInstant = source.getDeadlineInstant();
      this.credentials = source.getCredentials();
      this.typeRegistry = source.getTypeRegistry();
      this.tracer = source.getTracer();
    }
    @Override
    public HttpJsonCallOptions.Builder setTimeoutDuration(Duration timeoutDuration) {
      this.timeoutDuration = timeoutDuration;
      return this;
    }
    @Override
    public HttpJsonCallOptions.Builder setDeadlineInstant(Instant deadlineInstant) {
      this.deadlineInstant = deadlineInstant;
      return this;
    }
    @Override
    public HttpJsonCallOptions.Builder setCredentials(Credentials credentials) {
      this.credentials = credentials;
      return this;
    }
    @Override
    public HttpJsonCallOptions.Builder setTypeRegistry(TypeRegistry typeRegistry) {
      this.typeRegistry = typeRegistry;
      return this;
    }
    @Override
    public HttpJsonCallOptions.Builder setTracer(ApiTracer tracer) {
      this.tracer = tracer;
      return this;
    }
    @Override
    public HttpJsonCallOptions build() {
      return new AutoValue_HttpJsonCallOptions(
          this.timeoutDuration,
          this.deadlineInstant,
          this.credentials,
          this.typeRegistry,
          this.tracer);
    }
  }

}
