package com.google.api.gax.httpjson;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_HttpJsonTransportChannel extends HttpJsonTransportChannel {

  private final ManagedHttpJsonChannel managedChannel;

  private AutoValue_HttpJsonTransportChannel(
      ManagedHttpJsonChannel managedChannel) {
    this.managedChannel = managedChannel;
  }

  @Override
  public ManagedHttpJsonChannel getManagedChannel() {
    return managedChannel;
  }

  @Override
  public String toString() {
    return "HttpJsonTransportChannel{"
        + "managedChannel=" + managedChannel
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof HttpJsonTransportChannel) {
      HttpJsonTransportChannel that = (HttpJsonTransportChannel) o;
      return this.managedChannel.equals(that.getManagedChannel());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= managedChannel.hashCode();
    return h$;
  }

  static final class Builder extends HttpJsonTransportChannel.Builder {
    private ManagedHttpJsonChannel managedChannel;
    Builder() {
    }
    @Override
    public HttpJsonTransportChannel.Builder setManagedChannel(ManagedHttpJsonChannel managedChannel) {
      if (managedChannel == null) {
        throw new NullPointerException("Null managedChannel");
      }
      this.managedChannel = managedChannel;
      return this;
    }
    @Override
    public HttpJsonTransportChannel build() {
      if (this.managedChannel == null) {
        String missing = " managedChannel";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_HttpJsonTransportChannel(
          this.managedChannel);
    }
  }

}
