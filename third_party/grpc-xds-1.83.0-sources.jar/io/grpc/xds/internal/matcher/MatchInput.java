/*
 * Copyright 2021 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.xds.internal.matcher;

import javax.annotation.Nullable;

/**
 * Interface for extracting values from a match context (e.g. HTTP headers).
 */
interface MatchInput {
  /**
   * Extracts the value from the context.
   * @param context the context (e.g. Metadata, Attributes)
   * @return the extracted value, or null if not found.
   */
  @Nullable
  Object apply(MatchContext context);

  /**
   * Returns the type of value extracted by this input.
   */
  Class<?> outputType();
}
