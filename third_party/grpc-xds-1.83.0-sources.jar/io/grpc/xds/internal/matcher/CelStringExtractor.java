/*
 * Copyright 2026 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.xds.internal.matcher;

import dev.cel.common.CelAbstractSyntaxTree;
import dev.cel.common.types.SimpleType;
import dev.cel.runtime.CelEvaluationException;
import dev.cel.runtime.CelRuntime;
import dev.cel.runtime.CelVariableResolver;
import javax.annotation.Nullable;

/**
 * Executes compiled CEL expressions that extract a string.
 */
final class CelStringExtractor {
  private final CelRuntime.Program program;
  @Nullable
  private final String defaultValue;

  private CelStringExtractor(CelRuntime.Program program, @Nullable String defaultValue) {
    this.program = program;
    this.defaultValue = defaultValue;
  }

  /**
   * Compiles the AST into a CelStringExtractor with an optional default value.
   * Throws an Exception if evaluation fails during compilation setup.
   */
  static CelStringExtractor compile(CelAbstractSyntaxTree ast, @Nullable String defaultValue)
      throws CelEvaluationException {
    if (ast.getResultType() != SimpleType.STRING && ast.getResultType() != SimpleType.DYN) {
      throw new IllegalArgumentException(
          "CEL expression must evaluate to string, got: " + ast.getResultType());
    }
    CelCommon.checkAllowedReferences(ast);
    CelRuntime.Program program = CelCommon.RUNTIME.createProgram(ast);
    return new CelStringExtractor(program, defaultValue);
  }

  /**
   * Compiles the AST into a CelStringExtractor with no default value.
   * Throws an Exception if evaluation fails during compilation setup.
   */
  static CelStringExtractor compile(CelAbstractSyntaxTree ast)
      throws CelEvaluationException {
    return compile(ast, null);
  }

  /**
   * Evaluates the CEL expression and returns the string result.
   * Returns the default value if the result is not a string or if evaluation
   * fails.
   */
  String extract(Object input) throws CelEvaluationException {
    if (input instanceof CelVariableResolver) {
      try {
        Object result = program.eval((CelVariableResolver) input);

        if (result instanceof String) {
          return (String) result;
        }
      } catch (CelEvaluationException e) {
        if (defaultValue == null) {
          throw e;
        }
      }
    } else if (defaultValue == null) {
      throw new CelEvaluationException(
          "Unsupported input type for CEL evaluation: "
              + (input == null ? "null" : input.getClass().getName()));
    }
    return defaultValue;
  }
}
