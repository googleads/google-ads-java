/*
 * Copyright 2026 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.xds.internal.extproc;

/**
 * States of the stream with the external processor.
 */
public enum ExtProcStreamState {
  ACTIVE,
  DRAINING,
  COMPLETED,
  FAILED;

  public boolean isCompleted() {
    return this == COMPLETED || this == FAILED;
  }

  public boolean isFailed() {
    return this == FAILED;
  }

  public boolean isDraining() {
    return this == DRAINING;
  }
}
