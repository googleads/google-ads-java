/*
 * Copyright 2025 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.xds.client;

import com.google.auto.value.AutoValue;
import io.grpc.ChannelCredentials;
import io.grpc.Internal;

/**
 * Composition of {@link ChannelCredentials} and {@link ChannelCredsConfig}.
 */
@Internal
@AutoValue
public abstract class ConfiguredChannelCredentials {
  public abstract ChannelCredentials channelCredentials();

  public abstract ChannelCredsConfig channelCredsConfig();

  public static ConfiguredChannelCredentials create(ChannelCredentials creds,
      ChannelCredsConfig config) {
    return new AutoValue_ConfiguredChannelCredentials(creds, config);
  }

  /**
   * Configuration for channel credentials.
   */
  @Internal
  public interface ChannelCredsConfig {
    /**
     * Returns the type of the credentials.
     */
    String type();
  }
}
