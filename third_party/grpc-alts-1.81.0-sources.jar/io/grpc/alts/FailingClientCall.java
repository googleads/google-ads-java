/*
 * Copyright 2018 The gRPC Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.grpc.alts;

import io.grpc.ClientCall;
import io.grpc.Metadata;
import io.grpc.Status;

/** An implementation of {@link ClientCall} that fails when started. */
final class FailingClientCall<ReqT, RespT> extends ClientCall<ReqT, RespT> {

  private final Status error;

  public FailingClientCall(Status error) {
    this.error = error;
  }

  @Override
  public void start(ClientCall.Listener<RespT> listener, Metadata headers) {
    listener.onClose(error, new Metadata());
  }

  @Override
  public void request(int numMessages) {}

  @Override
  public void cancel(String message, Throwable cause) {}

  @Override
  public void halfClose() {}

  @Override
  public void sendMessage(ReqT message) {}
}
