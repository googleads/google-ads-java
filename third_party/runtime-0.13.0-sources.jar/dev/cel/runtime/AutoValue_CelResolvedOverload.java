package dev.cel.runtime;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelResolvedOverload extends CelResolvedOverload {

  private final String functionName;

  private final String overloadId;

  private final ImmutableList<Class<?>> parameterTypes;

  private final boolean strict;

  private final CelFunctionOverload definition;

  private final OptimizedFunctionOverload optimizedDefinition;

  AutoValue_CelResolvedOverload(
      String functionName,
      String overloadId,
      ImmutableList<Class<?>> parameterTypes,
      boolean strict,
      CelFunctionOverload definition,
      OptimizedFunctionOverload optimizedDefinition) {
    if (functionName == null) {
      throw new NullPointerException("Null functionName");
    }
    this.functionName = functionName;
    if (overloadId == null) {
      throw new NullPointerException("Null overloadId");
    }
    this.overloadId = overloadId;
    if (parameterTypes == null) {
      throw new NullPointerException("Null parameterTypes");
    }
    this.parameterTypes = parameterTypes;
    this.strict = strict;
    if (definition == null) {
      throw new NullPointerException("Null definition");
    }
    this.definition = definition;
    if (optimizedDefinition == null) {
      throw new NullPointerException("Null optimizedDefinition");
    }
    this.optimizedDefinition = optimizedDefinition;
  }

  @Override
  public String getFunctionName() {
    return functionName;
  }

  @Override
  public String getOverloadId() {
    return overloadId;
  }

  @Override
  public ImmutableList<Class<?>> getParameterTypes() {
    return parameterTypes;
  }

  @Override
  public boolean isStrict() {
    return strict;
  }

  @Override
  public CelFunctionOverload getDefinition() {
    return definition;
  }

  @Override
  OptimizedFunctionOverload getOptimizedDefinition() {
    return optimizedDefinition;
  }

  @Override
  public String toString() {
    return "CelResolvedOverload{"
        + "functionName=" + functionName + ", "
        + "overloadId=" + overloadId + ", "
        + "parameterTypes=" + parameterTypes + ", "
        + "strict=" + strict + ", "
        + "definition=" + definition + ", "
        + "optimizedDefinition=" + optimizedDefinition
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelResolvedOverload) {
      CelResolvedOverload that = (CelResolvedOverload) o;
      return this.functionName.equals(that.getFunctionName())
          && this.overloadId.equals(that.getOverloadId())
          && this.parameterTypes.equals(that.getParameterTypes())
          && this.strict == that.isStrict()
          && this.definition.equals(that.getDefinition())
          && this.optimizedDefinition.equals(that.getOptimizedDefinition());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= functionName.hashCode();
    h$ *= 1000003;
    h$ ^= overloadId.hashCode();
    h$ *= 1000003;
    h$ ^= parameterTypes.hashCode();
    h$ *= 1000003;
    h$ ^= strict ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= definition.hashCode();
    h$ *= 1000003;
    h$ ^= optimizedDefinition.hashCode();
    return h$;
  }

}
