package dev.cel.runtime;

import dev.cel.common.CelOptions;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProgramImpl extends ProgramImpl {

  private final Interpretable interpretable;

  private final CelOptions options;

  AutoValue_ProgramImpl(
      Interpretable interpretable,
      CelOptions options) {
    if (interpretable == null) {
      throw new NullPointerException("Null interpretable");
    }
    this.interpretable = interpretable;
    if (options == null) {
      throw new NullPointerException("Null options");
    }
    this.options = options;
  }

  @Override
  Interpretable getInterpretable() {
    return interpretable;
  }

  @Override
  CelOptions getOptions() {
    return options;
  }

  @Override
  public String toString() {
    return "ProgramImpl{"
        + "interpretable=" + interpretable + ", "
        + "options=" + options
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProgramImpl) {
      ProgramImpl that = (ProgramImpl) o;
      return this.interpretable.equals(that.getInterpretable())
          && this.options.equals(that.getOptions());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= interpretable.hashCode();
    h$ *= 1000003;
    h$ ^= options.hashCode();
    return h$;
  }

}
