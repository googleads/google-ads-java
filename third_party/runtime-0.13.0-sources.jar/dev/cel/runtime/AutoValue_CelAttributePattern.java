package dev.cel.runtime;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelAttributePattern extends CelAttributePattern {

  private final ImmutableList<CelAttribute.Qualifier> qualifiers;

  AutoValue_CelAttributePattern(
      ImmutableList<CelAttribute.Qualifier> qualifiers) {
    if (qualifiers == null) {
      throw new NullPointerException("Null qualifiers");
    }
    this.qualifiers = qualifiers;
  }

  @Override
  public ImmutableList<CelAttribute.Qualifier> qualifiers() {
    return qualifiers;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelAttributePattern) {
      CelAttributePattern that = (CelAttributePattern) o;
      return this.qualifiers.equals(that.qualifiers());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= qualifiers.hashCode();
    return h$;
  }

}
