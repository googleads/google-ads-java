package dev.cel.runtime;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.protobuf.Descriptors;
import com.google.protobuf.ExtensionRegistry;
import dev.cel.common.CelContainer;
import dev.cel.common.CelOptions;
import dev.cel.common.types.CelTypeProvider;
import dev.cel.common.values.CelValueProvider;
import dev.cel.runtime.planner.ProgramPlanner;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelRuntimeImpl extends CelRuntimeImpl {

  private final ProgramPlanner planner;

  private final CelOptions options;

  private final CelContainer container;

  private final ImmutableMap<String, CelFunctionBinding> functionBindings;

  private final ImmutableSet<Descriptors.FileDescriptor> fileDescriptors;

  @SuppressWarnings("Immutable")
  private final ImmutableSet<CelRuntimeLibrary> runtimeLibraries;

  private final ImmutableSet<String> lateBoundFunctionNames;

  private final CelStandardFunctions standardFunctions;

  private final @Nullable CelTypeProvider typeProvider;

  private final @Nullable CelValueProvider valueProvider;

  @SuppressWarnings("Immutable")
  private final @Nullable ExtensionRegistry extensionRegistry;

  private AutoValue_CelRuntimeImpl(
      ProgramPlanner planner,
      CelOptions options,
      CelContainer container,
      ImmutableMap<String, CelFunctionBinding> functionBindings,
      ImmutableSet<Descriptors.FileDescriptor> fileDescriptors,
      ImmutableSet<CelRuntimeLibrary> runtimeLibraries,
      ImmutableSet<String> lateBoundFunctionNames,
      CelStandardFunctions standardFunctions,
      @Nullable CelTypeProvider typeProvider,
      @Nullable CelValueProvider valueProvider,
      @Nullable ExtensionRegistry extensionRegistry) {
    this.planner = planner;
    this.options = options;
    this.container = container;
    this.functionBindings = functionBindings;
    this.fileDescriptors = fileDescriptors;
    this.runtimeLibraries = runtimeLibraries;
    this.lateBoundFunctionNames = lateBoundFunctionNames;
    this.standardFunctions = standardFunctions;
    this.typeProvider = typeProvider;
    this.valueProvider = valueProvider;
    this.extensionRegistry = extensionRegistry;
  }

  @Override
  ProgramPlanner planner() {
    return planner;
  }

  @Override
  CelOptions options() {
    return options;
  }

  @Override
  CelContainer container() {
    return container;
  }

  @Override
  ImmutableMap<String, CelFunctionBinding> functionBindings() {
    return functionBindings;
  }

  @Override
  ImmutableSet<Descriptors.FileDescriptor> fileDescriptors() {
    return fileDescriptors;
  }

  @SuppressWarnings("Immutable")
  @Override
  ImmutableSet<CelRuntimeLibrary> runtimeLibraries() {
    return runtimeLibraries;
  }

  @Override
  ImmutableSet<String> lateBoundFunctionNames() {
    return lateBoundFunctionNames;
  }

  @Override
  CelStandardFunctions standardFunctions() {
    return standardFunctions;
  }

  @Override
  @Nullable CelTypeProvider typeProvider() {
    return typeProvider;
  }

  @Override
  @Nullable CelValueProvider valueProvider() {
    return valueProvider;
  }

  @SuppressWarnings("Immutable")
  @Override
  @Nullable ExtensionRegistry extensionRegistry() {
    return extensionRegistry;
  }

  @Override
  public String toString() {
    return "CelRuntimeImpl{"
        + "planner=" + planner + ", "
        + "options=" + options + ", "
        + "container=" + container + ", "
        + "functionBindings=" + functionBindings + ", "
        + "fileDescriptors=" + fileDescriptors + ", "
        + "runtimeLibraries=" + runtimeLibraries + ", "
        + "lateBoundFunctionNames=" + lateBoundFunctionNames + ", "
        + "standardFunctions=" + standardFunctions + ", "
        + "typeProvider=" + typeProvider + ", "
        + "valueProvider=" + valueProvider + ", "
        + "extensionRegistry=" + extensionRegistry
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelRuntimeImpl) {
      CelRuntimeImpl that = (CelRuntimeImpl) o;
      return this.planner.equals(that.planner())
          && this.options.equals(that.options())
          && this.container.equals(that.container())
          && this.functionBindings.equals(that.functionBindings())
          && this.fileDescriptors.equals(that.fileDescriptors())
          && this.runtimeLibraries.equals(that.runtimeLibraries())
          && this.lateBoundFunctionNames.equals(that.lateBoundFunctionNames())
          && this.standardFunctions.equals(that.standardFunctions())
          && (this.typeProvider == null ? that.typeProvider() == null : this.typeProvider.equals(that.typeProvider()))
          && (this.valueProvider == null ? that.valueProvider() == null : this.valueProvider.equals(that.valueProvider()))
          && (this.extensionRegistry == null ? that.extensionRegistry() == null : this.extensionRegistry.equals(that.extensionRegistry()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= planner.hashCode();
    h$ *= 1000003;
    h$ ^= options.hashCode();
    h$ *= 1000003;
    h$ ^= container.hashCode();
    h$ *= 1000003;
    h$ ^= functionBindings.hashCode();
    h$ *= 1000003;
    h$ ^= fileDescriptors.hashCode();
    h$ *= 1000003;
    h$ ^= runtimeLibraries.hashCode();
    h$ *= 1000003;
    h$ ^= lateBoundFunctionNames.hashCode();
    h$ *= 1000003;
    h$ ^= standardFunctions.hashCode();
    h$ *= 1000003;
    h$ ^= (typeProvider == null) ? 0 : typeProvider.hashCode();
    h$ *= 1000003;
    h$ ^= (valueProvider == null) ? 0 : valueProvider.hashCode();
    h$ *= 1000003;
    h$ ^= (extensionRegistry == null) ? 0 : extensionRegistry.hashCode();
    return h$;
  }

  @Override
  public CelRuntimeImpl.Builder toRuntimeBuilder() {
    return new AutoValue_CelRuntimeImpl.Builder(this);
  }

  static final class Builder extends CelRuntimeImpl.Builder {
    private @Nullable ProgramPlanner planner;
    private @Nullable CelOptions options;
    private @Nullable CelContainer container;
    private @Nullable ImmutableMap<String, CelFunctionBinding> functionBindings;
    private ImmutableSet.@Nullable Builder<Descriptors.FileDescriptor> fileDescriptorsBuilder$;
    private @Nullable ImmutableSet<Descriptors.FileDescriptor> fileDescriptors;
    private ImmutableSet.@Nullable Builder<CelRuntimeLibrary> runtimeLibrariesBuilder$;
    private @Nullable ImmutableSet<CelRuntimeLibrary> runtimeLibraries;
    private ImmutableSet.@Nullable Builder<String> lateBoundFunctionNamesBuilder$;
    private @Nullable ImmutableSet<String> lateBoundFunctionNames;
    private @Nullable CelStandardFunctions standardFunctions;
    private @Nullable CelTypeProvider typeProvider;
    private @Nullable CelValueProvider valueProvider;
    private @Nullable ExtensionRegistry extensionRegistry;
    Builder() {
    }
    Builder(CelRuntimeImpl source) {
      this.planner = source.planner();
      this.options = source.options();
      this.container = source.container();
      this.functionBindings = source.functionBindings();
      this.fileDescriptors = source.fileDescriptors();
      this.runtimeLibraries = source.runtimeLibraries();
      this.lateBoundFunctionNames = source.lateBoundFunctionNames();
      this.standardFunctions = source.standardFunctions();
      this.typeProvider = source.typeProvider();
      this.valueProvider = source.valueProvider();
      this.extensionRegistry = source.extensionRegistry();
    }
    @Override
    public CelRuntimeImpl.Builder setPlanner(ProgramPlanner planner) {
      if (planner == null) {
        throw new NullPointerException("Null planner");
      }
      this.planner = planner;
      return this;
    }
    @Override
    public CelRuntimeImpl.Builder setOptions(CelOptions options) {
      if (options == null) {
        throw new NullPointerException("Null options");
      }
      this.options = options;
      return this;
    }
    @Override
    CelOptions options() {
      if (this.options == null) {
        throw new IllegalStateException("Property \"options\" has not been set");
      }
      return options;
    }
    @Override
    public CelRuntimeImpl.Builder setContainer(CelContainer container) {
      if (container == null) {
        throw new NullPointerException("Null container");
      }
      this.container = container;
      return this;
    }
    @Override
    CelContainer container() {
      if (this.container == null) {
        throw new IllegalStateException("Property \"container\" has not been set");
      }
      return container;
    }
    @Override
    CelRuntimeImpl.Builder setFunctionBindings(ImmutableMap<String, CelFunctionBinding> functionBindings) {
      if (functionBindings == null) {
        throw new NullPointerException("Null functionBindings");
      }
      this.functionBindings = functionBindings;
      return this;
    }
    @Override
    ImmutableMap<String, CelFunctionBinding> functionBindings() {
      if (this.functionBindings == null) {
        throw new IllegalStateException("Property \"functionBindings\" has not been set");
      }
      return functionBindings;
    }
    @Override
    ImmutableSet.Builder<Descriptors.FileDescriptor> fileDescriptorsBuilder() {
      if (fileDescriptorsBuilder$ == null) {
        if (fileDescriptors == null) {
          fileDescriptorsBuilder$ = ImmutableSet.builder();
        } else {
          fileDescriptorsBuilder$ = ImmutableSet.builder();
          fileDescriptorsBuilder$.addAll(fileDescriptors);
          fileDescriptors = null;
        }
      }
      return fileDescriptorsBuilder$;
    }
    @Override
    ImmutableSet.Builder<CelRuntimeLibrary> runtimeLibrariesBuilder() {
      if (runtimeLibrariesBuilder$ == null) {
        if (runtimeLibraries == null) {
          runtimeLibrariesBuilder$ = ImmutableSet.builder();
        } else {
          runtimeLibrariesBuilder$ = ImmutableSet.builder();
          runtimeLibrariesBuilder$.addAll(runtimeLibraries);
          runtimeLibraries = null;
        }
      }
      return runtimeLibrariesBuilder$;
    }
    @Override
    ImmutableSet.Builder<String> lateBoundFunctionNamesBuilder() {
      if (lateBoundFunctionNamesBuilder$ == null) {
        if (lateBoundFunctionNames == null) {
          lateBoundFunctionNamesBuilder$ = ImmutableSet.builder();
        } else {
          lateBoundFunctionNamesBuilder$ = ImmutableSet.builder();
          lateBoundFunctionNamesBuilder$.addAll(lateBoundFunctionNames);
          lateBoundFunctionNames = null;
        }
      }
      return lateBoundFunctionNamesBuilder$;
    }
    @Override
    public CelRuntimeImpl.Builder setStandardFunctions(CelStandardFunctions standardFunctions) {
      if (standardFunctions == null) {
        throw new NullPointerException("Null standardFunctions");
      }
      this.standardFunctions = standardFunctions;
      return this;
    }
    @Override
    CelStandardFunctions standardFunctions() {
      if (this.standardFunctions == null) {
        throw new IllegalStateException("Property \"standardFunctions\" has not been set");
      }
      return standardFunctions;
    }
    @Override
    public CelRuntimeImpl.Builder setTypeProvider(CelTypeProvider typeProvider) {
      this.typeProvider = typeProvider;
      return this;
    }
    @Override
    CelTypeProvider typeProvider() {
      return typeProvider;
    }
    @Override
    public CelRuntimeImpl.Builder setValueProvider(CelValueProvider valueProvider) {
      this.valueProvider = valueProvider;
      return this;
    }
    @Override
    CelValueProvider valueProvider() {
      return valueProvider;
    }
    @Override
    public CelRuntimeImpl.Builder setExtensionRegistry(ExtensionRegistry extensionRegistry) {
      this.extensionRegistry = extensionRegistry;
      return this;
    }
    @Override
    ExtensionRegistry extensionRegistry() {
      return extensionRegistry;
    }
    @Override
    CelRuntimeImpl autoBuild() {
      if (fileDescriptorsBuilder$ != null) {
        this.fileDescriptors = fileDescriptorsBuilder$.build();
      } else if (this.fileDescriptors == null) {
        this.fileDescriptors = ImmutableSet.of();
      }
      if (runtimeLibrariesBuilder$ != null) {
        this.runtimeLibraries = runtimeLibrariesBuilder$.build();
      } else if (this.runtimeLibraries == null) {
        this.runtimeLibraries = ImmutableSet.of();
      }
      if (lateBoundFunctionNamesBuilder$ != null) {
        this.lateBoundFunctionNames = lateBoundFunctionNamesBuilder$.build();
      } else if (this.lateBoundFunctionNames == null) {
        this.lateBoundFunctionNames = ImmutableSet.of();
      }
      if (this.planner == null
          || this.options == null
          || this.container == null
          || this.functionBindings == null
          || this.standardFunctions == null) {
        StringBuilder missing = new StringBuilder();
        if (this.planner == null) {
          missing.append(" planner");
        }
        if (this.options == null) {
          missing.append(" options");
        }
        if (this.container == null) {
          missing.append(" container");
        }
        if (this.functionBindings == null) {
          missing.append(" functionBindings");
        }
        if (this.standardFunctions == null) {
          missing.append(" standardFunctions");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_CelRuntimeImpl(
          this.planner,
          this.options,
          this.container,
          this.functionBindings,
          this.fileDescriptors,
          this.runtimeLibraries,
          this.lateBoundFunctionNames,
          this.standardFunctions,
          this.typeProvider,
          this.valueProvider,
          this.extensionRegistry);
    }
  }

}
