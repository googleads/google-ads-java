// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package dev.cel.runtime.planner;

import dev.cel.common.ast.CelExpr;
import dev.cel.common.values.CelValueConverter;
import dev.cel.runtime.CelEvaluationException;
import dev.cel.runtime.CelResolvedOverload;
import dev.cel.runtime.GlobalResolver;

final class EvalZeroArity extends PlannedInterpretable {
  private static final Object[] EMPTY_ARRAY = new Object[0];

  private final String functionName;
  private final CelResolvedOverload resolvedOverload;
  private final CelValueConverter celValueConverter;

  @Override
  Object evalInternal(GlobalResolver resolver, ExecutionFrame frame) throws CelEvaluationException {
    return EvalHelpers.dispatch(functionName, resolvedOverload, celValueConverter, EMPTY_ARRAY);
  }

  static EvalZeroArity create(
      CelExpr expr,
      String functionName,
      CelResolvedOverload resolvedOverload,
      CelValueConverter celValueConverter) {
    return new EvalZeroArity(expr, functionName, resolvedOverload, celValueConverter);
  }

  private EvalZeroArity(
      CelExpr expr,
      String functionName,
      CelResolvedOverload resolvedOverload,
      CelValueConverter celValueConverter) {
    super(expr);
    this.functionName = functionName;
    this.resolvedOverload = resolvedOverload;
    this.celValueConverter = celValueConverter;
  }
}
