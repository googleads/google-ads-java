package dev.cel.runtime.planner;

import dev.cel.common.CelOptions;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_PlannedProgram extends PlannedProgram {

  private final PlannedInterpretable interpretable;

  private final ErrorMetadata metadata;

  private final CelOptions options;

  AutoValue_PlannedProgram(
      PlannedInterpretable interpretable,
      ErrorMetadata metadata,
      CelOptions options) {
    if (interpretable == null) {
      throw new NullPointerException("Null interpretable");
    }
    this.interpretable = interpretable;
    if (metadata == null) {
      throw new NullPointerException("Null metadata");
    }
    this.metadata = metadata;
    if (options == null) {
      throw new NullPointerException("Null options");
    }
    this.options = options;
  }

  @Override
  public PlannedInterpretable interpretable() {
    return interpretable;
  }

  @Override
  ErrorMetadata metadata() {
    return metadata;
  }

  @Override
  public CelOptions options() {
    return options;
  }

  @Override
  public String toString() {
    return "PlannedProgram{"
        + "interpretable=" + interpretable + ", "
        + "metadata=" + metadata + ", "
        + "options=" + options
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof PlannedProgram) {
      PlannedProgram that = (PlannedProgram) o;
      return this.interpretable.equals(that.interpretable())
          && this.metadata.equals(that.metadata())
          && this.options.equals(that.options());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= interpretable.hashCode();
    h$ *= 1000003;
    h$ ^= metadata.hashCode();
    h$ *= 1000003;
    h$ ^= options.hashCode();
    return h$;
  }

}
