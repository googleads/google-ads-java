package dev.cel.runtime.planner;

import dev.cel.common.ast.CelExpr;
import java.util.Optional;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProgramPlanner_ResolvedFunction extends ProgramPlanner.ResolvedFunction {

  private final String functionName;

  private final Optional<CelExpr> target;

  private final Optional<String> overloadId;

  private AutoValue_ProgramPlanner_ResolvedFunction(
      String functionName,
      Optional<CelExpr> target,
      Optional<String> overloadId) {
    this.functionName = functionName;
    this.target = target;
    this.overloadId = overloadId;
  }

  @Override
  String functionName() {
    return functionName;
  }

  @Override
  Optional<CelExpr> target() {
    return target;
  }

  @Override
  Optional<String> overloadId() {
    return overloadId;
  }

  @Override
  public String toString() {
    return "ResolvedFunction{"
        + "functionName=" + functionName + ", "
        + "target=" + target + ", "
        + "overloadId=" + overloadId
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProgramPlanner.ResolvedFunction) {
      ProgramPlanner.ResolvedFunction that = (ProgramPlanner.ResolvedFunction) o;
      return this.functionName.equals(that.functionName())
          && this.target.equals(that.target())
          && this.overloadId.equals(that.overloadId());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= functionName.hashCode();
    h$ *= 1000003;
    h$ ^= target.hashCode();
    h$ *= 1000003;
    h$ ^= overloadId.hashCode();
    return h$;
  }

  static final class Builder extends ProgramPlanner.ResolvedFunction.Builder {
    private String functionName;
    private Optional<CelExpr> target = Optional.empty();
    private Optional<String> overloadId = Optional.empty();
    Builder() {
    }
    @Override
    ProgramPlanner.ResolvedFunction.Builder setFunctionName(String functionName) {
      if (functionName == null) {
        throw new NullPointerException("Null functionName");
      }
      this.functionName = functionName;
      return this;
    }
    @Override
    ProgramPlanner.ResolvedFunction.Builder setTarget(CelExpr target) {
      this.target = Optional.of(target);
      return this;
    }
    @Override
    ProgramPlanner.ResolvedFunction.Builder setOverloadId(String overloadId) {
      this.overloadId = Optional.of(overloadId);
      return this;
    }
    @Override
    ProgramPlanner.ResolvedFunction build() {
      if (this.functionName == null) {
        String missing = " functionName";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ProgramPlanner_ResolvedFunction(
          this.functionName,
          this.target,
          this.overloadId);
    }
  }

}
