package dev.cel.runtime;

import com.google.common.collect.ImmutableSet;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_CelUnknownSet extends CelUnknownSet {

  private final ImmutableSet<CelAttribute> attributes;

  private final ImmutableSet<Long> unknownExprIds;

  AutoValue_CelUnknownSet(
      ImmutableSet<CelAttribute> attributes,
      ImmutableSet<Long> unknownExprIds) {
    if (attributes == null) {
      throw new NullPointerException("Null attributes");
    }
    this.attributes = attributes;
    if (unknownExprIds == null) {
      throw new NullPointerException("Null unknownExprIds");
    }
    this.unknownExprIds = unknownExprIds;
  }

  @Override
  public ImmutableSet<CelAttribute> attributes() {
    return attributes;
  }

  @Override
  public ImmutableSet<Long> unknownExprIds() {
    return unknownExprIds;
  }

  @Override
  public String toString() {
    return "CelUnknownSet{"
        + "attributes=" + attributes + ", "
        + "unknownExprIds=" + unknownExprIds
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof CelUnknownSet) {
      CelUnknownSet that = (CelUnknownSet) o;
      return this.attributes.equals(that.attributes())
          && this.unknownExprIds.equals(that.unknownExprIds());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= attributes.hashCode();
    h$ *= 1000003;
    h$ ^= unknownExprIds.hashCode();
    return h$;
  }

}
