package dev.cel.runtime;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_DefaultInterpreter_IntermediateResult extends DefaultInterpreter.IntermediateResult {

  private final CelAttribute attribute;

  private final Object value;

  AutoValue_DefaultInterpreter_IntermediateResult(
      CelAttribute attribute,
      Object value) {
    if (attribute == null) {
      throw new NullPointerException("Null attribute");
    }
    this.attribute = attribute;
    if (value == null) {
      throw new NullPointerException("Null value");
    }
    this.value = value;
  }

  @Override
  CelAttribute attribute() {
    return attribute;
  }

  @Override
  Object value() {
    return value;
  }

  @Override
  public String toString() {
    return "IntermediateResult{"
        + "attribute=" + attribute + ", "
        + "value=" + value
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof DefaultInterpreter.IntermediateResult) {
      DefaultInterpreter.IntermediateResult that = (DefaultInterpreter.IntermediateResult) o;
      return this.attribute.equals(that.attribute())
          && this.value.equals(that.value());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= attribute.hashCode();
    h$ *= 1000003;
    h$ ^= value.hashCode();
    return h$;
  }

}
