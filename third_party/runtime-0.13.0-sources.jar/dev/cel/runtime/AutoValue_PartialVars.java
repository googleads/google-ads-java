package dev.cel.runtime;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_PartialVars extends PartialVars {

  private final CelVariableResolver resolver;

  private final ImmutableList<CelAttributePattern> unknowns;

  AutoValue_PartialVars(
      CelVariableResolver resolver,
      ImmutableList<CelAttributePattern> unknowns) {
    if (resolver == null) {
      throw new NullPointerException("Null resolver");
    }
    this.resolver = resolver;
    if (unknowns == null) {
      throw new NullPointerException("Null unknowns");
    }
    this.unknowns = unknowns;
  }

  @Override
  public CelVariableResolver resolver() {
    return resolver;
  }

  @Override
  public ImmutableList<CelAttributePattern> unknowns() {
    return unknowns;
  }

  @Override
  public String toString() {
    return "PartialVars{"
        + "resolver=" + resolver + ", "
        + "unknowns=" + unknowns
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof PartialVars) {
      PartialVars that = (PartialVars) o;
      return this.resolver.equals(that.resolver())
          && this.unknowns.equals(that.unknowns());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= resolver.hashCode();
    h$ *= 1000003;
    h$ ^= unknowns.hashCode();
    return h$;
  }

}
