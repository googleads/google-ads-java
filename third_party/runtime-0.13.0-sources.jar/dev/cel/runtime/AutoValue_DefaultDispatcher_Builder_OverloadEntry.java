package dev.cel.runtime;

import com.google.common.collect.ImmutableList;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_DefaultDispatcher_Builder_OverloadEntry extends DefaultDispatcher.Builder.OverloadEntry {

  private final String functionName;

  private final ImmutableList<Class<?>> argTypes;

  private final boolean isStrict;

  private final CelFunctionOverload overload;

  AutoValue_DefaultDispatcher_Builder_OverloadEntry(
      String functionName,
      ImmutableList<Class<?>> argTypes,
      boolean isStrict,
      CelFunctionOverload overload) {
    if (functionName == null) {
      throw new NullPointerException("Null functionName");
    }
    this.functionName = functionName;
    if (argTypes == null) {
      throw new NullPointerException("Null argTypes");
    }
    this.argTypes = argTypes;
    this.isStrict = isStrict;
    if (overload == null) {
      throw new NullPointerException("Null overload");
    }
    this.overload = overload;
  }

  @Override
  String functionName() {
    return functionName;
  }

  @Override
  ImmutableList<Class<?>> argTypes() {
    return argTypes;
  }

  @Override
  boolean isStrict() {
    return isStrict;
  }

  @Override
  CelFunctionOverload overload() {
    return overload;
  }

  @Override
  public String toString() {
    return "OverloadEntry{"
        + "functionName=" + functionName + ", "
        + "argTypes=" + argTypes + ", "
        + "isStrict=" + isStrict + ", "
        + "overload=" + overload
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof DefaultDispatcher.Builder.OverloadEntry) {
      DefaultDispatcher.Builder.OverloadEntry that = (DefaultDispatcher.Builder.OverloadEntry) o;
      return this.functionName.equals(that.functionName())
          && this.argTypes.equals(that.argTypes())
          && this.isStrict == that.isStrict()
          && this.overload.equals(that.overload());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= functionName.hashCode();
    h$ *= 1000003;
    h$ ^= argTypes.hashCode();
    h$ *= 1000003;
    h$ ^= isStrict ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= overload.hashCode();
    return h$;
  }

}
