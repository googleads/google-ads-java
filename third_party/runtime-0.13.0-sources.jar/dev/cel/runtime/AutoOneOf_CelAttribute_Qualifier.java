package dev.cel.runtime;

import com.google.common.primitives.UnsignedLong;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoOneOfProcessor")
final class AutoOneOf_CelAttribute_Qualifier {
  private AutoOneOf_CelAttribute_Qualifier() {} // There are no instances of this type.

  static CelAttribute.Qualifier asString(String asString) {
    if (asString == null) {
      throw new NullPointerException();
    }
    return new Impl_asString(asString);
  }

  static CelAttribute.Qualifier asInt(Long asInt) {
    if (asInt == null) {
      throw new NullPointerException();
    }
    return new Impl_asInt(asInt);
  }

  static CelAttribute.Qualifier asUint(UnsignedLong asUint) {
    if (asUint == null) {
      throw new NullPointerException();
    }
    return new Impl_asUint(asUint);
  }

  static CelAttribute.Qualifier asBool(Boolean asBool) {
    if (asBool == null) {
      throw new NullPointerException();
    }
    return new Impl_asBool(asBool);
  }

  static CelAttribute.Qualifier wildCard() {
    return Impl_wildCard.INSTANCE;
  }

  // Parent class that each implementation will inherit from.
  private abstract static class Parent_ extends CelAttribute.Qualifier {
    @Override
    public String asString() {
      throw new UnsupportedOperationException(kind().toString());
    }
    @Override
    public Long asInt() {
      throw new UnsupportedOperationException(kind().toString());
    }
    @Override
    public UnsignedLong asUint() {
      throw new UnsupportedOperationException(kind().toString());
    }
    @Override
    public Boolean asBool() {
      throw new UnsupportedOperationException(kind().toString());
    }
    @Override
    public void wildCard() {
      throw new UnsupportedOperationException(kind().toString());
    }
  }

  // Implementation when the contained property is "asString".
  private static final class Impl_asString extends Parent_ {
    private final String asString;
    Impl_asString(String asString) {
      this.asString = asString;
    }
    @Override
    public String asString() {
      return asString;
    }
    @Override
    public String toString() {
      return "Qualifier{asString=" + this.asString + "}";
    }
    @Override
    public boolean equals(Object x) {
      if (x instanceof CelAttribute.Qualifier) {
        CelAttribute.Qualifier that = (CelAttribute.Qualifier) x;
        return this.kind() == that.kind()
            && this.asString.equals(that.asString());
      } else {
        return false;
      }
    }
    @Override
    public int hashCode() {
      return asString.hashCode();
    }
    @Override
    public CelAttribute.Qualifier.Kind kind() {
      return CelAttribute.Qualifier.Kind.AS_STRING;
    }
  }

  // Implementation when the contained property is "asInt".
  private static final class Impl_asInt extends Parent_ {
    private final Long asInt;
    Impl_asInt(Long asInt) {
      this.asInt = asInt;
    }
    @Override
    public Long asInt() {
      return asInt;
    }
    @Override
    public String toString() {
      return "Qualifier{asInt=" + this.asInt + "}";
    }
    @Override
    public boolean equals(Object x) {
      if (x instanceof CelAttribute.Qualifier) {
        CelAttribute.Qualifier that = (CelAttribute.Qualifier) x;
        return this.kind() == that.kind()
            && this.asInt.equals(that.asInt());
      } else {
        return false;
      }
    }
    @Override
    public int hashCode() {
      return asInt.hashCode();
    }
    @Override
    public CelAttribute.Qualifier.Kind kind() {
      return CelAttribute.Qualifier.Kind.AS_INT;
    }
  }

  // Implementation when the contained property is "asUint".
  private static final class Impl_asUint extends Parent_ {
    private final UnsignedLong asUint;
    Impl_asUint(UnsignedLong asUint) {
      this.asUint = asUint;
    }
    @Override
    public UnsignedLong asUint() {
      return asUint;
    }
    @Override
    public String toString() {
      return "Qualifier{asUint=" + this.asUint + "}";
    }
    @Override
    public boolean equals(Object x) {
      if (x instanceof CelAttribute.Qualifier) {
        CelAttribute.Qualifier that = (CelAttribute.Qualifier) x;
        return this.kind() == that.kind()
            && this.asUint.equals(that.asUint());
      } else {
        return false;
      }
    }
    @Override
    public int hashCode() {
      return asUint.hashCode();
    }
    @Override
    public CelAttribute.Qualifier.Kind kind() {
      return CelAttribute.Qualifier.Kind.AS_UINT;
    }
  }

  // Implementation when the contained property is "asBool".
  private static final class Impl_asBool extends Parent_ {
    private final Boolean asBool;
    Impl_asBool(Boolean asBool) {
      this.asBool = asBool;
    }
    @Override
    public Boolean asBool() {
      return asBool;
    }
    @Override
    public String toString() {
      return "Qualifier{asBool=" + this.asBool + "}";
    }
    @Override
    public boolean equals(Object x) {
      if (x instanceof CelAttribute.Qualifier) {
        CelAttribute.Qualifier that = (CelAttribute.Qualifier) x;
        return this.kind() == that.kind()
            && this.asBool.equals(that.asBool());
      } else {
        return false;
      }
    }
    @Override
    public int hashCode() {
      return asBool.hashCode();
    }
    @Override
    public CelAttribute.Qualifier.Kind kind() {
      return CelAttribute.Qualifier.Kind.AS_BOOL;
    }
  }

  // Implementation when the contained property is "wildCard".
  private static final class Impl_wildCard extends Parent_ {
    // There is only one instance of this class.
    static final Impl_wildCard INSTANCE = new Impl_wildCard();
    private Impl_wildCard() {}
    @Override
    public void wildCard() {}
    @Override
    public String toString() {
      return "Qualifier{wildCard}";
    }
    @Override
    public boolean equals(Object x) {
      return x == this;
    }
    @Override
    public int hashCode() {
      return System.identityHashCode(this);
    }
    @Override
    public CelAttribute.Qualifier.Kind kind() {
      return CelAttribute.Qualifier.Kind.WILD_CARD;
    }
  }

}
