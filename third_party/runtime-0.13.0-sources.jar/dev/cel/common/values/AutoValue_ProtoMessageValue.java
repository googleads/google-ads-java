package dev.cel.common.values;

import com.google.protobuf.Message;
import dev.cel.common.internal.CelDescriptorPool;
import dev.cel.common.types.CelType;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProtoMessageValue extends ProtoMessageValue {

  private final Message value;

  private final CelType celType;

  private final CelDescriptorPool celDescriptorPool;

  private final ProtoCelValueConverter protoCelValueConverter;

  private final boolean enableJsonFieldNames;

  AutoValue_ProtoMessageValue(
      Message value,
      CelType celType,
      CelDescriptorPool celDescriptorPool,
      ProtoCelValueConverter protoCelValueConverter,
      boolean enableJsonFieldNames) {
    if (value == null) {
      throw new NullPointerException("Null value");
    }
    this.value = value;
    if (celType == null) {
      throw new NullPointerException("Null celType");
    }
    this.celType = celType;
    if (celDescriptorPool == null) {
      throw new NullPointerException("Null celDescriptorPool");
    }
    this.celDescriptorPool = celDescriptorPool;
    if (protoCelValueConverter == null) {
      throw new NullPointerException("Null protoCelValueConverter");
    }
    this.protoCelValueConverter = protoCelValueConverter;
    this.enableJsonFieldNames = enableJsonFieldNames;
  }

  @Override
  public Message value() {
    return value;
  }

  @Override
  public CelType celType() {
    return celType;
  }

  @Override
  CelDescriptorPool celDescriptorPool() {
    return celDescriptorPool;
  }

  @Override
  ProtoCelValueConverter protoCelValueConverter() {
    return protoCelValueConverter;
  }

  @Override
  boolean enableJsonFieldNames() {
    return enableJsonFieldNames;
  }

  @Override
  public String toString() {
    return "ProtoMessageValue{"
        + "value=" + value + ", "
        + "celType=" + celType + ", "
        + "celDescriptorPool=" + celDescriptorPool + ", "
        + "protoCelValueConverter=" + protoCelValueConverter + ", "
        + "enableJsonFieldNames=" + enableJsonFieldNames
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProtoMessageValue) {
      ProtoMessageValue that = (ProtoMessageValue) o;
      return this.value.equals(that.value())
          && this.celType.equals(that.celType())
          && this.celDescriptorPool.equals(that.celDescriptorPool())
          && this.protoCelValueConverter.equals(that.protoCelValueConverter())
          && this.enableJsonFieldNames == that.enableJsonFieldNames();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= value.hashCode();
    h$ *= 1000003;
    h$ ^= celType.hashCode();
    h$ *= 1000003;
    h$ ^= celDescriptorPool.hashCode();
    h$ *= 1000003;
    h$ ^= protoCelValueConverter.hashCode();
    h$ *= 1000003;
    h$ ^= enableJsonFieldNames ? 1231 : 1237;
    return h$;
  }

}
