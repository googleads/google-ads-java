package dev.cel.common.internal;

import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_BidiConverter<A, B> extends BidiConverter<A, B> {

  private final Converter<A, B> forwardConverter;

  private final Converter<B, A> backwardConverter;

  AutoValue_BidiConverter(
      Converter<A, B> forwardConverter,
      Converter<B, A> backwardConverter) {
    if (forwardConverter == null) {
      throw new NullPointerException("Null forwardConverter");
    }
    this.forwardConverter = forwardConverter;
    if (backwardConverter == null) {
      throw new NullPointerException("Null backwardConverter");
    }
    this.backwardConverter = backwardConverter;
  }

  @Override
  public Converter<A, B> forwardConverter() {
    return forwardConverter;
  }

  @Override
  public Converter<B, A> backwardConverter() {
    return backwardConverter;
  }

  @Override
  public String toString() {
    return "BidiConverter{"
        + "forwardConverter=" + forwardConverter + ", "
        + "backwardConverter=" + backwardConverter
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof BidiConverter) {
      BidiConverter<?, ?> that = (BidiConverter<?, ?>) o;
      return this.forwardConverter.equals(that.forwardConverter())
          && this.backwardConverter.equals(that.backwardConverter());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= forwardConverter.hashCode();
    h$ *= 1000003;
    h$ ^= backwardConverter.hashCode();
    return h$;
  }

}
