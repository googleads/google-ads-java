package dev.cel.common.internal;

import com.google.common.collect.ImmutableMap;
import com.google.protobuf.Descriptors;
import javax.annotation.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProtoEquality_ProtoMap extends ProtoEquality.ProtoMap {

  private final Descriptors.FieldDescriptor valueField;

  private final ImmutableMap<Object, Object> map;

  AutoValue_ProtoEquality_ProtoMap(
      Descriptors.FieldDescriptor valueField,
      ImmutableMap<Object, Object> map) {
    if (valueField == null) {
      throw new NullPointerException("Null valueField");
    }
    this.valueField = valueField;
    if (map == null) {
      throw new NullPointerException("Null map");
    }
    this.map = map;
  }

  @Override
  Descriptors.FieldDescriptor valueField() {
    return valueField;
  }

  @Override
  ImmutableMap<Object, Object> map() {
    return map;
  }

  @Override
  public String toString() {
    return "ProtoMap{"
        + "valueField=" + valueField + ", "
        + "map=" + map
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProtoEquality.ProtoMap) {
      ProtoEquality.ProtoMap that = (ProtoEquality.ProtoMap) o;
      return this.valueField.equals(that.valueField())
          && this.map.equals(that.map());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= valueField.hashCode();
    h$ *= 1000003;
    h$ ^= map.hashCode();
    return h$;
  }

}
