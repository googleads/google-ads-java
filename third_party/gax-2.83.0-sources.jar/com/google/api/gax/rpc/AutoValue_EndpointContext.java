package com.google.api.gax.rpc;

import com.google.api.gax.rpc.internal.EnvironmentProvider;
import com.google.api.gax.rpc.mtls.CertificateBasedAccess;
import com.google.auth.mtls.MtlsProvider;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_EndpointContext extends EndpointContext {

  private final @Nullable String serviceName;

  private final @Nullable String universeDomain;

  private final @Nullable String clientSettingsEndpoint;

  private final @Nullable String transportChannelProviderEndpoint;

  private final boolean useS2A;

  private final @Nullable EnvironmentProvider envProvider;

  private final @Nullable String mtlsEndpoint;

  private final boolean switchToMtlsEndpointAllowed;

  private final @Nullable MtlsProvider mtlsProvider;

  private final @Nullable CertificateBasedAccess certificateBasedAccess;

  private final boolean usingGDCH;

  private final String resolvedUniverseDomain;

  private final String resolvedEndpoint;

  private final @Nullable String resolvedServerAddress;

  private final @Nullable Integer resolvedServerPort;

  private AutoValue_EndpointContext(
      @Nullable String serviceName,
      @Nullable String universeDomain,
      @Nullable String clientSettingsEndpoint,
      @Nullable String transportChannelProviderEndpoint,
      boolean useS2A,
      @Nullable EnvironmentProvider envProvider,
      @Nullable String mtlsEndpoint,
      boolean switchToMtlsEndpointAllowed,
      @Nullable MtlsProvider mtlsProvider,
      @Nullable CertificateBasedAccess certificateBasedAccess,
      boolean usingGDCH,
      String resolvedUniverseDomain,
      String resolvedEndpoint,
      @Nullable String resolvedServerAddress,
      @Nullable Integer resolvedServerPort) {
    this.serviceName = serviceName;
    this.universeDomain = universeDomain;
    this.clientSettingsEndpoint = clientSettingsEndpoint;
    this.transportChannelProviderEndpoint = transportChannelProviderEndpoint;
    this.useS2A = useS2A;
    this.envProvider = envProvider;
    this.mtlsEndpoint = mtlsEndpoint;
    this.switchToMtlsEndpointAllowed = switchToMtlsEndpointAllowed;
    this.mtlsProvider = mtlsProvider;
    this.certificateBasedAccess = certificateBasedAccess;
    this.usingGDCH = usingGDCH;
    this.resolvedUniverseDomain = resolvedUniverseDomain;
    this.resolvedEndpoint = resolvedEndpoint;
    this.resolvedServerAddress = resolvedServerAddress;
    this.resolvedServerPort = resolvedServerPort;
  }

  @Override
  public @Nullable String serviceName() {
    return serviceName;
  }

  @Override
  public @Nullable String universeDomain() {
    return universeDomain;
  }

  @Override
  public @Nullable String clientSettingsEndpoint() {
    return clientSettingsEndpoint;
  }

  @Override
  public @Nullable String transportChannelProviderEndpoint() {
    return transportChannelProviderEndpoint;
  }

  @Override
  boolean useS2A() {
    return useS2A;
  }

  @Override
  @Nullable EnvironmentProvider envProvider() {
    return envProvider;
  }

  @Override
  public @Nullable String mtlsEndpoint() {
    return mtlsEndpoint;
  }

  @Override
  public boolean switchToMtlsEndpointAllowed() {
    return switchToMtlsEndpointAllowed;
  }

  @Override
  public @Nullable MtlsProvider mtlsProvider() {
    return mtlsProvider;
  }

  @Override
  @Nullable CertificateBasedAccess certificateBasedAccess() {
    return certificateBasedAccess;
  }

  @Override
  public boolean usingGDCH() {
    return usingGDCH;
  }

  @Override
  String resolvedUniverseDomain() {
    return resolvedUniverseDomain;
  }

  @Override
  public String resolvedEndpoint() {
    return resolvedEndpoint;
  }

  @Override
  public @Nullable String resolvedServerAddress() {
    return resolvedServerAddress;
  }

  @Override
  public @Nullable Integer resolvedServerPort() {
    return resolvedServerPort;
  }

  @Override
  public String toString() {
    return "EndpointContext{"
        + "serviceName=" + serviceName + ", "
        + "universeDomain=" + universeDomain + ", "
        + "clientSettingsEndpoint=" + clientSettingsEndpoint + ", "
        + "transportChannelProviderEndpoint=" + transportChannelProviderEndpoint + ", "
        + "useS2A=" + useS2A + ", "
        + "envProvider=" + envProvider + ", "
        + "mtlsEndpoint=" + mtlsEndpoint + ", "
        + "switchToMtlsEndpointAllowed=" + switchToMtlsEndpointAllowed + ", "
        + "mtlsProvider=" + mtlsProvider + ", "
        + "certificateBasedAccess=" + certificateBasedAccess + ", "
        + "usingGDCH=" + usingGDCH + ", "
        + "resolvedUniverseDomain=" + resolvedUniverseDomain + ", "
        + "resolvedEndpoint=" + resolvedEndpoint + ", "
        + "resolvedServerAddress=" + resolvedServerAddress + ", "
        + "resolvedServerPort=" + resolvedServerPort
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof EndpointContext) {
      EndpointContext that = (EndpointContext) o;
      return (this.serviceName == null ? that.serviceName() == null : this.serviceName.equals(that.serviceName()))
          && (this.universeDomain == null ? that.universeDomain() == null : this.universeDomain.equals(that.universeDomain()))
          && (this.clientSettingsEndpoint == null ? that.clientSettingsEndpoint() == null : this.clientSettingsEndpoint.equals(that.clientSettingsEndpoint()))
          && (this.transportChannelProviderEndpoint == null ? that.transportChannelProviderEndpoint() == null : this.transportChannelProviderEndpoint.equals(that.transportChannelProviderEndpoint()))
          && this.useS2A == that.useS2A()
          && (this.envProvider == null ? that.envProvider() == null : this.envProvider.equals(that.envProvider()))
          && (this.mtlsEndpoint == null ? that.mtlsEndpoint() == null : this.mtlsEndpoint.equals(that.mtlsEndpoint()))
          && this.switchToMtlsEndpointAllowed == that.switchToMtlsEndpointAllowed()
          && (this.mtlsProvider == null ? that.mtlsProvider() == null : this.mtlsProvider.equals(that.mtlsProvider()))
          && (this.certificateBasedAccess == null ? that.certificateBasedAccess() == null : this.certificateBasedAccess.equals(that.certificateBasedAccess()))
          && this.usingGDCH == that.usingGDCH()
          && this.resolvedUniverseDomain.equals(that.resolvedUniverseDomain())
          && this.resolvedEndpoint.equals(that.resolvedEndpoint())
          && (this.resolvedServerAddress == null ? that.resolvedServerAddress() == null : this.resolvedServerAddress.equals(that.resolvedServerAddress()))
          && (this.resolvedServerPort == null ? that.resolvedServerPort() == null : this.resolvedServerPort.equals(that.resolvedServerPort()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (serviceName == null) ? 0 : serviceName.hashCode();
    h$ *= 1000003;
    h$ ^= (universeDomain == null) ? 0 : universeDomain.hashCode();
    h$ *= 1000003;
    h$ ^= (clientSettingsEndpoint == null) ? 0 : clientSettingsEndpoint.hashCode();
    h$ *= 1000003;
    h$ ^= (transportChannelProviderEndpoint == null) ? 0 : transportChannelProviderEndpoint.hashCode();
    h$ *= 1000003;
    h$ ^= useS2A ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= (envProvider == null) ? 0 : envProvider.hashCode();
    h$ *= 1000003;
    h$ ^= (mtlsEndpoint == null) ? 0 : mtlsEndpoint.hashCode();
    h$ *= 1000003;
    h$ ^= switchToMtlsEndpointAllowed ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= (mtlsProvider == null) ? 0 : mtlsProvider.hashCode();
    h$ *= 1000003;
    h$ ^= (certificateBasedAccess == null) ? 0 : certificateBasedAccess.hashCode();
    h$ *= 1000003;
    h$ ^= usingGDCH ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= resolvedUniverseDomain.hashCode();
    h$ *= 1000003;
    h$ ^= resolvedEndpoint.hashCode();
    h$ *= 1000003;
    h$ ^= (resolvedServerAddress == null) ? 0 : resolvedServerAddress.hashCode();
    h$ *= 1000003;
    h$ ^= (resolvedServerPort == null) ? 0 : resolvedServerPort.hashCode();
    return h$;
  }

  @Override
  public EndpointContext.Builder toBuilder() {
    return new AutoValue_EndpointContext.Builder(this);
  }

  static final class Builder extends EndpointContext.Builder {
    private @Nullable String serviceName;
    private @Nullable String universeDomain;
    private @Nullable String clientSettingsEndpoint;
    private @Nullable String transportChannelProviderEndpoint;
    private boolean useS2A;
    private @Nullable EnvironmentProvider envProvider;
    private @Nullable String mtlsEndpoint;
    private boolean switchToMtlsEndpointAllowed;
    private @Nullable MtlsProvider mtlsProvider;
    private @Nullable CertificateBasedAccess certificateBasedAccess;
    private boolean usingGDCH;
    private @Nullable String resolvedUniverseDomain;
    private @Nullable String resolvedEndpoint;
    private @Nullable String resolvedServerAddress;
    private @Nullable Integer resolvedServerPort;
    private byte set$0;
    Builder() {
    }
    Builder(EndpointContext source) {
      this.serviceName = source.serviceName();
      this.universeDomain = source.universeDomain();
      this.clientSettingsEndpoint = source.clientSettingsEndpoint();
      this.transportChannelProviderEndpoint = source.transportChannelProviderEndpoint();
      this.useS2A = source.useS2A();
      this.envProvider = source.envProvider();
      this.mtlsEndpoint = source.mtlsEndpoint();
      this.switchToMtlsEndpointAllowed = source.switchToMtlsEndpointAllowed();
      this.mtlsProvider = source.mtlsProvider();
      this.certificateBasedAccess = source.certificateBasedAccess();
      this.usingGDCH = source.usingGDCH();
      this.resolvedUniverseDomain = source.resolvedUniverseDomain();
      this.resolvedEndpoint = source.resolvedEndpoint();
      this.resolvedServerAddress = source.resolvedServerAddress();
      this.resolvedServerPort = source.resolvedServerPort();
      set$0 = (byte) 7;
    }
    @Override
    public EndpointContext.Builder setServiceName(String serviceName) {
      this.serviceName = serviceName;
      return this;
    }
    @Override
    String serviceName() {
      return serviceName;
    }
    @Override
    public EndpointContext.Builder setUniverseDomain(String universeDomain) {
      this.universeDomain = universeDomain;
      return this;
    }
    @Override
    String universeDomain() {
      return universeDomain;
    }
    @Override
    public EndpointContext.Builder setClientSettingsEndpoint(String clientSettingsEndpoint) {
      this.clientSettingsEndpoint = clientSettingsEndpoint;
      return this;
    }
    @Override
    String clientSettingsEndpoint() {
      return clientSettingsEndpoint;
    }
    @Override
    public EndpointContext.Builder setTransportChannelProviderEndpoint(String transportChannelProviderEndpoint) {
      this.transportChannelProviderEndpoint = transportChannelProviderEndpoint;
      return this;
    }
    @Override
    String transportChannelProviderEndpoint() {
      return transportChannelProviderEndpoint;
    }
    @Override
    EndpointContext.Builder setUseS2A(boolean useS2A) {
      this.useS2A = useS2A;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    boolean useS2A() {
      if ((set$0 & 1) == 0) {
        throw new IllegalStateException("Property \"useS2A\" has not been set");
      }
      return useS2A;
    }
    @Override
    EndpointContext.Builder setEnvProvider(EnvironmentProvider envProvider) {
      this.envProvider = envProvider;
      return this;
    }
    @Override
    EnvironmentProvider envProvider() {
      return envProvider;
    }
    @Override
    public EndpointContext.Builder setMtlsEndpoint(String mtlsEndpoint) {
      this.mtlsEndpoint = mtlsEndpoint;
      return this;
    }
    @Override
    String mtlsEndpoint() {
      return mtlsEndpoint;
    }
    @Override
    public EndpointContext.Builder setSwitchToMtlsEndpointAllowed(boolean switchToMtlsEndpointAllowed) {
      this.switchToMtlsEndpointAllowed = switchToMtlsEndpointAllowed;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    boolean switchToMtlsEndpointAllowed() {
      if ((set$0 & 2) == 0) {
        throw new IllegalStateException("Property \"switchToMtlsEndpointAllowed\" has not been set");
      }
      return switchToMtlsEndpointAllowed;
    }
    @Override
    public EndpointContext.Builder setMtlsProvider(MtlsProvider mtlsProvider) {
      this.mtlsProvider = mtlsProvider;
      return this;
    }
    @Override
    @Nullable MtlsProvider mtlsProvider() {
      return mtlsProvider;
    }
    @Override
    EndpointContext.Builder setCertificateBasedAccess(CertificateBasedAccess certificateBasedAccess) {
      this.certificateBasedAccess = certificateBasedAccess;
      return this;
    }
    @Override
    CertificateBasedAccess certificateBasedAccess() {
      return certificateBasedAccess;
    }
    @Override
    public EndpointContext.Builder setUsingGDCH(boolean usingGDCH) {
      this.usingGDCH = usingGDCH;
      set$0 |= (byte) 4;
      return this;
    }
    @Override
    boolean usingGDCH() {
      if ((set$0 & 4) == 0) {
        throw new IllegalStateException("Property \"usingGDCH\" has not been set");
      }
      return usingGDCH;
    }
    @Override
    public EndpointContext.Builder setResolvedUniverseDomain(String resolvedUniverseDomain) {
      if (resolvedUniverseDomain == null) {
        throw new NullPointerException("Null resolvedUniverseDomain");
      }
      this.resolvedUniverseDomain = resolvedUniverseDomain;
      return this;
    }
    @Override
    String resolvedUniverseDomain() {
      if (this.resolvedUniverseDomain == null) {
        throw new IllegalStateException("Property \"resolvedUniverseDomain\" has not been set");
      }
      return resolvedUniverseDomain;
    }
    @Override
    public EndpointContext.Builder setResolvedEndpoint(String resolvedEndpoint) {
      if (resolvedEndpoint == null) {
        throw new NullPointerException("Null resolvedEndpoint");
      }
      this.resolvedEndpoint = resolvedEndpoint;
      return this;
    }
    @Override
    String resolvedEndpoint() {
      if (this.resolvedEndpoint == null) {
        throw new IllegalStateException("Property \"resolvedEndpoint\" has not been set");
      }
      return resolvedEndpoint;
    }
    @Override
    public EndpointContext.Builder setResolvedServerAddress(String resolvedServerAddress) {
      this.resolvedServerAddress = resolvedServerAddress;
      return this;
    }
    @Override
    public EndpointContext.Builder setResolvedServerPort(Integer resolvedServerPort) {
      this.resolvedServerPort = resolvedServerPort;
      return this;
    }
    @Override
    EndpointContext autoBuild() {
      if (set$0 != 7
          || this.resolvedUniverseDomain == null
          || this.resolvedEndpoint == null) {
        StringBuilder missing = new StringBuilder();
        if ((set$0 & 1) == 0) {
          missing.append(" useS2A");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" switchToMtlsEndpointAllowed");
        }
        if ((set$0 & 4) == 0) {
          missing.append(" usingGDCH");
        }
        if (this.resolvedUniverseDomain == null) {
          missing.append(" resolvedUniverseDomain");
        }
        if (this.resolvedEndpoint == null) {
          missing.append(" resolvedEndpoint");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_EndpointContext(
          this.serviceName,
          this.universeDomain,
          this.clientSettingsEndpoint,
          this.transportChannelProviderEndpoint,
          this.useS2A,
          this.envProvider,
          this.mtlsEndpoint,
          this.switchToMtlsEndpointAllowed,
          this.mtlsProvider,
          this.certificateBasedAccess,
          this.usingGDCH,
          this.resolvedUniverseDomain,
          this.resolvedEndpoint,
          this.resolvedServerAddress,
          this.resolvedServerPort);
    }
  }

}
