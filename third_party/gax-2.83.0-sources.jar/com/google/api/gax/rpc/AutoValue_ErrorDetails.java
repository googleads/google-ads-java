package com.google.api.gax.rpc;

import com.google.protobuf.Any;
import java.util.List;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ErrorDetails extends ErrorDetails {

  private final @Nullable List<Any> rawErrorMessages;

  private AutoValue_ErrorDetails(
      @Nullable List<Any> rawErrorMessages) {
    this.rawErrorMessages = rawErrorMessages;
  }

  @Override
  @Nullable List<Any> getRawErrorMessages() {
    return rawErrorMessages;
  }

  @Override
  public String toString() {
    return "ErrorDetails{"
        + "rawErrorMessages=" + rawErrorMessages
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ErrorDetails) {
      ErrorDetails that = (ErrorDetails) o;
      return (this.rawErrorMessages == null ? that.getRawErrorMessages() == null : this.rawErrorMessages.equals(that.getRawErrorMessages()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (rawErrorMessages == null) ? 0 : rawErrorMessages.hashCode();
    return h$;
  }

  static final class Builder extends ErrorDetails.Builder {
    private @Nullable List<Any> rawErrorMessages;
    Builder() {
    }
    @Override
    public ErrorDetails.Builder setRawErrorMessages(List<Any> rawErrorMessages) {
      this.rawErrorMessages = rawErrorMessages;
      return this;
    }
    @Override
    public ErrorDetails build() {
      return new AutoValue_ErrorDetails(
          this.rawErrorMessages);
    }
  }

}
