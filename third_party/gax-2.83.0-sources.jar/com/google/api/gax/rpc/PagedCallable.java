/*
 * Copyright 2016 Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.google.api.gax.rpc;

import com.google.api.core.ApiFuture;
import com.google.api.core.InternalApi;
import com.google.common.base.Preconditions;
import org.jspecify.annotations.NullMarked;

/**
 * A UnaryCallable which provides page streaming functionality for unary calls.
 *
 * <p>Public for technical reasons - for advanced usage.
 */
@NullMarked
@InternalApi("For use by transport-specific implementations")
public class PagedCallable<RequestT, ResponseT, PagedListResponseT>
    extends UnaryCallable<RequestT, PagedListResponseT> {
  private final UnaryCallable<RequestT, ResponseT> callable;
  private final PagedListResponseFactory<RequestT, ResponseT, PagedListResponseT>
      pagedListResponseFactory;

  public PagedCallable(
      UnaryCallable<RequestT, ResponseT> callable,
      PagedListResponseFactory<RequestT, ResponseT, PagedListResponseT> pagedListResponseFactory) {
    this.callable = Preconditions.checkNotNull(callable);
    this.pagedListResponseFactory = pagedListResponseFactory;
  }

  @Override
  public String toString() {
    return String.format("paged(%s)", callable);
  }

  @Override
  public ApiFuture<PagedListResponseT> futureCall(RequestT request, ApiCallContext context) {
    ApiFuture<ResponseT> futureResponse = callable.futureCall(request, context);
    return pagedListResponseFactory.getFuturePagedResponse(
        callable.withDefaultCallContext(context), request, context, futureResponse);
  }
}
