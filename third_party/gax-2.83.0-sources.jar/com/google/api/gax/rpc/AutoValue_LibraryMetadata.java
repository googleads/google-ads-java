package com.google.api.gax.rpc;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_LibraryMetadata extends LibraryMetadata {

  private final @Nullable String repository;

  private final @Nullable String artifactName;

  private final @Nullable String version;

  private AutoValue_LibraryMetadata(
      @Nullable String repository,
      @Nullable String artifactName,
      @Nullable String version) {
    this.repository = repository;
    this.artifactName = artifactName;
    this.version = version;
  }

  @Override
  public @Nullable String repository() {
    return repository;
  }

  @Override
  public @Nullable String artifactName() {
    return artifactName;
  }

  @Override
  public @Nullable String version() {
    return version;
  }

  @Override
  public String toString() {
    return "LibraryMetadata{"
        + "repository=" + repository + ", "
        + "artifactName=" + artifactName + ", "
        + "version=" + version
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof LibraryMetadata) {
      LibraryMetadata that = (LibraryMetadata) o;
      return (this.repository == null ? that.repository() == null : this.repository.equals(that.repository()))
          && (this.artifactName == null ? that.artifactName() == null : this.artifactName.equals(that.artifactName()))
          && (this.version == null ? that.version() == null : this.version.equals(that.version()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (repository == null) ? 0 : repository.hashCode();
    h$ *= 1000003;
    h$ ^= (artifactName == null) ? 0 : artifactName.hashCode();
    h$ *= 1000003;
    h$ ^= (version == null) ? 0 : version.hashCode();
    return h$;
  }

  static final class Builder extends LibraryMetadata.Builder {
    private @Nullable String repository;
    private @Nullable String artifactName;
    private @Nullable String version;
    Builder() {
    }
    @Override
    public LibraryMetadata.Builder setRepository(@Nullable String repository) {
      this.repository = repository;
      return this;
    }
    @Override
    public LibraryMetadata.Builder setArtifactName(@Nullable String artifactName) {
      this.artifactName = artifactName;
      return this;
    }
    @Override
    public LibraryMetadata.Builder setVersion(@Nullable String version) {
      this.version = version;
      return this;
    }
    @Override
    public LibraryMetadata build() {
      return new AutoValue_LibraryMetadata(
          this.repository,
          this.artifactName,
          this.version);
    }
  }

}
