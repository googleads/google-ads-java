package com.google.api.gax.rpc;

import com.google.api.core.ApiClock;
import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.tracing.ApiTracerFactory;
import com.google.auth.Credentials;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ScheduledExecutorService;
import javax.annotation.Generated;
import javax.annotation.Nonnull;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClientContext extends ClientContext {

  private final List<BackgroundResource> backgroundResources;

  private final ScheduledExecutorService executor;

  private final @Nullable Credentials credentials;

  private final @Nullable TransportChannel transportChannel;

  private final Map<String, String> headers;

  private final Map<String, String> internalHeaders;

  private final ApiClock clock;

  private final ApiCallContext defaultCallContext;

  private final @Nullable Watchdog streamWatchdog;

  private final Duration streamWatchdogCheckIntervalDuration;

  private final @Nullable String universeDomain;

  private final @Nullable String endpoint;

  private final @Nullable String quotaProjectId;

  private final EndpointContext endpointContext;

  private final ApiTracerFactory tracerFactory;

  private final @Nullable String gdchApiAudience;

  private AutoValue_ClientContext(
      List<BackgroundResource> backgroundResources,
      ScheduledExecutorService executor,
      @Nullable Credentials credentials,
      @Nullable TransportChannel transportChannel,
      Map<String, String> headers,
      Map<String, String> internalHeaders,
      ApiClock clock,
      ApiCallContext defaultCallContext,
      @Nullable Watchdog streamWatchdog,
      Duration streamWatchdogCheckIntervalDuration,
      @Nullable String universeDomain,
      @Nullable String endpoint,
      @Nullable String quotaProjectId,
      EndpointContext endpointContext,
      ApiTracerFactory tracerFactory,
      @Nullable String gdchApiAudience) {
    this.backgroundResources = backgroundResources;
    this.executor = executor;
    this.credentials = credentials;
    this.transportChannel = transportChannel;
    this.headers = headers;
    this.internalHeaders = internalHeaders;
    this.clock = clock;
    this.defaultCallContext = defaultCallContext;
    this.streamWatchdog = streamWatchdog;
    this.streamWatchdogCheckIntervalDuration = streamWatchdogCheckIntervalDuration;
    this.universeDomain = universeDomain;
    this.endpoint = endpoint;
    this.quotaProjectId = quotaProjectId;
    this.endpointContext = endpointContext;
    this.tracerFactory = tracerFactory;
    this.gdchApiAudience = gdchApiAudience;
  }

  @Override
  public List<BackgroundResource> getBackgroundResources() {
    return backgroundResources;
  }

  @Override
  public ScheduledExecutorService getExecutor() {
    return executor;
  }

  @Override
  public @Nullable Credentials getCredentials() {
    return credentials;
  }

  @Override
  public @Nullable TransportChannel getTransportChannel() {
    return transportChannel;
  }

  @Override
  public Map<String, String> getHeaders() {
    return headers;
  }

  @Override
  protected Map<String, String> getInternalHeaders() {
    return internalHeaders;
  }

  @Override
  public ApiClock getClock() {
    return clock;
  }

  @Override
  public ApiCallContext getDefaultCallContext() {
    return defaultCallContext;
  }

  @Override
  public @Nullable Watchdog getStreamWatchdog() {
    return streamWatchdog;
  }

  @Nonnull
  @Override
  public Duration getStreamWatchdogCheckIntervalDuration() {
    return streamWatchdogCheckIntervalDuration;
  }

  @Override
  public @Nullable String getUniverseDomain() {
    return universeDomain;
  }

  @Override
  public @Nullable String getEndpoint() {
    return endpoint;
  }

  @Override
  public @Nullable String getQuotaProjectId() {
    return quotaProjectId;
  }

  @Override
  EndpointContext getEndpointContext() {
    return endpointContext;
  }

  @BetaApi("The surface for tracing is not stable yet and may change in the future.")
  @Nonnull
  @Override
  public ApiTracerFactory getTracerFactory() {
    return tracerFactory;
  }

  @Override
  public @Nullable String getGdchApiAudience() {
    return gdchApiAudience;
  }

  @Override
  public String toString() {
    return "ClientContext{"
        + "backgroundResources=" + backgroundResources + ", "
        + "executor=" + executor + ", "
        + "credentials=" + credentials + ", "
        + "transportChannel=" + transportChannel + ", "
        + "headers=" + headers + ", "
        + "internalHeaders=" + internalHeaders + ", "
        + "clock=" + clock + ", "
        + "defaultCallContext=" + defaultCallContext + ", "
        + "streamWatchdog=" + streamWatchdog + ", "
        + "streamWatchdogCheckIntervalDuration=" + streamWatchdogCheckIntervalDuration + ", "
        + "universeDomain=" + universeDomain + ", "
        + "endpoint=" + endpoint + ", "
        + "quotaProjectId=" + quotaProjectId + ", "
        + "endpointContext=" + endpointContext + ", "
        + "tracerFactory=" + tracerFactory + ", "
        + "gdchApiAudience=" + gdchApiAudience
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClientContext) {
      ClientContext that = (ClientContext) o;
      return this.backgroundResources.equals(that.getBackgroundResources())
          && this.executor.equals(that.getExecutor())
          && (this.credentials == null ? that.getCredentials() == null : this.credentials.equals(that.getCredentials()))
          && (this.transportChannel == null ? that.getTransportChannel() == null : this.transportChannel.equals(that.getTransportChannel()))
          && this.headers.equals(that.getHeaders())
          && this.internalHeaders.equals(that.getInternalHeaders())
          && this.clock.equals(that.getClock())
          && this.defaultCallContext.equals(that.getDefaultCallContext())
          && (this.streamWatchdog == null ? that.getStreamWatchdog() == null : this.streamWatchdog.equals(that.getStreamWatchdog()))
          && this.streamWatchdogCheckIntervalDuration.equals(that.getStreamWatchdogCheckIntervalDuration())
          && (this.universeDomain == null ? that.getUniverseDomain() == null : this.universeDomain.equals(that.getUniverseDomain()))
          && (this.endpoint == null ? that.getEndpoint() == null : this.endpoint.equals(that.getEndpoint()))
          && (this.quotaProjectId == null ? that.getQuotaProjectId() == null : this.quotaProjectId.equals(that.getQuotaProjectId()))
          && this.endpointContext.equals(that.getEndpointContext())
          && this.tracerFactory.equals(that.getTracerFactory())
          && (this.gdchApiAudience == null ? that.getGdchApiAudience() == null : this.gdchApiAudience.equals(that.getGdchApiAudience()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= backgroundResources.hashCode();
    h$ *= 1000003;
    h$ ^= executor.hashCode();
    h$ *= 1000003;
    h$ ^= (credentials == null) ? 0 : credentials.hashCode();
    h$ *= 1000003;
    h$ ^= (transportChannel == null) ? 0 : transportChannel.hashCode();
    h$ *= 1000003;
    h$ ^= headers.hashCode();
    h$ *= 1000003;
    h$ ^= internalHeaders.hashCode();
    h$ *= 1000003;
    h$ ^= clock.hashCode();
    h$ *= 1000003;
    h$ ^= defaultCallContext.hashCode();
    h$ *= 1000003;
    h$ ^= (streamWatchdog == null) ? 0 : streamWatchdog.hashCode();
    h$ *= 1000003;
    h$ ^= streamWatchdogCheckIntervalDuration.hashCode();
    h$ *= 1000003;
    h$ ^= (universeDomain == null) ? 0 : universeDomain.hashCode();
    h$ *= 1000003;
    h$ ^= (endpoint == null) ? 0 : endpoint.hashCode();
    h$ *= 1000003;
    h$ ^= (quotaProjectId == null) ? 0 : quotaProjectId.hashCode();
    h$ *= 1000003;
    h$ ^= endpointContext.hashCode();
    h$ *= 1000003;
    h$ ^= tracerFactory.hashCode();
    h$ *= 1000003;
    h$ ^= (gdchApiAudience == null) ? 0 : gdchApiAudience.hashCode();
    return h$;
  }

  @Override
  public ClientContext.Builder toBuilder() {
    return new AutoValue_ClientContext.Builder(this);
  }

  static final class Builder extends ClientContext.Builder {
    private @Nullable List<BackgroundResource> backgroundResources;
    private @Nullable ScheduledExecutorService executor;
    private @Nullable Credentials credentials;
    private @Nullable TransportChannel transportChannel;
    private @Nullable Map<String, String> headers;
    private @Nullable Map<String, String> internalHeaders;
    private @Nullable ApiClock clock;
    private @Nullable ApiCallContext defaultCallContext;
    private @Nullable Watchdog streamWatchdog;
    private @Nullable Duration streamWatchdogCheckIntervalDuration;
    private @Nullable String universeDomain;
    private @Nullable String endpoint;
    private @Nullable String quotaProjectId;
    private @Nullable EndpointContext endpointContext;
    private @Nullable ApiTracerFactory tracerFactory;
    private @Nullable String gdchApiAudience;
    Builder() {
    }
    Builder(ClientContext source) {
      this.backgroundResources = source.getBackgroundResources();
      this.executor = source.getExecutor();
      this.credentials = source.getCredentials();
      this.transportChannel = source.getTransportChannel();
      this.headers = source.getHeaders();
      this.internalHeaders = source.getInternalHeaders();
      this.clock = source.getClock();
      this.defaultCallContext = source.getDefaultCallContext();
      this.streamWatchdog = source.getStreamWatchdog();
      this.streamWatchdogCheckIntervalDuration = source.getStreamWatchdogCheckIntervalDuration();
      this.universeDomain = source.getUniverseDomain();
      this.endpoint = source.getEndpoint();
      this.quotaProjectId = source.getQuotaProjectId();
      this.endpointContext = source.getEndpointContext();
      this.tracerFactory = source.getTracerFactory();
      this.gdchApiAudience = source.getGdchApiAudience();
    }
    @Override
    public ClientContext.Builder setBackgroundResources(List<BackgroundResource> backgroundResources) {
      if (backgroundResources == null) {
        throw new NullPointerException("Null backgroundResources");
      }
      this.backgroundResources = backgroundResources;
      return this;
    }
    @Override
    public ClientContext.Builder setExecutor(ScheduledExecutorService executor) {
      if (executor == null) {
        throw new NullPointerException("Null executor");
      }
      this.executor = executor;
      return this;
    }
    @Override
    public ClientContext.Builder setCredentials(Credentials credentials) {
      this.credentials = credentials;
      return this;
    }
    @Override
    public ClientContext.Builder setTransportChannel(TransportChannel transportChannel) {
      this.transportChannel = transportChannel;
      return this;
    }
    @Override
    public ClientContext.Builder setHeaders(Map<String, String> headers) {
      if (headers == null) {
        throw new NullPointerException("Null headers");
      }
      this.headers = headers;
      return this;
    }
    @Override
    protected ClientContext.Builder setInternalHeaders(Map<String, String> internalHeaders) {
      if (internalHeaders == null) {
        throw new NullPointerException("Null internalHeaders");
      }
      this.internalHeaders = internalHeaders;
      return this;
    }
    @Override
    public ClientContext.Builder setClock(ApiClock clock) {
      if (clock == null) {
        throw new NullPointerException("Null clock");
      }
      this.clock = clock;
      return this;
    }
    @Override
    public ClientContext.Builder setDefaultCallContext(ApiCallContext defaultCallContext) {
      if (defaultCallContext == null) {
        throw new NullPointerException("Null defaultCallContext");
      }
      this.defaultCallContext = defaultCallContext;
      return this;
    }
    @Override
    public ClientContext.Builder setStreamWatchdog(@Nullable Watchdog streamWatchdog) {
      this.streamWatchdog = streamWatchdog;
      return this;
    }
    @Override
    public ClientContext.Builder setStreamWatchdogCheckIntervalDuration(Duration streamWatchdogCheckIntervalDuration) {
      if (streamWatchdogCheckIntervalDuration == null) {
        throw new NullPointerException("Null streamWatchdogCheckIntervalDuration");
      }
      this.streamWatchdogCheckIntervalDuration = streamWatchdogCheckIntervalDuration;
      return this;
    }
    @Override
    public ClientContext.Builder setUniverseDomain(String universeDomain) {
      this.universeDomain = universeDomain;
      return this;
    }
    @Override
    public ClientContext.Builder setEndpoint(String endpoint) {
      this.endpoint = endpoint;
      return this;
    }
    @Override
    public ClientContext.Builder setQuotaProjectId(@Nullable String quotaProjectId) {
      this.quotaProjectId = quotaProjectId;
      return this;
    }
    @Override
    ClientContext.Builder setEndpointContext(EndpointContext endpointContext) {
      if (endpointContext == null) {
        throw new NullPointerException("Null endpointContext");
      }
      this.endpointContext = endpointContext;
      return this;
    }
    @Override
    public ClientContext.Builder setTracerFactory(ApiTracerFactory tracerFactory) {
      if (tracerFactory == null) {
        throw new NullPointerException("Null tracerFactory");
      }
      this.tracerFactory = tracerFactory;
      return this;
    }
    @Override
    public ClientContext.Builder setGdchApiAudience(@Nullable String gdchApiAudience) {
      this.gdchApiAudience = gdchApiAudience;
      return this;
    }
    @Override
    public ClientContext build() {
      if (this.backgroundResources == null
          || this.executor == null
          || this.headers == null
          || this.internalHeaders == null
          || this.clock == null
          || this.defaultCallContext == null
          || this.streamWatchdogCheckIntervalDuration == null
          || this.endpointContext == null
          || this.tracerFactory == null) {
        StringBuilder missing = new StringBuilder();
        if (this.backgroundResources == null) {
          missing.append(" backgroundResources");
        }
        if (this.executor == null) {
          missing.append(" executor");
        }
        if (this.headers == null) {
          missing.append(" headers");
        }
        if (this.internalHeaders == null) {
          missing.append(" internalHeaders");
        }
        if (this.clock == null) {
          missing.append(" clock");
        }
        if (this.defaultCallContext == null) {
          missing.append(" defaultCallContext");
        }
        if (this.streamWatchdogCheckIntervalDuration == null) {
          missing.append(" streamWatchdogCheckIntervalDuration");
        }
        if (this.endpointContext == null) {
          missing.append(" endpointContext");
        }
        if (this.tracerFactory == null) {
          missing.append(" tracerFactory");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ClientContext(
          this.backgroundResources,
          this.executor,
          this.credentials,
          this.transportChannel,
          this.headers,
          this.internalHeaders,
          this.clock,
          this.defaultCallContext,
          this.streamWatchdog,
          this.streamWatchdogCheckIntervalDuration,
          this.universeDomain,
          this.endpoint,
          this.quotaProjectId,
          this.endpointContext,
          this.tracerFactory,
          this.gdchApiAudience);
    }
  }

}
