package com.google.api.gax.core;

import com.google.auth.Credentials;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_FixedCredentialsProvider extends FixedCredentialsProvider {

  private final @Nullable Credentials credentials;

  AutoValue_FixedCredentialsProvider(
      @Nullable Credentials credentials) {
    this.credentials = credentials;
  }

  @Override
  public @Nullable Credentials getCredentials() {
    return credentials;
  }

  @Override
  public String toString() {
    return "FixedCredentialsProvider{"
        + "credentials=" + credentials
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof FixedCredentialsProvider) {
      FixedCredentialsProvider that = (FixedCredentialsProvider) o;
      return (this.credentials == null ? that.getCredentials() == null : this.credentials.equals(that.getCredentials()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (credentials == null) ? 0 : credentials.hashCode();
    return h$;
  }

}
