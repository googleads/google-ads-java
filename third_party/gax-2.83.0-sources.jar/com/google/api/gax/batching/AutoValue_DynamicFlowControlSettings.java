package com.google.api.gax.batching;

import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_DynamicFlowControlSettings extends DynamicFlowControlSettings {

  private final @Nullable Long initialOutstandingElementCount;

  private final @Nullable Long initialOutstandingRequestBytes;

  private final @Nullable Long maxOutstandingElementCount;

  private final @Nullable Long maxOutstandingRequestBytes;

  private final @Nullable Long minOutstandingElementCount;

  private final @Nullable Long minOutstandingRequestBytes;

  private final FlowController.LimitExceededBehavior limitExceededBehavior;

  private AutoValue_DynamicFlowControlSettings(
      @Nullable Long initialOutstandingElementCount,
      @Nullable Long initialOutstandingRequestBytes,
      @Nullable Long maxOutstandingElementCount,
      @Nullable Long maxOutstandingRequestBytes,
      @Nullable Long minOutstandingElementCount,
      @Nullable Long minOutstandingRequestBytes,
      FlowController.LimitExceededBehavior limitExceededBehavior) {
    this.initialOutstandingElementCount = initialOutstandingElementCount;
    this.initialOutstandingRequestBytes = initialOutstandingRequestBytes;
    this.maxOutstandingElementCount = maxOutstandingElementCount;
    this.maxOutstandingRequestBytes = maxOutstandingRequestBytes;
    this.minOutstandingElementCount = minOutstandingElementCount;
    this.minOutstandingRequestBytes = minOutstandingRequestBytes;
    this.limitExceededBehavior = limitExceededBehavior;
  }

  @Override
  public @Nullable Long getInitialOutstandingElementCount() {
    return initialOutstandingElementCount;
  }

  @Override
  public @Nullable Long getInitialOutstandingRequestBytes() {
    return initialOutstandingRequestBytes;
  }

  @Override
  public @Nullable Long getMaxOutstandingElementCount() {
    return maxOutstandingElementCount;
  }

  @Override
  public @Nullable Long getMaxOutstandingRequestBytes() {
    return maxOutstandingRequestBytes;
  }

  @Override
  public @Nullable Long getMinOutstandingElementCount() {
    return minOutstandingElementCount;
  }

  @Override
  public @Nullable Long getMinOutstandingRequestBytes() {
    return minOutstandingRequestBytes;
  }

  @Override
  public FlowController.LimitExceededBehavior getLimitExceededBehavior() {
    return limitExceededBehavior;
  }

  @Override
  public String toString() {
    return "DynamicFlowControlSettings{"
        + "initialOutstandingElementCount=" + initialOutstandingElementCount + ", "
        + "initialOutstandingRequestBytes=" + initialOutstandingRequestBytes + ", "
        + "maxOutstandingElementCount=" + maxOutstandingElementCount + ", "
        + "maxOutstandingRequestBytes=" + maxOutstandingRequestBytes + ", "
        + "minOutstandingElementCount=" + minOutstandingElementCount + ", "
        + "minOutstandingRequestBytes=" + minOutstandingRequestBytes + ", "
        + "limitExceededBehavior=" + limitExceededBehavior
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof DynamicFlowControlSettings) {
      DynamicFlowControlSettings that = (DynamicFlowControlSettings) o;
      return (this.initialOutstandingElementCount == null ? that.getInitialOutstandingElementCount() == null : this.initialOutstandingElementCount.equals(that.getInitialOutstandingElementCount()))
          && (this.initialOutstandingRequestBytes == null ? that.getInitialOutstandingRequestBytes() == null : this.initialOutstandingRequestBytes.equals(that.getInitialOutstandingRequestBytes()))
          && (this.maxOutstandingElementCount == null ? that.getMaxOutstandingElementCount() == null : this.maxOutstandingElementCount.equals(that.getMaxOutstandingElementCount()))
          && (this.maxOutstandingRequestBytes == null ? that.getMaxOutstandingRequestBytes() == null : this.maxOutstandingRequestBytes.equals(that.getMaxOutstandingRequestBytes()))
          && (this.minOutstandingElementCount == null ? that.getMinOutstandingElementCount() == null : this.minOutstandingElementCount.equals(that.getMinOutstandingElementCount()))
          && (this.minOutstandingRequestBytes == null ? that.getMinOutstandingRequestBytes() == null : this.minOutstandingRequestBytes.equals(that.getMinOutstandingRequestBytes()))
          && this.limitExceededBehavior.equals(that.getLimitExceededBehavior());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (initialOutstandingElementCount == null) ? 0 : initialOutstandingElementCount.hashCode();
    h$ *= 1000003;
    h$ ^= (initialOutstandingRequestBytes == null) ? 0 : initialOutstandingRequestBytes.hashCode();
    h$ *= 1000003;
    h$ ^= (maxOutstandingElementCount == null) ? 0 : maxOutstandingElementCount.hashCode();
    h$ *= 1000003;
    h$ ^= (maxOutstandingRequestBytes == null) ? 0 : maxOutstandingRequestBytes.hashCode();
    h$ *= 1000003;
    h$ ^= (minOutstandingElementCount == null) ? 0 : minOutstandingElementCount.hashCode();
    h$ *= 1000003;
    h$ ^= (minOutstandingRequestBytes == null) ? 0 : minOutstandingRequestBytes.hashCode();
    h$ *= 1000003;
    h$ ^= limitExceededBehavior.hashCode();
    return h$;
  }

  @Override
  public DynamicFlowControlSettings.Builder toBuilder() {
    return new AutoValue_DynamicFlowControlSettings.Builder(this);
  }

  static final class Builder extends DynamicFlowControlSettings.Builder {
    private @Nullable Long initialOutstandingElementCount;
    private @Nullable Long initialOutstandingRequestBytes;
    private @Nullable Long maxOutstandingElementCount;
    private @Nullable Long maxOutstandingRequestBytes;
    private @Nullable Long minOutstandingElementCount;
    private @Nullable Long minOutstandingRequestBytes;
    private FlowController.@Nullable LimitExceededBehavior limitExceededBehavior;
    Builder() {
    }
    Builder(DynamicFlowControlSettings source) {
      this.initialOutstandingElementCount = source.getInitialOutstandingElementCount();
      this.initialOutstandingRequestBytes = source.getInitialOutstandingRequestBytes();
      this.maxOutstandingElementCount = source.getMaxOutstandingElementCount();
      this.maxOutstandingRequestBytes = source.getMaxOutstandingRequestBytes();
      this.minOutstandingElementCount = source.getMinOutstandingElementCount();
      this.minOutstandingRequestBytes = source.getMinOutstandingRequestBytes();
      this.limitExceededBehavior = source.getLimitExceededBehavior();
    }
    @Override
    public DynamicFlowControlSettings.Builder setInitialOutstandingElementCount(Long initialOutstandingElementCount) {
      this.initialOutstandingElementCount = initialOutstandingElementCount;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setInitialOutstandingRequestBytes(Long initialOutstandingRequestBytes) {
      this.initialOutstandingRequestBytes = initialOutstandingRequestBytes;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setMaxOutstandingElementCount(Long maxOutstandingElementCount) {
      this.maxOutstandingElementCount = maxOutstandingElementCount;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setMaxOutstandingRequestBytes(Long maxOutstandingRequestBytes) {
      this.maxOutstandingRequestBytes = maxOutstandingRequestBytes;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setMinOutstandingElementCount(Long minOutstandingElementCount) {
      this.minOutstandingElementCount = minOutstandingElementCount;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setMinOutstandingRequestBytes(Long minOutstandingRequestBytes) {
      this.minOutstandingRequestBytes = minOutstandingRequestBytes;
      return this;
    }
    @Override
    public DynamicFlowControlSettings.Builder setLimitExceededBehavior(FlowController.LimitExceededBehavior limitExceededBehavior) {
      if (limitExceededBehavior == null) {
        throw new NullPointerException("Null limitExceededBehavior");
      }
      this.limitExceededBehavior = limitExceededBehavior;
      return this;
    }
    @Override
    DynamicFlowControlSettings autoBuild() {
      if (this.limitExceededBehavior == null) {
        String missing = " limitExceededBehavior";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_DynamicFlowControlSettings(
          this.initialOutstandingElementCount,
          this.initialOutstandingRequestBytes,
          this.maxOutstandingElementCount,
          this.maxOutstandingRequestBytes,
          this.minOutstandingElementCount,
          this.minOutstandingRequestBytes,
          this.limitExceededBehavior);
    }
  }

}
