package com.google.api.gax.batching;

import java.time.Duration;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_BatchingSettings extends BatchingSettings {

  private final @Nullable Long elementCountThreshold;

  private final @Nullable Long requestByteThreshold;

  private final @Nullable Duration delayThresholdDuration;

  private final Boolean isEnabled;

  private final FlowControlSettings flowControlSettings;

  private AutoValue_BatchingSettings(
      @Nullable Long elementCountThreshold,
      @Nullable Long requestByteThreshold,
      @Nullable Duration delayThresholdDuration,
      Boolean isEnabled,
      FlowControlSettings flowControlSettings) {
    this.elementCountThreshold = elementCountThreshold;
    this.requestByteThreshold = requestByteThreshold;
    this.delayThresholdDuration = delayThresholdDuration;
    this.isEnabled = isEnabled;
    this.flowControlSettings = flowControlSettings;
  }

  @Override
  public @Nullable Long getElementCountThreshold() {
    return elementCountThreshold;
  }

  @Override
  public @Nullable Long getRequestByteThreshold() {
    return requestByteThreshold;
  }

  @Override
  public @Nullable Duration getDelayThresholdDuration() {
    return delayThresholdDuration;
  }

  @Override
  public Boolean getIsEnabled() {
    return isEnabled;
  }

  @Override
  public FlowControlSettings getFlowControlSettings() {
    return flowControlSettings;
  }

  @Override
  public String toString() {
    return "BatchingSettings{"
        + "elementCountThreshold=" + elementCountThreshold + ", "
        + "requestByteThreshold=" + requestByteThreshold + ", "
        + "delayThresholdDuration=" + delayThresholdDuration + ", "
        + "isEnabled=" + isEnabled + ", "
        + "flowControlSettings=" + flowControlSettings
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof BatchingSettings) {
      BatchingSettings that = (BatchingSettings) o;
      return (this.elementCountThreshold == null ? that.getElementCountThreshold() == null : this.elementCountThreshold.equals(that.getElementCountThreshold()))
          && (this.requestByteThreshold == null ? that.getRequestByteThreshold() == null : this.requestByteThreshold.equals(that.getRequestByteThreshold()))
          && (this.delayThresholdDuration == null ? that.getDelayThresholdDuration() == null : this.delayThresholdDuration.equals(that.getDelayThresholdDuration()))
          && this.isEnabled.equals(that.getIsEnabled())
          && this.flowControlSettings.equals(that.getFlowControlSettings());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (elementCountThreshold == null) ? 0 : elementCountThreshold.hashCode();
    h$ *= 1000003;
    h$ ^= (requestByteThreshold == null) ? 0 : requestByteThreshold.hashCode();
    h$ *= 1000003;
    h$ ^= (delayThresholdDuration == null) ? 0 : delayThresholdDuration.hashCode();
    h$ *= 1000003;
    h$ ^= isEnabled.hashCode();
    h$ *= 1000003;
    h$ ^= flowControlSettings.hashCode();
    return h$;
  }

  @Override
  public BatchingSettings.Builder toBuilder() {
    return new AutoValue_BatchingSettings.Builder(this);
  }

  static final class Builder extends BatchingSettings.Builder {
    private @Nullable Long elementCountThreshold;
    private @Nullable Long requestByteThreshold;
    private @Nullable Duration delayThresholdDuration;
    private @Nullable Boolean isEnabled;
    private @Nullable FlowControlSettings flowControlSettings;
    Builder() {
    }
    Builder(BatchingSettings source) {
      this.elementCountThreshold = source.getElementCountThreshold();
      this.requestByteThreshold = source.getRequestByteThreshold();
      this.delayThresholdDuration = source.getDelayThresholdDuration();
      this.isEnabled = source.getIsEnabled();
      this.flowControlSettings = source.getFlowControlSettings();
    }
    @Override
    public BatchingSettings.Builder setElementCountThreshold(Long elementCountThreshold) {
      this.elementCountThreshold = elementCountThreshold;
      return this;
    }
    @Override
    public BatchingSettings.Builder setRequestByteThreshold(Long requestByteThreshold) {
      this.requestByteThreshold = requestByteThreshold;
      return this;
    }
    @Override
    public BatchingSettings.Builder setDelayThresholdDuration(Duration delayThresholdDuration) {
      this.delayThresholdDuration = delayThresholdDuration;
      return this;
    }
    @Override
    public BatchingSettings.Builder setIsEnabled(Boolean isEnabled) {
      if (isEnabled == null) {
        throw new NullPointerException("Null isEnabled");
      }
      this.isEnabled = isEnabled;
      return this;
    }
    @Override
    public BatchingSettings.Builder setFlowControlSettings(FlowControlSettings flowControlSettings) {
      if (flowControlSettings == null) {
        throw new NullPointerException("Null flowControlSettings");
      }
      this.flowControlSettings = flowControlSettings;
      return this;
    }
    @Override
    BatchingSettings autoBuild() {
      if (this.isEnabled == null
          || this.flowControlSettings == null) {
        StringBuilder missing = new StringBuilder();
        if (this.isEnabled == null) {
          missing.append(" isEnabled");
        }
        if (this.flowControlSettings == null) {
          missing.append(" flowControlSettings");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_BatchingSettings(
          this.elementCountThreshold,
          this.requestByteThreshold,
          this.delayThresholdDuration,
          this.isEnabled,
          this.flowControlSettings);
    }
  }

}
