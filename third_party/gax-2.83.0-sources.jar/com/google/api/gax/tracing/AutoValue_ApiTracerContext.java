package com.google.api.gax.tracing;

import com.google.api.gax.rpc.LibraryMetadata;
import java.util.function.Supplier;
import javax.annotation.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ApiTracerContext extends ApiTracerContext {

  private final @Nullable String serverAddress;

  private final @Nullable Integer serverPort;

  private final LibraryMetadata libraryMetadata;

  private final @Nullable String fullMethodName;

  private final ApiTracerContext.@Nullable Transport transport;

  private final ApiTracerFactory.@Nullable OperationType operationType;

  private final @Nullable String httpMethod;

  private final @Nullable String httpPathTemplate;

  private final @Nullable String serviceName;

  private final @Nullable String urlDomain;

  private final @Nullable Supplier<String> destinationResourceIdSupplier;

  private AutoValue_ApiTracerContext(
      @Nullable String serverAddress,
      @Nullable Integer serverPort,
      LibraryMetadata libraryMetadata,
      @Nullable String fullMethodName,
      ApiTracerContext.@Nullable Transport transport,
      ApiTracerFactory.@Nullable OperationType operationType,
      @Nullable String httpMethod,
      @Nullable String httpPathTemplate,
      @Nullable String serviceName,
      @Nullable String urlDomain,
      @Nullable Supplier<String> destinationResourceIdSupplier) {
    this.serverAddress = serverAddress;
    this.serverPort = serverPort;
    this.libraryMetadata = libraryMetadata;
    this.fullMethodName = fullMethodName;
    this.transport = transport;
    this.operationType = operationType;
    this.httpMethod = httpMethod;
    this.httpPathTemplate = httpPathTemplate;
    this.serviceName = serviceName;
    this.urlDomain = urlDomain;
    this.destinationResourceIdSupplier = destinationResourceIdSupplier;
  }

  @Override
  @Nullable String serverAddress() {
    return serverAddress;
  }

  @Override
  @Nullable Integer serverPort() {
    return serverPort;
  }

  @Override
  LibraryMetadata libraryMetadata() {
    return libraryMetadata;
  }

  @Override
  @Nullable String fullMethodName() {
    return fullMethodName;
  }

  @Override
  ApiTracerContext.@Nullable Transport transport() {
    return transport;
  }

  @Override
  ApiTracerFactory.@Nullable OperationType operationType() {
    return operationType;
  }

  @Override
  @Nullable String httpMethod() {
    return httpMethod;
  }

  @Override
  @Nullable String httpPathTemplate() {
    return httpPathTemplate;
  }

  @Override
  @Nullable String serviceName() {
    return serviceName;
  }

  @Override
  @Nullable String urlDomain() {
    return urlDomain;
  }

  @Override
  protected @Nullable Supplier<String> destinationResourceIdSupplier() {
    return destinationResourceIdSupplier;
  }

  @Override
  public String toString() {
    return "ApiTracerContext{"
        + "serverAddress=" + serverAddress + ", "
        + "serverPort=" + serverPort + ", "
        + "libraryMetadata=" + libraryMetadata + ", "
        + "fullMethodName=" + fullMethodName + ", "
        + "transport=" + transport + ", "
        + "operationType=" + operationType + ", "
        + "httpMethod=" + httpMethod + ", "
        + "httpPathTemplate=" + httpPathTemplate + ", "
        + "serviceName=" + serviceName + ", "
        + "urlDomain=" + urlDomain + ", "
        + "destinationResourceIdSupplier=" + destinationResourceIdSupplier
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ApiTracerContext) {
      ApiTracerContext that = (ApiTracerContext) o;
      return (this.serverAddress == null ? that.serverAddress() == null : this.serverAddress.equals(that.serverAddress()))
          && (this.serverPort == null ? that.serverPort() == null : this.serverPort.equals(that.serverPort()))
          && this.libraryMetadata.equals(that.libraryMetadata())
          && (this.fullMethodName == null ? that.fullMethodName() == null : this.fullMethodName.equals(that.fullMethodName()))
          && (this.transport == null ? that.transport() == null : this.transport.equals(that.transport()))
          && (this.operationType == null ? that.operationType() == null : this.operationType.equals(that.operationType()))
          && (this.httpMethod == null ? that.httpMethod() == null : this.httpMethod.equals(that.httpMethod()))
          && (this.httpPathTemplate == null ? that.httpPathTemplate() == null : this.httpPathTemplate.equals(that.httpPathTemplate()))
          && (this.serviceName == null ? that.serviceName() == null : this.serviceName.equals(that.serviceName()))
          && (this.urlDomain == null ? that.urlDomain() == null : this.urlDomain.equals(that.urlDomain()))
          && (this.destinationResourceIdSupplier == null ? that.destinationResourceIdSupplier() == null : this.destinationResourceIdSupplier.equals(that.destinationResourceIdSupplier()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (serverAddress == null) ? 0 : serverAddress.hashCode();
    h$ *= 1000003;
    h$ ^= (serverPort == null) ? 0 : serverPort.hashCode();
    h$ *= 1000003;
    h$ ^= libraryMetadata.hashCode();
    h$ *= 1000003;
    h$ ^= (fullMethodName == null) ? 0 : fullMethodName.hashCode();
    h$ *= 1000003;
    h$ ^= (transport == null) ? 0 : transport.hashCode();
    h$ *= 1000003;
    h$ ^= (operationType == null) ? 0 : operationType.hashCode();
    h$ *= 1000003;
    h$ ^= (httpMethod == null) ? 0 : httpMethod.hashCode();
    h$ *= 1000003;
    h$ ^= (httpPathTemplate == null) ? 0 : httpPathTemplate.hashCode();
    h$ *= 1000003;
    h$ ^= (serviceName == null) ? 0 : serviceName.hashCode();
    h$ *= 1000003;
    h$ ^= (urlDomain == null) ? 0 : urlDomain.hashCode();
    h$ *= 1000003;
    h$ ^= (destinationResourceIdSupplier == null) ? 0 : destinationResourceIdSupplier.hashCode();
    return h$;
  }

  @Override
  ApiTracerContext.Builder toBuilder() {
    return new AutoValue_ApiTracerContext.Builder(this);
  }

  static final class Builder extends ApiTracerContext.Builder {
    private @Nullable String serverAddress;
    private @Nullable Integer serverPort;
    private @Nullable LibraryMetadata libraryMetadata;
    private @Nullable String fullMethodName;
    private ApiTracerContext.@Nullable Transport transport;
    private ApiTracerFactory.@Nullable OperationType operationType;
    private @Nullable String httpMethod;
    private @Nullable String httpPathTemplate;
    private @Nullable String serviceName;
    private @Nullable String urlDomain;
    private @Nullable Supplier<String> destinationResourceIdSupplier;
    Builder() {
    }
    Builder(ApiTracerContext source) {
      this.serverAddress = source.serverAddress();
      this.serverPort = source.serverPort();
      this.libraryMetadata = source.libraryMetadata();
      this.fullMethodName = source.fullMethodName();
      this.transport = source.transport();
      this.operationType = source.operationType();
      this.httpMethod = source.httpMethod();
      this.httpPathTemplate = source.httpPathTemplate();
      this.serviceName = source.serviceName();
      this.urlDomain = source.urlDomain();
      this.destinationResourceIdSupplier = source.destinationResourceIdSupplier();
    }
    @Override
    public ApiTracerContext.Builder setServerAddress(@Nullable String serverAddress) {
      this.serverAddress = serverAddress;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setServerPort(@Nullable Integer serverPort) {
      this.serverPort = serverPort;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setLibraryMetadata(LibraryMetadata libraryMetadata) {
      if (libraryMetadata == null) {
        throw new NullPointerException("Null libraryMetadata");
      }
      this.libraryMetadata = libraryMetadata;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setFullMethodName(@Nullable String fullMethodName) {
      this.fullMethodName = fullMethodName;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setTransport(ApiTracerContext.@Nullable Transport transport) {
      this.transport = transport;
      return this;
    }
    @Override
    ApiTracerContext.Builder setOperationType(ApiTracerFactory.@Nullable OperationType operationType) {
      this.operationType = operationType;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setHttpMethod(@Nullable String httpMethod) {
      this.httpMethod = httpMethod;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setHttpPathTemplate(@Nullable String httpPathTemplate) {
      this.httpPathTemplate = httpPathTemplate;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setServiceName(@Nullable String serviceName) {
      this.serviceName = serviceName;
      return this;
    }
    @Override
    public ApiTracerContext.Builder setUrlDomain(@Nullable String urlDomain) {
      this.urlDomain = urlDomain;
      return this;
    }
    @Override
    ApiTracerContext.Builder setDestinationResourceIdSupplier(@Nullable Supplier<String> destinationResourceIdSupplier) {
      this.destinationResourceIdSupplier = destinationResourceIdSupplier;
      return this;
    }
    @Override
    public ApiTracerContext build() {
      if (this.libraryMetadata == null) {
        String missing = " libraryMetadata";
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_ApiTracerContext(
          this.serverAddress,
          this.serverPort,
          this.libraryMetadata,
          this.fullMethodName,
          this.transport,
          this.operationType,
          this.httpMethod,
          this.httpPathTemplate,
          this.serviceName,
          this.urlDomain,
          this.destinationResourceIdSupplier);
    }
  }

}
